export type GoalCategory =
  | 'all'
  | 'money'
  | 'automation'
  | 'content'
  | 'clients'
  | 'productivity'
  | 'skills';

export interface Product {
  id: string;
  title: string;
  category: GoalCategory;
  categoryLabel: string;
  tagline: string;
  description: string;
  priceINR: number;
  originalPriceINR: number;
  badge?: string;
  rating: number;
  reviewsCount: number;
  format: string; // e.g. 'Notion + PDF + Video'
  deliverables: string[];
  samplePreviewTitle?: string;
  samplePreviewContent?: string;
  difficulty: 'Beginner' | 'Intermediate' | 'All Levels';
  popular?: boolean;
  featured?: boolean;
}

export interface Bundle {
  id: string;
  title: string;
  subtitle: string;
  badge: string;
  badgeType: 'popular' | 'business' | 'ultimate' | 'creator';
  priceINR: number;
  originalPriceINR: number;
  features: string[];
  includedProducts: string[];
  savingsPercent: number;
}

export interface BlogPost {
  id: string;
  title: string;
  category: string;
  readTime: string;
  date: string;
  excerpt: string;
  content: string[];
  keyTakeaways: string[];
}

export interface FAQItem {
  question: string;
  answer: string;
  category: string;
}

export interface OrderInfo {
  orderId: string;
  customerName: string;
  customerEmail: string;
  productName: string;
  totalPaid: number;
  date: string;
  downloads: { name: string; type: string; size: string }[];
}
