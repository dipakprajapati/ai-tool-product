import React from 'react';
import { Target, Search, Download, Rocket } from 'lucide-react';

export const HowItWorks: React.FC = () => {
  const steps = [
    {
      num: '1',
      title: 'Choose Your Goal',
      desc: 'Pick from side hustles, automation, content creation, or business growth.',
      icon: <Target className="w-6 h-6 text-blue-600" />,
    },
    {
      num: '2',
      title: 'Pick the Right Resource',
      desc: 'Browse individual toolkits or comprehensive multi-product bundles.',
      icon: <Search className="w-6 h-6 text-blue-600" />,
    },
    {
      num: '3',
      title: 'Download & Learn',
      desc: 'Get instant digital access to structured guides, templates, and prompts.',
      icon: <Download className="w-6 h-6 text-blue-600" />,
    },
    {
      num: '4',
      title: 'Apply to Your Work',
      desc: 'Save hours of time and build new digital capabilities immediately.',
      icon: <Rocket className="w-6 h-6 text-blue-600" />,
    },
  ];

  return (
    <section id="how-it-works" className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center max-w-2xl mx-auto mb-14">
        <span className="text-blue-600 text-xs font-extrabold uppercase tracking-widest">
          SIMPLE PROCESS
        </span>
        <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-[#0F172A] mt-1">
          How It Works
        </h2>
        <p className="mt-3 text-slate-600 text-base">
          Get started with our practical digital products in 4 simple steps.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
        {steps.map((step) => (
          <div
            key={step.num}
            className="bg-white p-8 rounded-3xl border border-slate-200 text-center shadow-xs hover:shadow-md hover:border-blue-300 transition-all flex flex-col items-center justify-between"
          >
            <div className="w-14 h-14 bg-blue-50 text-blue-600 font-extrabold rounded-2xl flex items-center justify-center mb-5 text-xl border border-blue-100 shadow-inner">
              {step.num}
            </div>

            <h3 className="font-bold text-lg text-slate-900 mb-2">
              {step.title}
            </h3>

            <p className="text-sm text-slate-600 leading-relaxed">
              {step.desc}
            </p>

            <div className="mt-5 p-2 rounded-xl bg-slate-50 text-slate-400">
              {step.icon}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
