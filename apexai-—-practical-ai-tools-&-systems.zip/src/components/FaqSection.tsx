import React, { useState } from 'react';
import { FAQItem } from '../types';
import { ChevronDown, HelpCircle, Sparkles } from 'lucide-react';

interface FaqSectionProps {
  faqs: FAQItem[];
}

export const FaqSection: React.FC<FaqSectionProps> = ({ faqs }) => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggle = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  return (
    <section id="faq" className="py-20 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center mb-14">
        <span className="text-blue-600 text-xs font-extrabold uppercase tracking-widest flex items-center justify-center gap-1.5">
          <HelpCircle className="w-3.5 h-3.5" />
          COMMON INQUIRIES
        </span>
        <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-[#0F172A] mt-1">
          Frequently Asked Questions
        </h2>
        <p className="mt-3 text-slate-600 text-base">
          Got questions about our digital products? We have clear answers.
        </p>
      </div>

      <div className="space-y-4">
        {faqs.map((faq, idx) => {
          const isOpen = openIndex === idx;
          return (
            <div
              key={idx}
              className={`bg-white rounded-2xl border transition-all overflow-hidden ${
                isOpen ? 'border-blue-300 shadow-md shadow-blue-500/5' : 'border-slate-200'
              }`}
            >
              <button
                type="button"
                onClick={() => toggle(idx)}
                className="w-full text-left p-6 flex justify-between items-center cursor-pointer gap-4 focus:outline-none"
              >
                <span className="font-bold text-slate-900 text-base sm:text-lg">
                  {faq.question}
                </span>
                <span
                  className={`w-7 h-7 rounded-full bg-slate-50 text-blue-600 flex items-center justify-center shrink-0 transition-transform duration-200 ${
                    isOpen ? 'rotate-180 bg-blue-50' : ''
                  }`}
                >
                  <ChevronDown className="w-4 h-4 font-bold" />
                </span>
              </button>

              {isOpen && (
                <div className="px-6 pb-6 pt-0 text-sm sm:text-base text-slate-600 leading-relaxed border-t border-slate-100 mt-1 animate-fadeIn">
                  <p className="pt-3">{faq.answer}</p>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Support note */}
      <div className="mt-10 text-center p-6 bg-slate-50 rounded-2xl border border-slate-200 text-sm text-slate-600">
        Still have questions? Email us directly at{' '}
        <span className="font-semibold text-blue-600">support@apexai.tools</span> — we typically reply in under 2 hours.
      </div>
    </section>
  );
};
