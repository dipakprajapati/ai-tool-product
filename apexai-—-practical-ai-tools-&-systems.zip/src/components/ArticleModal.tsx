import React from 'react';
import { BlogPost } from '../types';
import { X, Clock, Calendar, CheckCircle2, Share2, BookOpen } from 'lucide-react';

interface ArticleModalProps {
  article: BlogPost | null;
  onClose: () => void;
}

export const ArticleModal: React.FC<ArticleModalProps> = ({ article, onClose }) => {
  if (!article) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 relative shadow-2xl my-8 max-h-[90vh] overflow-y-auto border border-slate-100">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-6 right-6 text-slate-400 hover:text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-full w-9 h-9 flex items-center justify-center text-lg font-bold transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Article Metadata */}
        <div className="flex items-center gap-3 text-xs text-slate-500 mb-3">
          <span className="bg-blue-50 text-blue-700 font-bold px-3 py-1 rounded-full uppercase tracking-wider">
            {article.category}
          </span>
          <span className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" />
            {article.readTime}
          </span>
          <span>•</span>
          <span className="flex items-center gap-1">
            <Calendar className="w-3.5 h-3.5" />
            {article.date}
          </span>
        </div>

        {/* Title */}
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight leading-snug">
          {article.title}
        </h2>

        <p className="mt-3 text-base text-slate-600 italic border-l-2 border-blue-500 pl-3 leading-relaxed">
          {article.excerpt}
        </p>

        {/* Key Takeaways Box */}
        <div className="mt-6 bg-slate-50 rounded-2xl p-5 border border-slate-200">
          <div className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-500" />
            <span>Key Actionable Takeaways</span>
          </div>
          <ul className="space-y-2 text-xs sm:text-sm text-slate-700">
            {article.keyTakeaways.map((item, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="text-blue-600 font-bold mt-0.5">•</span>
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Article Body */}
        <div className="mt-6 space-y-4 text-sm text-slate-700 leading-relaxed">
          {article.content.map((p, idx) => (
            <p key={idx}>{p}</p>
          ))}
        </div>

        {/* Footer actions */}
        <div className="mt-8 pt-6 border-t border-slate-200 flex items-center justify-between">
          <div className="text-xs text-slate-500">
            Published by ApexAI Editorial Team
          </div>
          <button
            onClick={onClose}
            className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold px-5 py-2.5 rounded-xl transition"
          >
            Close Article
          </button>
        </div>
      </div>
    </div>
  );
};
