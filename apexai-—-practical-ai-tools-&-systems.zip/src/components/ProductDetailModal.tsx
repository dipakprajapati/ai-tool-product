import React from 'react';
import { Product } from '../types';
import { X, Star, CheckCircle2, Download, Terminal, Layers, Clock, ShieldCheck } from 'lucide-react';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onProceedToCheckout: (product: Product) => void;
  currency: 'INR' | 'USD';
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onProceedToCheckout,
  currency,
}) => {
  if (!product) return null;

  const formatPrice = (inrPrice: number) => {
    if (currency === 'USD') {
      const usd = Math.round(inrPrice / 83);
      return `$${usd < 1 ? 1 : usd}`;
    }
    return `₹${inrPrice.toLocaleString('en-IN')}`;
  };

  const savings = Math.round(
    ((product.originalPriceINR - product.priceINR) / product.originalPriceINR) * 100
  );

  return (
    <div
      id="product-detail-modal"
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-fadeIn"
    >
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 relative shadow-2xl my-8 max-h-[92vh] overflow-y-auto border border-slate-100">
        {/* Close Button */}
        <button
          onClick={onClose}
          id="close-product-detail-modal-btn"
          className="absolute top-6 right-6 text-slate-400 hover:text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-full w-9 h-9 flex items-center justify-center text-lg font-bold transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Product Category & Rating */}
        <div className="flex items-center gap-3 mb-2">
          <span className="bg-blue-50 text-blue-700 font-extrabold text-xs px-3 py-1 rounded-full uppercase tracking-wider">
            {product.categoryLabel}
          </span>
          <div className="flex items-center gap-1 text-xs font-bold text-amber-500">
            <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
            <span>{product.rating}</span>
            <span className="text-slate-400 font-normal">
              ({product.reviewsCount} verified reviews)
            </span>
          </div>
        </div>

        {/* Title & Tagline */}
        <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          {product.title}
        </h2>
        <p className="mt-1 text-sm sm:text-base text-blue-600 font-medium">
          {product.tagline}
        </p>

        <p className="mt-3 text-sm text-slate-600 leading-relaxed">
          {product.description}
        </p>

        {/* Format & Difficulty Pills */}
        <div className="mt-4 flex flex-wrap gap-2 text-xs">
          <span className="bg-slate-100 text-slate-700 font-medium px-3 py-1 rounded-lg flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-blue-600" />
            <span>Format: {product.format}</span>
          </span>
          <span className="bg-slate-100 text-slate-700 font-medium px-3 py-1 rounded-lg flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-blue-600" />
            <span>Level: {product.difficulty}</span>
          </span>
          <span className="bg-emerald-50 text-emerald-700 font-medium px-3 py-1 rounded-lg flex items-center gap-1.5">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Commercial Implementation License</span>
          </span>
        </div>

        {/* What's Included */}
        <div className="mt-6 bg-slate-50 p-5 rounded-2xl border border-slate-200">
          <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-3">
            What You Get Inside This Toolkit:
          </h4>
          <ul className="space-y-2.5">
            {product.deliverables.map((item, idx) => (
              <li key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-700">
                <CheckCircle2 className="w-4 h-4 text-blue-600 mt-0.5 shrink-0" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Sample Prompt / Snippet Preview if present */}
        {product.samplePreviewContent && (
          <div className="mt-5 bg-slate-900 text-slate-300 p-4 rounded-2xl border border-slate-800 text-xs">
            <div className="flex items-center justify-between text-blue-400 font-mono text-[11px] mb-2 font-bold">
              <span className="flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5" />
                {product.samplePreviewTitle || 'Sample Blueprint Preview'}
              </span>
              <span className="text-slate-500">Verified Prompt</span>
            </div>
            <p className="font-mono text-[11px] leading-relaxed text-slate-200 bg-slate-950 p-2.5 rounded-lg border border-slate-800">
              &quot;{product.samplePreviewContent}&quot;
            </p>
          </div>
        )}

        {/* Price & Checkout Footer */}
        <div className="mt-8 pt-6 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-400 line-through">
                {formatPrice(product.originalPriceINR)}
              </span>
              <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">
                Save {savings}%
              </span>
            </div>
            <div className="text-3xl font-extrabold text-slate-900">
              {formatPrice(product.priceINR)}
            </div>
          </div>

          <div className="flex gap-2">
            <button
              onClick={onClose}
              className="bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-semibold px-4 py-3 rounded-xl transition"
            >
              Continue Browsing
            </button>
            <button
              onClick={() => {
                onClose();
                onProceedToCheckout(product);
              }}
              className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-3 rounded-xl text-sm transition shadow-lg shadow-blue-500/25 flex items-center justify-center gap-2 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Get Access Now</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
