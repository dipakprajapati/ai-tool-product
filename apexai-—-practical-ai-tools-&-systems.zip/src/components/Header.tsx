import React, { useState } from 'react';
import { Sparkles, Menu, X, ShoppingBag, ShieldCheck, ArrowRight } from 'lucide-react';

interface HeaderProps {
  onExploreClick: () => void;
  currency: 'INR' | 'USD';
  onToggleCurrency: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onExploreClick,
  currency,
  onToggleCurrency,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <>
      {/* TOP ANNOUNCEMENT BAR */}
      <div id="announcement-bar" className="bg-blue-600 text-white text-xs py-2.5 text-center font-medium px-4 tracking-wide relative z-50">
        <div className="max-w-7xl mx-auto flex items-center justify-center gap-2 flex-wrap">
          <span className="inline-flex items-center gap-1 font-semibold">
            🚀 Special Launch Offer:
          </span>
          <span>
            Get up to 60% off on all{' '}
            <a
              href="#bundles"
              className="underline font-bold hover:text-blue-100 transition-colors inline-flex items-center gap-0.5"
            >
              Complete AI Bundles
              <ArrowRight className="w-3 h-3 inline" />
            </a>{' '}
            today! Use code <span className="bg-blue-700 px-1.5 py-0.5 rounded font-mono font-bold">LAUNCH60</span>
          </span>
        </div>
      </div>

      {/* HEADER / NAVIGATION */}
      <header id="main-header" className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <a
            href="#"
            id="brand-logo-link"
            className="text-xl font-extrabold tracking-tight text-[#0F172A] flex items-center gap-2.5 group"
          >
            <span className="w-9 h-9 bg-blue-600 text-white rounded-xl flex items-center justify-center text-sm font-black shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform">
              AI
            </span>
            <span className="flex flex-col">
              <span className="leading-tight text-lg font-black tracking-tight text-slate-900">
                Apex<span className="text-blue-600">AI</span>
              </span>
              <span className="text-[10px] text-slate-400 font-semibold tracking-wider uppercase">
                Systems & Workkits
              </span>
            </span>
          </a>

          {/* Desktop Navigation */}
          <nav id="desktop-nav" className="hidden lg:flex items-center space-x-7 text-sm font-medium text-slate-600">
            <a href="#home" className="text-blue-600 font-semibold transition hover:text-blue-700">
              Home
            </a>
            <a href="#shop" className="hover:text-blue-600 transition flex items-center gap-1.5">
              <span>Shop</span>
              <span className="bg-blue-50 text-blue-700 text-[11px] font-bold px-2 py-0.5 rounded-full border border-blue-100">
                50+ Products
              </span>
            </a>
            <a href="#bundles" className="hover:text-blue-600 transition">
              Bundles
            </a>
            <a href="#free-resources" className="hover:text-blue-600 transition">
              Free Resources
            </a>
            <a href="#how-it-works" className="hover:text-blue-600 transition">
              How It Works
            </a>
            <a href="#blog" className="hover:text-blue-600 transition">
              Blog
            </a>
            <a href="#faq" className="hover:text-blue-600 transition">
              FAQ
            </a>
          </nav>

          {/* Right Action Controls */}
          <div className="hidden md:flex items-center space-x-3.5">
            {/* Currency Toggle */}
            <button
              id="currency-toggle-btn"
              onClick={onToggleCurrency}
              title="Toggle Currency"
              className="text-xs font-semibold px-2.5 py-1.5 rounded-lg border border-slate-200 text-slate-600 hover:text-blue-600 hover:border-blue-300 transition-colors bg-slate-50 flex items-center gap-1"
            >
              <span>Currency:</span>
              <span className="text-blue-600 font-bold">{currency === 'INR' ? '₹ INR' : '$ USD'}</span>
            </button>

            <a
              href="#shop"
              id="header-explore-btn"
              onClick={onExploreClick}
              className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-xl text-sm font-semibold transition shadow-sm shadow-blue-500/20 flex items-center gap-2 active:scale-95"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Explore Products</span>
            </a>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center gap-2 md:hidden">
            <button
              onClick={onToggleCurrency}
              className="text-xs font-bold px-2 py-1 rounded border border-slate-200 text-slate-700 bg-slate-50"
            >
              {currency === 'INR' ? '₹' : '$'}
            </button>
            <button
              id="mobile-menu-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-700 rounded-lg hover:bg-slate-100 focus:outline-none transition"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu Dropdown */}
        {mobileMenuOpen && (
          <div
            id="mobile-menu"
            className="md:hidden bg-white border-b border-slate-200 px-6 py-5 space-y-3.5 shadow-lg animate-fadeIn"
          >
            <a
              href="#home"
              onClick={() => setMobileMenuOpen(false)}
              className="block text-slate-900 font-semibold py-1.5 hover:text-blue-600"
            >
              Home
            </a>
            <a
              href="#shop"
              onClick={() => setMobileMenuOpen(false)}
              className="block text-slate-700 py-1.5 hover:text-blue-600 flex items-center justify-between"
            >
              <span>Shop All Products</span>
              <span className="bg-blue-50 text-blue-700 text-xs font-bold px-2 py-0.5 rounded-full">
                50+
              </span>
            </a>
            <a
              href="#bundles"
              onClick={() => setMobileMenuOpen(false)}
              className="block text-slate-700 py-1.5 hover:text-blue-600"
            >
              Complete AI Bundles
            </a>
            <a
              href="#free-resources"
              onClick={() => setMobileMenuOpen(false)}
              className="block text-slate-700 py-1.5 hover:text-blue-600"
            >
              Free 50 Prompts Guide
            </a>
            <a
              href="#how-it-works"
              onClick={() => setMobileMenuOpen(false)}
              className="block text-slate-700 py-1.5 hover:text-blue-600"
            >
              How It Works
            </a>
            <a
              href="#blog"
              onClick={() => setMobileMenuOpen(false)}
              className="block text-slate-700 py-1.5 hover:text-blue-600"
            >
              Articles & Guides
            </a>
            <a
              href="#faq"
              onClick={() => setMobileMenuOpen(false)}
              className="block text-slate-700 py-1.5 hover:text-blue-600"
            >
              FAQ
            </a>
            <div className="pt-3 border-t border-slate-100 flex flex-col gap-2.5">
              <a
                href="#shop"
                onClick={() => {
                  setMobileMenuOpen(false);
                  onExploreClick();
                }}
                className="block text-center bg-blue-600 text-white py-3 rounded-xl font-semibold shadow-sm hover:bg-blue-700"
              >
                Explore 50+ Products
              </a>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
