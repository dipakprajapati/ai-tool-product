import React from 'react';
import { BlogPost } from '../types';
import { Clock, ArrowRight, BookOpen, Sparkles } from 'lucide-react';

interface BlogSectionProps {
  posts: BlogPost[];
  onReadArticle: (post: BlogPost) => void;
}

export const BlogSection: React.FC<BlogSectionProps> = ({ posts, onReadArticle }) => {
  return (
    <section id="blog" className="py-20 bg-slate-50 border-y border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <span className="text-blue-600 text-xs font-extrabold uppercase tracking-widest flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              AI RESOURCES & GUIDES
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-[#0F172A] mt-1">
              Latest Articles & Tutorials
            </h2>
            <p className="mt-2 text-slate-600 text-sm">
              In-depth strategies, frameworks, and actionable playbooks updated weekly.
            </p>
          </div>

          <a
            href="#blog"
            onClick={(e) => {
              e.preventDefault();
              onReadArticle(posts[0]);
            }}
            className="mt-4 md:mt-0 text-blue-600 font-bold hover:text-blue-700 hover:underline flex items-center gap-1 text-sm cursor-pointer"
          >
            <span>View featured guide</span>
            <ArrowRight className="w-4 h-4" />
          </a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {posts.map((post) => (
            <div
              key={post.id}
              onClick={() => onReadArticle(post)}
              className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-xl hover:border-blue-300 transition-all flex flex-col justify-between cursor-pointer group"
            >
              <div>
                {/* Visual Header */}
                <div className="bg-gradient-to-br from-slate-900 to-slate-800 aspect-[16/10] p-6 flex flex-col justify-between text-white relative overflow-hidden">
                  <div className="flex justify-between items-center relative z-10">
                    <span className="bg-blue-600 text-white text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider">
                      {post.category}
                    </span>
                    <span className="text-slate-400 text-xs flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      {post.readTime}
                    </span>
                  </div>
                  <div className="relative z-10 flex items-center gap-2 text-xs font-mono text-blue-300">
                    <BookOpen className="w-4 h-4 text-blue-400" />
                    <span>Tutorial & Blueprint</span>
                  </div>
                </div>

                <div className="p-6">
                  <span className="text-xs text-blue-600 font-bold uppercase tracking-wider">
                    {post.category}
                  </span>
                  <h3 className="text-lg font-bold text-slate-900 mt-2 group-hover:text-blue-600 transition leading-snug">
                    {post.title}
                  </h3>
                  <p className="mt-2 text-sm text-slate-600 line-clamp-3 leading-relaxed">
                    {post.excerpt}
                  </p>
                </div>
              </div>

              <div className="p-6 pt-0 border-t border-slate-100 mt-3 flex items-center justify-between text-xs font-bold text-blue-600 group-hover:translate-x-1 transition-transform">
                <span>Read Full Article</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
