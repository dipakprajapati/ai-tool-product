import React from 'react';
import { CheckCircle, ShieldCheck, Zap, Sparkles, Clock, Globe } from 'lucide-react';

export const TrustStrip: React.FC = () => {
  const trustItems = [
    { title: 'Practical & Actionable', desc: 'No fluff, just proven steps' },
    { title: 'Beginner Friendly', desc: 'Zero coding required' },
    { title: 'Ready-to-Use Resources', desc: 'Copy-paste templates' },
    { title: 'Lifetime Access*', desc: 'Free updates included' },
    { title: 'Real-World Use', desc: 'Tested in production' },
  ];

  return (
    <section id="trust-strip" className="border-y border-slate-200 bg-white py-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 text-center">
          {trustItems.map((item, idx) => (
            <div
              key={idx}
              className={`flex items-center justify-center gap-2 p-2 rounded-xl transition ${
                idx === trustItems.length - 1 ? 'col-span-2 md:col-span-1' : ''
              }`}
            >
              <div className="w-5 h-5 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center shrink-0">
                <CheckCircle className="w-3.5 h-3.5 stroke-[2.5]" />
              </div>
              <div className="text-left">
                <span className="text-xs sm:text-sm font-bold text-slate-800 block leading-tight">
                  {item.title}
                </span>
                <span className="text-[11px] text-slate-500 hidden sm:inline-block">
                  {item.desc}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
