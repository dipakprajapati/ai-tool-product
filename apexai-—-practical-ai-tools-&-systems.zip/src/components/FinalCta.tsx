import React from 'react';
import { ArrowRight, ShoppingBag, ShieldCheck } from 'lucide-react';

interface FinalCtaProps {
  onExploreClick: () => void;
}

export const FinalCta: React.FC<FinalCtaProps> = ({ onExploreClick }) => {
  return (
    <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative overflow-hidden">
      <div className="bg-gradient-to-b from-blue-50/80 to-white p-10 sm:p-16 rounded-3xl border border-blue-100 shadow-xl shadow-blue-500/5 relative">
        <span className="text-blue-600 text-xs font-black uppercase tracking-widest bg-blue-100/80 px-3.5 py-1.5 rounded-full inline-block mb-4">
          GET STARTED TODAY
        </span>
        <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-[#0F172A] max-w-2xl mx-auto leading-tight">
          Ready to Start Using AI More Effectively?
        </h2>
        <p className="mt-4 text-slate-600 text-base sm:text-lg max-w-xl mx-auto leading-relaxed">
          Explore practical resources, templates, and systems designed to help you work smarter,
          create faster and build with AI.
        </p>
        <div className="mt-8 flex flex-col sm:flex-row justify-center items-center gap-4">
          <a
            href="#shop"
            onClick={onExploreClick}
            className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white font-semibold px-8 py-4 rounded-xl text-base shadow-lg shadow-blue-600/25 transition inline-flex items-center justify-center gap-2 active:scale-95"
          >
            <ShoppingBag className="w-5 h-5" />
            <span>Explore All Products</span>
          </a>
          <a
            href="#bundles"
            className="w-full sm:w-auto bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 font-semibold px-8 py-4 rounded-xl text-base transition shadow-sm inline-flex items-center justify-center gap-2"
          >
            <span>View All Bundles (Save 60%)</span>
            <ArrowRight className="w-4 h-4" />
          </a>
        </div>

        <div className="mt-8 flex items-center justify-center gap-6 text-xs font-semibold text-slate-500">
          <span className="flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            14-Day Money Back Guarantee
          </span>
          <span>•</span>
          <span>Instant Download</span>
          <span>•</span>
          <span>Lifetime Access</span>
        </div>
      </div>
    </section>
  );
};
