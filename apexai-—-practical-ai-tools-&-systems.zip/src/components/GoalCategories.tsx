import React from 'react';
import { GoalCategory } from '../types';
import { ArrowUpRight } from 'lucide-react';

interface GoalCategoriesProps {
  selectedCategory: GoalCategory;
  onSelectCategory: (cat: GoalCategory) => void;
}

interface GoalCard {
  category: GoalCategory;
  emoji: string;
  title: string;
  description: string;
  badge: string;
}

export const GoalCategories: React.FC<GoalCategoriesProps> = ({
  selectedCategory,
  onSelectCategory,
}) => {
  const goals: GoalCard[] = [
    {
      category: 'money',
      emoji: '💰',
      title: 'Make Money With AI',
      description: 'Explore practical side hustles, digital product systems, and freelance toolkits.',
      badge: 'High Earning Potential',
    },
    {
      category: 'automation',
      emoji: '⚙️',
      title: 'Automate Your Business',
      description: 'Deploy AI chatbots, booking bots, customer support flows, and automated workflows.',
      badge: 'Save 10+ hrs/week',
    },
    {
      category: 'content',
      emoji: '🚀',
      title: 'Grow Your Content',
      description: 'Speed up creation with viral reel vaults, YouTube scripts, and design kits.',
      badge: '10x Content Speed',
    },
    {
      category: 'clients',
      emoji: '📈',
      title: 'Get More Clients',
      description: 'High-converting cold email kits, sales funnel templates, and proposal packs.',
      badge: 'High Conversion',
    },
    {
      category: 'productivity',
      emoji: '⚡',
      title: 'Work Faster With AI',
      description: 'ChatGPT prompt packs, Notion workspace templates, and productivity systems.',
      badge: 'Daily Time Saver',
    },
    {
      category: 'skills',
      emoji: '🎓',
      title: 'Build AI Skills',
      description: 'Beginner-friendly guides and toolkits designed for real-world application.',
      badge: 'Practical Learning',
    },
  ];

  const handleCardClick = (cat: GoalCategory) => {
    onSelectCategory(cat);
    const shopEl = document.getElementById('shop');
    if (shopEl) {
      shopEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="goals" className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center max-w-2xl mx-auto mb-14">
        <span className="text-blue-600 text-xs font-extrabold uppercase tracking-widest">
          TARGETED WORKKITS
        </span>
        <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-[#0F172A] mt-1">
          Shop By Your Goal
        </h2>
        <p className="mt-3 text-slate-600 text-base">
          Select what you want to achieve and find the exact toolkit designed for it.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {goals.map((g) => {
          const isSelected = selectedCategory === g.category;
          return (
            <div
              key={g.category}
              id={`goal-card-${g.category}`}
              onClick={() => handleCardClick(g.category)}
              className={`group bg-white p-7 sm:p-8 rounded-3xl border transition-all cursor-pointer relative overflow-hidden flex flex-col justify-between ${
                isSelected
                  ? 'border-blue-600 ring-2 ring-blue-600/20 shadow-lg shadow-blue-500/10'
                  : 'border-slate-200 hover:border-blue-400 hover:shadow-xl'
              }`}
            >
              <div>
                <div className="flex items-center justify-between mb-5">
                  <div className="w-14 h-14 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center text-2xl font-bold group-hover:bg-blue-600 group-hover:text-white transition-all transform group-hover:scale-110">
                    {g.emoji}
                  </div>
                  <span className="text-[11px] font-bold text-slate-500 bg-slate-100 px-2.5 py-1 rounded-full group-hover:bg-blue-50 group-hover:text-blue-700 transition">
                    {g.badge}
                  </span>
                </div>

                <h3 className="text-xl font-bold text-slate-900 group-hover:text-blue-600 transition flex items-center justify-between">
                  <span>{g.title}</span>
                  <ArrowUpRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity text-blue-600" />
                </h3>
                <p className="mt-2 text-sm text-slate-600 leading-relaxed">
                  {g.description}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-blue-600">
                <span>View Products in this Category</span>
                <span>→</span>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
