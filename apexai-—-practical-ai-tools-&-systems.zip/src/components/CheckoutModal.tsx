import React, { useState } from 'react';
import { Product, Bundle, OrderInfo } from '../types';
import {
  X,
  ShieldCheck,
  Download,
  CheckCircle2,
  Lock,
  Tag,
  CreditCard,
  QrCode,
  Building,
  Check,
  Copy,
  FileText
} from 'lucide-react';

interface CheckoutModalProps {
  item: Product | Bundle | null;
  onClose: () => void;
  currency: 'INR' | 'USD';
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({ item, onClose, currency }) => {
  if (!item) return null;

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [couponCode, setCouponCode] = useState('');
  const [appliedDiscount, setAppliedDiscount] = useState<number | null>(null);
  const [couponError, setCouponError] = useState('');
  const [couponSuccess, setCouponSuccess] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'card' | 'netbanking'>('upi');
  const [isProcessing, setIsProcessing] = useState(false);
  const [orderComplete, setOrderComplete] = useState<OrderInfo | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);

  // Price calculations
  const basePriceINR = item.priceINR;
  const discountAmountINR = appliedDiscount ? Math.round((basePriceINR * appliedDiscount) / 100) : 0;
  const finalPriceINR = Math.max(0, basePriceINR - discountAmountINR);

  const formatPrice = (inrPrice: number) => {
    if (currency === 'USD') {
      const usd = Math.round(inrPrice / 83);
      return `$${usd < 1 ? 1 : usd}`;
    }
    return `₹${inrPrice.toLocaleString('en-IN')}`;
  };

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError('');
    setCouponSuccess('');

    const clean = couponCode.trim().toUpperCase();
    if (clean === 'LAUNCH60') {
      setAppliedDiscount(60);
      setCouponSuccess('Launch promo applied: 60% OFF!');
    } else if (clean === 'WELCOME20' || clean === 'AI20') {
      setAppliedDiscount(20);
      setCouponSuccess('Welcome voucher applied: 20% OFF!');
    } else {
      setCouponError('Invalid coupon code. Try code LAUNCH60');
    }
  };

  const handleSubmitPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !email) return;

    setIsProcessing(true);

    setTimeout(() => {
      setIsProcessing(false);
      const randomOrderId = `APX-${Math.floor(100000 + Math.random() * 900000)}`;
      setOrderComplete({
        orderId: randomOrderId,
        customerName: fullName,
        customerEmail: email,
        productName: item.title,
        totalPaid: finalPriceINR,
        date: new Date().toLocaleDateString('en-US', {
          month: 'short',
          day: 'numeric',
          year: 'numeric',
        }),
        downloads: [
          { name: `${item.title.replace(/\s+/g, '_')}_Master_Pack.zip`, type: 'ZIP Archive', size: '18.4 MB' },
          { name: 'Instant_Notion_Duplicate_Link.pdf', type: 'PDF Document', size: '1.2 MB' },
          { name: 'Setup_Video_Walkthrough_Guide.mp4', type: 'MP4 Stream', size: '1080p' },
        ],
      });
    }, 1200);
  };

  const handleCopyPortalLink = () => {
    navigator.clipboard.writeText(`https://apexai.tools/access/${orderComplete?.orderId}`);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div
      id="checkout-modal"
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-fadeIn"
    >
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 relative shadow-2xl my-8 max-h-[95vh] overflow-y-auto border border-slate-100">
        {/* Close Button */}
        <button
          onClick={onClose}
          id="close-checkout-modal-btn"
          className="absolute top-6 right-6 text-slate-400 hover:text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-full w-9 h-9 flex items-center justify-center text-lg font-bold transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {!orderComplete ? (
          <>
            <div className="flex items-center gap-2 text-blue-600 font-bold text-xs uppercase tracking-wider mb-1">
              <Lock className="w-3.5 h-3.5" />
              <span>256-Bit Encrypted Checkout</span>
            </div>
            <h3 className="text-2xl font-extrabold text-slate-900">
              Secure Checkout
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Instant digital access delivered immediately to your screen & email.
            </p>

            {/* Product Summary Box */}
            <div className="mt-5 bg-slate-50 p-4 rounded-2xl border border-slate-200">
              <div className="flex items-start justify-between">
                <div>
                  <div id="modal-product-name" className="font-bold text-slate-900 text-sm sm:text-base">
                    {item.title}
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    {'categoryLabel' in item ? item.categoryLabel : 'Complete Multi-Product Bundle'} • Instant Download
                  </div>
                </div>
                <div className="text-right">
                  {appliedDiscount && (
                    <div className="text-xs text-slate-400 line-through">
                      {formatPrice(basePriceINR)}
                    </div>
                  )}
                  <div id="modal-product-price" className="text-xl font-extrabold text-blue-600">
                    {formatPrice(finalPriceINR)}
                  </div>
                </div>
              </div>

              {/* Coupon Code Input */}
              <div className="mt-3 pt-3 border-t border-slate-200">
                <form onSubmit={handleApplyCoupon} className="flex gap-2">
                  <div className="relative flex-1">
                    <Tag className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      value={couponCode}
                      onChange={(e) => setCouponCode(e.target.value)}
                      placeholder="Promo code (e.g. LAUNCH60)"
                      className="w-full bg-white border border-slate-300 pl-8 pr-3 py-1.5 rounded-xl text-xs uppercase focus:outline-none focus:border-blue-600 font-mono"
                    />
                  </div>
                  <button
                    type="submit"
                    className="bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold px-3 py-1.5 rounded-xl transition cursor-pointer"
                  >
                    Apply
                  </button>
                </form>

                {couponSuccess && (
                  <div className="text-[11px] text-emerald-600 font-bold mt-1.5 flex items-center gap-1">
                    <Check className="w-3 h-3" /> {couponSuccess}
                  </div>
                )}
                {couponError && (
                  <div className="text-[11px] text-rose-600 mt-1.5">
                    {couponError}
                  </div>
                )}
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="mt-5">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-2">
                Select Payment Method
              </label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('upi')}
                  className={`p-2.5 rounded-xl border text-xs font-semibold flex flex-col items-center gap-1 transition cursor-pointer ${
                    paymentMethod === 'upi'
                      ? 'border-blue-600 bg-blue-50 text-blue-700 ring-1 ring-blue-600'
                      : 'border-slate-200 hover:border-slate-300 text-slate-600'
                  }`}
                >
                  <QrCode className="w-4 h-4" />
                  <span>UPI / QR</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('card')}
                  className={`p-2.5 rounded-xl border text-xs font-semibold flex flex-col items-center gap-1 transition cursor-pointer ${
                    paymentMethod === 'card'
                      ? 'border-blue-600 bg-blue-50 text-blue-700 ring-1 ring-blue-600'
                      : 'border-slate-200 hover:border-slate-300 text-slate-600'
                  }`}
                >
                  <CreditCard className="w-4 h-4" />
                  <span>Cards</span>
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('netbanking')}
                  className={`p-2.5 rounded-xl border text-xs font-semibold flex flex-col items-center gap-1 transition cursor-pointer ${
                    paymentMethod === 'netbanking'
                      ? 'border-blue-600 bg-blue-50 text-blue-700 ring-1 ring-blue-600'
                      : 'border-slate-200 hover:border-slate-300 text-slate-600'
                  }`}
                >
                  <Building className="w-4 h-4" />
                  <span>Net Banking</span>
                </button>
              </div>
            </div>

            {/* Checkout Form */}
            <form onSubmit={handleSubmitPayment} className="mt-5 space-y-3.5">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="Enter your full name"
                  className="w-full bg-white border border-slate-300 rounded-xl px-4 py-2.5 text-slate-900 focus:outline-none focus:border-blue-600 text-sm shadow-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Email Address (For File Delivery)
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="w-full bg-white border border-slate-300 rounded-xl px-4 py-2.5 text-slate-900 focus:outline-none focus:border-blue-600 text-sm shadow-xs"
                />
              </div>

              {paymentMethod === 'upi' && (
                <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs text-slate-600 flex items-center justify-between">
                  <span>Fast UPI Auto-routing: Google Pay, PhonePe, Paytm supported.</span>
                  <span className="text-emerald-600 font-bold">0% fee</span>
                </div>
              )}

              <button
                type="submit"
                disabled={isProcessing}
                id="submit-payment-btn"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3.5 rounded-xl transition shadow-lg shadow-blue-600/30 text-base mt-2 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-75"
              >
                {isProcessing ? (
                  <span>Securing Order...</span>
                ) : (
                  <>
                    <Lock className="w-4 h-4" />
                    <span>Pay {formatPrice(finalPriceINR)} &amp; Get Instant Access</span>
                  </>
                )}
              </button>

              <div className="flex items-center justify-center gap-3 text-[11px] text-slate-400 text-center pt-1">
                <span>🔒 SSL Encrypted</span>
                <span>•</span>
                <span>Lifetime Access</span>
                <span>•</span>
                <span>14-Day Guarantee</span>
              </div>
            </form>
          </>
        ) : (
          /* Order Confirmation View */
          <div className="space-y-5 animate-fadeIn text-center">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-2">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div>
              <span className="text-xs font-mono font-bold text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full">
                Order #{orderComplete.orderId}
              </span>
              <h3 className="text-2xl font-black text-slate-900 mt-2">
                Payment Successful!
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Receipt and access links sent to{' '}
                <span className="font-semibold text-slate-800">{orderComplete.customerEmail}</span>
              </p>
            </div>

            {/* Instant Download Links Container */}
            <div className="text-left bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2.5">
              <div className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                Your Deliverables Ready For Download:
              </div>
              {orderComplete.downloads.map((dl, idx) => (
                <div
                  key={idx}
                  className="bg-white p-3 rounded-xl border border-slate-200 flex items-center justify-between shadow-xs"
                >
                  <div className="flex items-center gap-2.5">
                    <FileText className="w-5 h-5 text-blue-600 shrink-0" />
                    <div>
                      <div className="text-xs font-bold text-slate-900 truncate max-w-[200px] sm:max-w-xs">
                        {dl.name}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        {dl.type} • {dl.size}
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => alert(`Starting download for ${dl.name}...`)}
                    className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold px-3 py-1.5 rounded-lg flex items-center gap-1 transition shrink-0"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download</span>
                  </button>
                </div>
              ))}
            </div>

            {/* Portal Link / Share */}
            <div className="flex gap-2">
              <button
                onClick={handleCopyPortalLink}
                className="flex-1 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-semibold py-2.5 rounded-xl transition flex items-center justify-center gap-1.5"
              >
                {copiedLink ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                <span>{copiedLink ? 'Link Copied!' : 'Copy Portal Link'}</span>
              </button>
              <button
                onClick={onClose}
                className="flex-1 bg-slate-900 hover:bg-black text-white text-xs font-semibold py-2.5 rounded-xl transition"
              >
                Done
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
