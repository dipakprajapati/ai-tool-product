import React, { useState } from 'react';
import { Download, CheckCircle2, Copy, Check, Sparkles, FileText, ArrowRight } from 'lucide-react';

export const FreeResourceSection: React.FC = () => {
  const [firstName, setFirstName] = useState('');
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [copiedPromptIndex, setCopiedPromptIndex] = useState<number | null>(null);

  const samplePrompts = [
    {
      role: 'Content & Socials',
      prompt: 'Act as a viral content strategist. Take the following key idea: "[Insert Idea]" and create 3 distinct hooks for LinkedIn: 1) Counter-intuitive statement, 2) Step-by-step breakdown, 3) Personal mistake & lesson learned.',
    },
    {
      role: 'Client Outreach',
      prompt: 'Act as a top-performing B2B sales development rep. Write a 65-word cold outreach email to a [Target Role] at [Target Company]. Highlight how we solved [Common Pain Point] for a similar company, ending with a low-friction question.',
    },
    {
      role: 'Workflow Optimization',
      prompt: 'Review this list of my daily tasks: [Insert 5 Tasks]. Identify which tasks can be fully automated using free AI tools (Make.com, ChatGPT, Google Docs) and write out the exact input/output trigger for each.',
    },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setSubmitted(true);
  };

  const handleCopyPrompt = (text: string, idx: number) => {
    navigator.clipboard.writeText(text);
    setCopiedPromptIndex(idx);
    setTimeout(() => setCopiedPromptIndex(null), 2000);
  };

  return (
    <section id="free-resources" className="py-20 bg-slate-900 text-white relative overflow-hidden">
      {/* Background ambient lighting */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center relative z-10">
        <div>
          <span className="bg-blue-500/20 text-blue-400 text-xs font-bold px-3.5 py-1.5 rounded-full inline-flex items-center gap-1.5 border border-blue-500/30">
            <Sparkles className="w-3.5 h-3.5" />
            FREE RESOURCE
          </span>

          <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight mt-4 text-white">
            Start With Free AI Resources
          </h2>

          <p className="mt-4 text-slate-300 text-base leading-relaxed">
            Not ready to buy yet? Start with practical AI resources designed to help you
            understand what&apos;s possible and take your first step without spending a rupee.
          </p>

          <ul className="mt-6 space-y-3 text-sm text-slate-300">
            <li className="flex items-center gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Instant PDF & Notion database link delivered immediately</span>
            </li>
            <li className="flex items-center gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>Beginner friendly examples, fill-in-the-blank brackets, and workflows</span>
            </li>
            <li className="flex items-center gap-2.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>100% spam-free guarantee. Unsubscribe with 1-click anytime</span>
            </li>
          </ul>

          <div className="mt-8 p-4 rounded-2xl bg-slate-800/80 border border-slate-700 text-xs text-slate-300 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-600/30 text-blue-400 flex items-center justify-center font-bold shrink-0">
              50+
            </div>
            <div>
              <div className="font-bold text-white">Over 8,400 downloads this month</div>
              <div className="text-slate-400">Used by solo founders, freelancers, and growth teams</div>
            </div>
          </div>
        </div>

        {/* Form Card or Instant Download Preview */}
        <div className="bg-white/10 p-8 sm:p-10 rounded-3xl border border-white/10 backdrop-blur-md shadow-2xl">
          {!submitted ? (
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-2xl font-bold text-white">
                  Get the 50 ChatGPT Prompts Guide
                </h3>
                <span className="text-xs bg-emerald-500/20 text-emerald-300 px-2.5 py-1 rounded-full font-mono font-bold">
                  FREE
                </span>
              </div>
              <p className="text-xs text-slate-300 mb-6">
                Enter your details below for instant on-screen access and email delivery.
              </p>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                    First Name
                  </label>
                  <input
                    type="text"
                    required
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    placeholder="Enter your first name"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3.5 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 text-sm shadow-inner"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300 mb-2">
                    Email Address (For Instant Access)
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3.5 text-white placeholder-slate-500 focus:outline-none focus:border-blue-500 text-sm shadow-inner"
                  />
                </div>

                <button
                  type="submit"
                  id="free-guide-submit-btn"
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-4 rounded-xl transition shadow-lg shadow-blue-600/30 text-base mt-2 flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Download className="w-5 h-5" />
                  <span>Get Free Resources Now</span>
                </button>

                <p className="text-[11px] text-slate-400 text-center">
                  By signing up, you agree to receive helpful AI guides. Unsubscribe anytime.
                </p>
              </form>
            </div>
          ) : (
            <div className="space-y-5 animate-fadeIn">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                  <CheckCircle2 className="w-7 h-7" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-white">
                    Access Granted, {firstName || 'Builder'}!
                  </h3>
                  <p className="text-xs text-emerald-400">
                    Direct access link prepared for {email}
                  </p>
                </div>
              </div>

              {/* Instant Download Action */}
              <div className="bg-slate-800 p-4 rounded-2xl border border-slate-700 flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <FileText className="w-6 h-6 text-blue-400" />
                  <div>
                    <div className="text-sm font-bold text-white">50_ChatGPT_Prompts_Guide.pdf</div>
                    <div className="text-xs text-slate-400">PDF + Notion Database Link (3.4 MB)</div>
                  </div>
                </div>
                <a
                  href="#free-resources"
                  onClick={() => alert(`Downloading ApexAI 50 Prompts Guide for ${email}...`)}
                  className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-3.5 py-2 rounded-xl transition flex items-center gap-1"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download</span>
                </a>
              </div>

              {/* Interactive prompt previewer inside the card */}
              <div className="pt-2">
                <div className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center justify-between">
                  <span>Quick Preview of Top Prompts Inside:</span>
                  <span className="text-[10px] text-blue-400">Copy & Paste</span>
                </div>
                <div className="space-y-2.5">
                  {samplePrompts.map((sp, idx) => (
                    <div
                      key={idx}
                      className="bg-slate-900/80 p-3 rounded-xl border border-slate-800 text-xs space-y-1.5"
                    >
                      <div className="flex justify-between items-center text-[10px] font-bold text-blue-400">
                        <span>{sp.role}</span>
                        <button
                          onClick={() => handleCopyPrompt(sp.prompt, idx)}
                          className="text-slate-400 hover:text-white flex items-center gap-1 cursor-pointer"
                        >
                          {copiedPromptIndex === idx ? (
                            <span className="text-emerald-400 flex items-center gap-0.5">
                              <Check className="w-3 h-3" /> Copied!
                            </span>
                          ) : (
                            <span className="flex items-center gap-0.5">
                              <Copy className="w-3 h-3" /> Copy
                            </span>
                          )}
                        </button>
                      </div>
                      <p className="text-slate-300 font-mono text-[11px] leading-relaxed line-clamp-2">
                        {sp.prompt}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              <button
                onClick={() => setSubmitted(false)}
                className="text-xs text-slate-400 hover:text-white underline block text-center pt-2"
              >
                Send to another email
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
