import React, { useState } from 'react';
import {
  Sparkles,
  Bot,
  Zap,
  ArrowRight,
  Calculator,
  CheckCircle2,
  Copy,
  Check,
  Download,
  Terminal,
  Clock,
  Coins
} from 'lucide-react';

interface HeroProps {
  onExploreProducts: () => void;
  onGetFreeResources: () => void;
}

export const Hero: React.FC<HeroProps> = ({
  onExploreProducts,
  onGetFreeResources,
}) => {
  const [activeTab, setActiveTab] = useState<'bot' | 'prompt' | 'calculator'>('bot');
  const [copiedPrompt, setCopiedPrompt] = useState(false);

  // Mini calculator state inside the showcase
  const [weeklyHours, setWeeklyHours] = useState(12);
  const [hourlyValue, setHourlyValue] = useState(1000); // INR

  const savedHoursPerMonth = Math.round(weeklyHours * 4 * 0.65);
  const monthlySavings = savedHoursPerMonth * hourlyValue;

  const handleCopyPrompt = () => {
    navigator.clipboard.writeText(
      'Act as a Senior Operations Specialist. Analyze my weekly schedule and create an automated 3-step Zapier/Make blueprint connecting my client inquiries to an instant AI qualification agent.'
    );
    setCopiedPrompt(true);
    setTimeout(() => setCopiedPrompt(false), 2000);
  };

  return (
    <section
      id="home"
      className="relative overflow-hidden pt-12 pb-20 lg:pt-20 lg:pb-28 bg-gradient-to-b from-blue-50/70 via-slate-50/40 to-transparent"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        {/* Top Pill */}
        <div className="inline-flex items-center gap-2 bg-blue-50 border border-blue-200/80 text-blue-700 px-4 py-1.5 rounded-full text-xs font-bold mb-6 shadow-xs hover:bg-blue-100/70 transition cursor-default">
          <Sparkles className="w-3.5 h-3.5 text-blue-600" />
          <span>Practical AI Systems, Templates & Playbooks</span>
        </div>

        {/* Heading */}
        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold tracking-tight text-[#0F172A] max-w-4xl mx-auto leading-[1.08]">
          Build Smarter With AI.
        </h1>

        {/* Subtitle */}
        <p className="mt-6 text-lg sm:text-xl text-slate-600 max-w-2xl mx-auto leading-relaxed font-normal">
          Practical AI tools, templates, prompts and step-by-step systems designed
          to help you save time, create faster and build new digital opportunities.
        </p>

        {/* Action Buttons */}
        <div className="mt-10 flex flex-col sm:flex-row justify-center items-center gap-4">
          <a
            href="#shop"
            id="hero-explore-cta"
            onClick={onExploreProducts}
            className="w-full sm:w-auto bg-blue-600 hover:bg-blue-700 text-white font-semibold px-8 py-4 rounded-xl text-base shadow-lg shadow-blue-600/25 transition active:scale-95 flex items-center justify-center gap-2"
          >
            <span>Explore AI Products</span>
            <ArrowRight className="w-4 h-4" />
          </a>
          <a
            href="#free-resources"
            id="hero-free-cta"
            onClick={onGetFreeResources}
            className="w-full sm:w-auto bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 font-semibold px-8 py-4 rounded-xl text-base transition shadow-sm flex items-center justify-center gap-2"
          >
            <span>Get Free AI Resources</span>
            <Download className="w-4 h-4 text-slate-500" />
          </a>
        </div>

        {/* Hero Visual Preview - Interactive Ecosystem Dashboard */}
        <div className="mt-14 max-w-5xl mx-auto rounded-3xl border border-slate-200/90 bg-white p-3 sm:p-4 shadow-2xl shadow-slate-300/40">
          <div className="bg-slate-900 rounded-2xl p-4 sm:p-6 text-left relative overflow-hidden border border-slate-800">
            {/* Ambient subtle glow */}
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(37,99,235,0.18)_0,transparent_75%)] pointer-events-none" />

            {/* Showcase Header Bar */}
            <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
              <div className="flex items-center gap-2.5">
                <div className="flex gap-1.5">
                  <span className="w-3 h-3 rounded-full bg-red-500/80 inline-block" />
                  <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block" />
                  <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block" />
                </div>
                <span className="text-xs font-mono text-slate-400 font-medium pl-2">
                  ApexAI Digital Ecosystem v2.6 • Interactive Console
                </span>
              </div>

              {/* Interactive Tabs */}
              <div className="flex items-center gap-1.5 bg-slate-800/90 p-1 rounded-xl border border-slate-700/60 text-xs font-semibold">
                <button
                  onClick={() => setActiveTab('bot')}
                  className={`px-3 py-1.5 rounded-lg transition ${
                    activeTab === 'bot'
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  WhatsApp Bot Kit
                </button>
                <button
                  onClick={() => setActiveTab('prompt')}
                  className={`px-3 py-1.5 rounded-lg transition ${
                    activeTab === 'prompt'
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Prompt Engine
                </button>
                <button
                  onClick={() => setActiveTab('calculator')}
                  className={`px-3 py-1.5 rounded-lg transition ${
                    activeTab === 'calculator'
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  ROI Calculator
                </button>
              </div>
            </div>

            {/* Showcase Body Content */}
            <div className="relative z-10 py-5">
              {activeTab === 'bot' && (
                <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                  <div className="md:col-span-7 space-y-3">
                    <div className="inline-flex items-center gap-2 bg-emerald-500/10 text-emerald-400 text-xs px-2.5 py-1 rounded-md font-mono border border-emerald-500/20">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      Live WhatsApp Node Simulation
                    </div>
                    <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                      Automated Lead Triage & Appointment Booking
                    </h3>
                    <p className="text-slate-300 text-sm leading-relaxed">
                      Pre-wired Make.com & n8n templates capture prospect messages,
                      identify interest level, qualify budget, and send direct calendar booking links in under 12 seconds.
                    </p>
                    <div className="flex flex-wrap gap-2 pt-1 text-xs text-slate-300">
                      <span className="bg-slate-800/80 px-2.5 py-1 rounded-md border border-slate-700">
                        ⚡ 1-Click JSON Import
                      </span>
                      <span className="bg-slate-800/80 px-2.5 py-1 rounded-md border border-slate-700">
                        📱 Works on Free WhatsApp Cloud API
                      </span>
                      <span className="bg-slate-800/80 px-2.5 py-1 rounded-md border border-slate-700">
                        📊 Realtime Sheets Sync
                      </span>
                    </div>
                  </div>

                  <div className="md:col-span-5 bg-slate-950/90 rounded-xl p-3.5 border border-slate-800 text-xs font-mono space-y-2.5 text-slate-300">
                    <div className="text-[11px] text-slate-500 uppercase tracking-wider font-sans font-bold">
                      Incoming Customer Chat:
                    </div>
                    <div className="bg-slate-800/80 p-2.5 rounded-lg border border-slate-700/50 text-slate-200">
                      &quot;Hi! What are your pricing packages for digital consulting?&quot;
                    </div>
                    <div className="bg-blue-950/60 p-2.5 rounded-lg border border-blue-500/30 text-blue-200 space-y-1">
                      <div className="text-[10px] text-blue-400 font-sans font-bold">ApexAI WhatsApp Bot:</div>
                      <div>
                        &quot;Hey there! We have packages starting from ₹4,999. Would you like me to reserve a 15-min discovery slot tomorrow at 11 AM or 4 PM?&quot;
                      </div>
                    </div>
                    <div className="flex items-center justify-between text-[11px] text-emerald-400 pt-1">
                      <span>✓ Lead auto-logged in CRM</span>
                      <span className="text-slate-500">Latency: 1.1s</span>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'prompt' && (
                <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                  <div className="md:col-span-7 space-y-3">
                    <div className="inline-flex items-center gap-2 bg-blue-500/10 text-blue-400 text-xs px-2.5 py-1 rounded-md font-mono border border-blue-500/20">
                      <Terminal className="w-3.5 h-3.5" />
                      500+ Tested Prompt System
                    </div>
                    <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                      Master Prompt Architectures That Never Fail
                    </h3>
                    <p className="text-slate-300 text-sm leading-relaxed">
                      Stop getting vague, generic ChatGPT outputs. Each prompt includes verified role calibration, output constraints, and few-shot examples.
                    </p>
                    <div className="pt-2">
                      <button
                        onClick={handleCopyPrompt}
                        className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold px-4 py-2 rounded-lg transition flex items-center gap-2 shadow-sm"
                      >
                        {copiedPrompt ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
                        <span>{copiedPrompt ? 'Copied Prompt to Clipboard!' : 'Copy Sample Master Prompt'}</span>
                      </button>
                    </div>
                  </div>

                  <div className="md:col-span-5 bg-slate-950/90 rounded-xl p-3.5 border border-slate-800 text-xs font-mono text-slate-300">
                    <div className="flex justify-between items-center text-[10px] text-slate-500 mb-1.5">
                      <span>SYSTEM_PROMPT.md</span>
                      <span>v2.4 Ready</span>
                    </div>
                    <p className="text-blue-300 leading-relaxed bg-slate-900/90 p-2.5 rounded-lg border border-slate-800">
                      &quot;Act as a Senior Operations Specialist. Analyze my weekly schedule and create an automated 3-step Zapier/Make blueprint connecting my client inquiries to an instant AI qualification agent...&quot;
                    </p>
                    <div className="mt-2 text-[11px] text-slate-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Tested on GPT-4o, Claude 3.5 Sonnet & Gemini 1.5/2.0</span>
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'calculator' && (
                <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
                  <div className="md:col-span-6 space-y-3">
                    <div className="inline-flex items-center gap-2 bg-amber-500/10 text-amber-400 text-xs px-2.5 py-1 rounded-md font-mono border border-amber-500/20">
                      <Calculator className="w-3.5 h-3.5" />
                      Interactive Time & Revenue Estimator
                    </div>
                    <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                      Calculate Your Estimated Weekly Savings
                    </h3>
                    <div className="space-y-3 pt-1 text-slate-300 text-xs">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span>Hours spent weekly on repetitive admin:</span>
                          <span className="font-bold text-white">{weeklyHours} hrs/week</span>
                        </div>
                        <input
                          type="range"
                          min="4"
                          max="40"
                          value={weeklyHours}
                          onChange={(e) => setWeeklyHours(Number(e.target.value))}
                          className="w-full accent-blue-500 cursor-pointer"
                        />
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span>Estimated value of your work per hour:</span>
                          <span className="font-bold text-white">₹{hourlyValue}/hr</span>
                        </div>
                        <input
                          type="range"
                          min="300"
                          max="5000"
                          step="100"
                          value={hourlyValue}
                          onChange={(e) => setHourlyValue(Number(e.target.value))}
                          className="w-full accent-blue-500 cursor-pointer"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="md:col-span-6 bg-slate-950/90 rounded-xl p-4 border border-slate-800 text-center space-y-3">
                    <div className="text-xs text-slate-400 uppercase tracking-wider font-semibold">
                      Your Projected ROI With ApexAI Toolkits
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
                        <div className="text-2xl font-black text-blue-400">~{savedHoursPerMonth} hrs</div>
                        <div className="text-[11px] text-slate-400 mt-0.5">Time Saved / Month</div>
                      </div>
                      <div className="bg-slate-900 p-3 rounded-lg border border-slate-800">
                        <div className="text-2xl font-black text-emerald-400">₹{monthlySavings.toLocaleString()}</div>
                        <div className="text-[11px] text-slate-400 mt-0.5">Productive Value Reclaimed</div>
                      </div>
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Average toolkit pays for itself in less than 48 hours of deployment.
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Showcase Footer Metrics Strip */}
            <div className="relative z-10 pt-4 border-t border-slate-800 grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div>
                <div className="text-base sm:text-lg font-extrabold text-white">50+</div>
                <div className="text-[11px] text-slate-400">Modular Workkits</div>
              </div>
              <div>
                <div className="text-base sm:text-lg font-extrabold text-white">12,400+</div>
                <div className="text-[11px] text-slate-400">Active Professionals</div>
              </div>
              <div>
                <div className="text-base sm:text-lg font-extrabold text-white">4.9 / 5.0</div>
                <div className="text-[11px] text-slate-400">Verified User Rating</div>
              </div>
              <div>
                <div className="text-base sm:text-lg font-extrabold text-emerald-400">Instant</div>
                <div className="text-[11px] text-slate-400">Digital Delivery</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
