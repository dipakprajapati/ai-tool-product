import { Bundle } from '../types';

export const BUNDLES_DATA: Bundle[] = [
  {
    id: 'bundle-side-hustle',
    title: 'AI Side Hustle Starter Bundle',
    subtitle: 'For beginners who want to explore practical AI-based income opportunities without guesswork.',
    badge: 'POPULAR BUNDLE',
    badgeType: 'popular',
    priceINR: 2999,
    originalPriceINR: 6999,
    savingsPercent: 57,
    features: [
      '6 Complete Digital Toolkits & Video Guides',
      '50 Proven AI Income Streams & Execution Frameworks',
      'ChatGPT Prompt Mega Pack (500+ Prompts) Included',
      'AI Freelancing Starter Kit + Contract Templates',
      'AI Digital Products Playbook with Canva Assets',
      'Lifetime Access & All Future Quarterly Updates'
    ],
    includedProducts: [
      'AI Freelancing Starter Kit',
      'AI Digital Products Playbook',
      'ChatGPT Prompt Mega Pack',
      'AI Viral Short-Form Video Vault',
      'Personal AI Chief of Staff',
      'Midjourney & Image AI Design Suite'
    ]
  },
  {
    id: 'bundle-business-automation',
    title: 'AI Business Automation Bundle',
    subtitle: 'For freelancers, agencies, and businesses that want to use AI to automate repetitive work and capture leads.',
    badge: 'BUSINESS ESSENTIAL',
    badgeType: 'business',
    priceINR: 3999,
    originalPriceINR: 8999,
    savingsPercent: 56,
    features: [
      'AI Chatbot Agency Mastery Course & Pitch Decks',
      'AI WhatsApp Sales Bot Kit (1-Click Make Blueprints)',
      'AI Lead Generation & Outbound Prospecting Kit',
      'Ready-to-Deploy Customer Support & Booking Workflows',
      'Client Service Agreements & High-Ticket Pricing Matrix',
      'Lifetime Access, Direct Setup Support & Video Guides'
    ],
    includedProducts: [
      'AI WhatsApp Sales Bot Kit',
      'AI Chatbot Agency Mastery',
      'AI Automation Workflow Templates',
      'AI Lead Generation Kit',
      'AI Proposal & Closing Mastery Pack'
    ]
  },
  {
    id: 'bundle-creator-powerpack',
    title: 'AI Creator & Content Powerpack',
    subtitle: 'Everything a solo creator, YouTuber, or marketer needs to produce 10x more high-retention content.',
    badge: 'CREATOR FAVORITE',
    badgeType: 'creator',
    priceINR: 1999,
    originalPriceINR: 4999,
    savingsPercent: 60,
    features: [
      'AI Viral Short-Form Video Vault (100 Hooks)',
      'AI YouTube Studio OS with Storytelling Formulas',
      'AI Social Media Omnipresence Kit (1-to-15 Repurposing)',
      'Midjourney Visual Design Suite & Thumbnail Prompts',
      'SEO Content Engine & E-E-A-T Article Blueprints'
    ],
    includedProducts: [
      'AI Viral Short-Form Video Vault',
      'AI YouTube Studio OS',
      'AI Social Media Omnipresence Kit',
      'Midjourney & Image AI Design Suite',
      'AI SEO Content Engine'
    ]
  },
  {
    id: 'bundle-ultimate-empire',
    title: 'Ultimate AI Digital Empire All-Access',
    subtitle: 'The full ApexAI digital vault — every single current product, blueprint, prompt system, and future releases.',
    badge: 'MAXIMUM VALUE',
    badgeType: 'ultimate',
    priceINR: 5999,
    originalPriceINR: 14999,
    savingsPercent: 60,
    features: [
      'Access to ALL 50+ Current & Upcoming Digital Products',
      'Both Business Automation & Side Hustle Bundles Included',
      'All Notion Second Brain Systems & Workflow Blueprints',
      'Private Discord Community & Monthly Live Q&A Sessions',
      'VIP Priority Support & Commercial Usage License',
      'Permanent Lifetime Access with Zero Subscription Fees'
    ],
    includedProducts: [
      'Entire ApexAI Catalog (18+ Standalone Toolkits + All Bundles)'
    ]
  }
];
