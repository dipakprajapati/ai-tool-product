import { FAQItem } from '../types';

export const FAQS_DATA: FAQItem[] = [
  {
    question: 'What are digital products and how do I receive them?',
    answer: 'Digital products are downloadable resources such as PDF guides, Notion systems, Zapier/Make.com JSON blueprints, Canva graphic templates, and structured prompt libraries. Immediately after completing your payment, you will receive on-screen instant download access plus an automated email containing lifetime access links.',
    category: 'General'
  },
  {
    question: 'Are these products beginner friendly?',
    answer: 'Yes, 100%! Every product and bundle is specifically built with clear step-by-step instructions, screenshots, and video walk-throughs. No coding or prior AI expertise is required to implement any of the templates.',
    category: 'Usability'
  },
  {
    question: 'Do I need paid subscriptions to tools like ChatGPT Plus or Zapier?',
    answer: 'Most of our templates and prompt packs are completely functional with the free tier of ChatGPT, Claude, and Google Docs. For business automation workflows, free plans of Make.com and Zapier are fully supported to get started.',
    category: 'Tools'
  },
  {
    question: 'What payment methods do you support?',
    answer: 'We support all major payment methods including UPI (Google Pay, PhonePe, Paytm), Credit & Debit cards (Visa, Mastercard, RuPay), Net Banking, and international cards via secure encrypted checkout.',
    category: 'Payment'
  },
  {
    question: 'Do I get updates when AI models or platforms update?',
    answer: 'Yes! All digital products and bundles come with free lifetime updates. Whenever new AI models (e.g., GPT-5, Gemini 2.5, Claude 4) release new features or API changes, we update the prompts, blueprints, and guides in your member download portal.',
    category: 'Updates'
  },
  {
    question: 'What is your refund policy?',
    answer: 'We stand behind the quality of our work. If you find that a purchased product does not deliver the promised templates or does not work as described within 14 days of purchase, simply contact our support email for assistance or a prompt refund.',
    category: 'Guarantee'
  },
  {
    question: 'Can I use these templates for client projects or commercial use?',
    answer: 'Yes! You are granted commercial usage rights to implement the workflows, chatbots, prompt outputs, and systems for your personal business or on behalf of paying clients. You may not re-sell or redistribute the raw template files themselves.',
    category: 'Licensing'
  }
];
