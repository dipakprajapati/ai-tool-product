import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { TrustStrip } from './components/TrustStrip';
import { GoalCategories } from './components/GoalCategories';
import { ProductCatalog } from './components/ProductCatalog';
import { BundlesSection } from './components/BundlesSection';
import { FreeResourceSection } from './components/FreeResourceSection';
import { HowItWorks } from './components/HowItWorks';
import { BlogSection } from './components/BlogSection';
import { FaqSection } from './components/FaqSection';
import { FinalCta } from './components/FinalCta';
import { Footer } from './components/Footer';
import { CheckoutModal } from './components/CheckoutModal';
import { ProductDetailModal } from './components/ProductDetailModal';
import { ArticleModal } from './components/ArticleModal';

import { PRODUCTS_DATA } from './data/products';
import { BUNDLES_DATA } from './data/bundles';
import { BLOG_POSTS_DATA } from './data/blog';
import { FAQS_DATA } from './data/faqs';
import { Product, Bundle, BlogPost, GoalCategory } from './types';

export default function App() {
  const [selectedCategory, setSelectedCategory] = useState<GoalCategory>('all');
  const [currency, setCurrency] = useState<'INR' | 'USD'>('INR');

  // Modals state
  const [checkoutItem, setCheckoutItem] = useState<Product | Bundle | null>(null);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [activeArticle, setActiveArticle] = useState<BlogPost | null>(null);

  const handleToggleCurrency = () => {
    setCurrency((prev) => (prev === 'INR' ? 'USD' : 'INR'));
  };

  const scrollToShop = () => {
    const el = document.getElementById('shop');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToFreeResources = () => {
    const el = document.getElementById('free-resources');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAFAFC] text-[#0F172A] selection:bg-blue-600 selection:text-white">
      {/* Header with Top Announcement Bar */}
      <Header
        onExploreClick={scrollToShop}
        currency={currency}
        onToggleCurrency={handleToggleCurrency}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* Hero Section */}
        <Hero
          onExploreProducts={scrollToShop}
          onGetFreeResources={scrollToFreeResources}
        />

        {/* Value / Trust Strip */}
        <TrustStrip />

        {/* Shop By Your Goal */}
        <GoalCategories
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
        />

        {/* Product Catalogue (50+ Products Capable) */}
        <ProductCatalog
          products={PRODUCTS_DATA}
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
          onOpenCheckout={(prod) => setCheckoutItem(prod)}
          onQuickView={(prod) => setQuickViewProduct(prod)}
          currency={currency}
        />

        {/* Complete AI Bundles */}
        <BundlesSection
          bundles={BUNDLES_DATA}
          onOpenCheckoutForBundle={(b) => setCheckoutItem(b)}
          currency={currency}
        />

        {/* Free Resources & Lead Magnet */}
        <FreeResourceSection />

        {/* How It Works 4-Step Process */}
        <HowItWorks />

        {/* Blog & Tutorials Preview */}
        <BlogSection
          posts={BLOG_POSTS_DATA}
          onReadArticle={(post) => setActiveArticle(post)}
        />

        {/* Frequently Asked Questions */}
        <FaqSection faqs={FAQS_DATA} />

        {/* Final High-Converting CTA */}
        <FinalCta onExploreClick={scrollToShop} />
      </main>

      {/* Footer */}
      <Footer onSelectCategory={setSelectedCategory} />

      {/* Checkout Modal */}
      <CheckoutModal
        item={checkoutItem}
        onClose={() => setCheckoutItem(null)}
        currency={currency}
      />

      {/* Product Quick View Modal */}
      <ProductDetailModal
        product={quickViewProduct}
        onClose={() => setQuickViewProduct(null)}
        onProceedToCheckout={(prod) => setCheckoutItem(prod)}
        currency={currency}
      />

      {/* Blog Article Reader Modal */}
      <ArticleModal
        article={activeArticle}
        onClose={() => setActiveArticle(null)}
      />
    </div>
  );
}
