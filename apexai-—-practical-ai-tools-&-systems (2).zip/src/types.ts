export type GoalCategory =
  | 'all'
  | 'money'
  | 'automation'
  | 'content'
  | 'clients'
  | 'productivity'
  | 'skills';

export interface ProductCurriculumItem {
  title: string;
  duration?: string;
  description?: string;
}

export interface ProductBonusItem {
  title: string;
  valueINR: number;
  description: string;
}

export interface ProductFaqItem {
  question: string;
  answer: string;
}

export interface Product {
  id: string;
  title: string;
  category: GoalCategory;
  categoryLabel: string;
  tagline: string;
  description: string;
  fullDescription?: string;
  priceINR: number;
  originalPriceINR: number;
  badge?: string;
  rating: number;
  reviewsCount: number;
  format: string; // e.g. 'Notion + PDF + Video'
  deliverables: string[];
  learningPoints?: string[]; // Outcomes / What you will achieve
  curriculum?: ProductCurriculumItem[]; // Modules / Chapters breakdown
  targetAudience?: string[]; // Who this is for
  bonuses?: ProductBonusItem[]; // Included bonus pack
  faqs?: ProductFaqItem[]; // Custom FAQs
  authorBio?: string;
  guaranteeText?: string;
  samplePreviewTitle?: string;
  samplePreviewContent?: string;
  difficulty: 'Beginner' | 'Intermediate' | 'All Levels';
  popular?: boolean;
  featured?: boolean;
  imageUrl?: string;
  paymentLink?: string; // Custom Razorpay payment page URL or direct checkout link (e.g. https://rzp.io/l/...)
  pdfUrl?: string; // Direct digital download link or Google Drive / Cloud storage URL
  pdfFileName?: string;
  slug?: string;
  updatedAt?: string;
}

export interface Bundle {
  id: string;
  title: string;
  subtitle: string;
  badge: string;
  badgeType: 'popular' | 'business' | 'ultimate' | 'creator';
  priceINR: number;
  originalPriceINR: number;
  features: string[];
  includedProducts: string[];
  savingsPercent: number;
  slug?: string;
  imageUrl?: string;
  paymentLink?: string; // Custom Razorpay payment link for this bundle (e.g. https://rzp.io/l/...)
  fullDescription?: string;
  pdfUrl?: string;
  pdfFileName?: string;
  deliverables?: string[];
  curriculum?: ProductCurriculumItem[];
  targetAudience?: string[];
  bonuses?: ProductBonusItem[];
  faqs?: ProductFaqItem[];
  updatedAt?: string;
}

export interface PaymentGatewaySettings {
  defaultRazorpayUrl: string;
  razorpayKeyId?: string;
  merchantUpiId?: string;
  merchantName?: string;
  directRedirectOnAccess: boolean; // if true, clicking Get Access redirects directly to Razorpay link
  resendApiKey?: string; // Optional Resend API key for automated customer email delivery
  notificationWebhookUrl?: string; // Optional Webhook URL (Zapier/Make/Pabbly) for order delivery
  senderEmail?: string; // e.g. orders@apexai.tools or onboarding@resend.dev
  updatedAt?: string;
}

export interface BlogPost {
  id: string;
  title: string;
  category: string;
  readTime: string;
  date: string;
  excerpt: string;
  content: string[];
  keyTakeaways: string[];
  author?: string;
  imageUrl?: string;
  tags?: string;
  featured?: boolean;
  slug?: string;
  updatedAt?: string;
}

export interface FAQItem {
  question: string;
  answer: string;
  category: string;
}

export interface OrderInfo {
  orderId: string;
  productId?: string;
  customerName: string;
  customerEmail: string;
  productName: string;
  totalPaid: number;
  date: string;
  pdfUrl?: string;
  downloads: { name: string; type: string; size: string; downloadUrl?: string }[];
}
