import {
  collection,
  doc,
  setDoc,
  getDoc,
  deleteDoc,
  updateDoc,
  query,
  where,
  onSnapshot,
  getDocs,
} from 'firebase/firestore';
import { User as FirebaseUser } from 'firebase/auth';
import { db } from './config';
import { handleFirestoreError, OperationType } from './errors';
import { BlogPost, Product, Bundle, PaymentGatewaySettings } from '../types';
import { BLOG_POSTS_DATA } from '../data/blog';
import { PRODUCTS_DATA } from '../data/products';
import { BUNDLES_DATA } from '../data/bundles';

export interface FirestoreOrder {
  orderId: string;
  userId: string;
  productId?: string;
  customerName: string;
  customerEmail: string;
  productTitle: string;
  totalPaid: number;
  currency: string;
  paymentMethod: string;
  status: 'completed' | 'pending';
  pdfUrl?: string;
  downloadUrl?: string;
  createdAt: string;
}

export interface FirestoreSavedItem {
  id: string;
  userId: string;
  productId: string;
  productTitle: string;
  createdAt: string;
}

// Sync user profile upon Google Sign-In
export async function syncUserProfile(user: FirebaseUser): Promise<void> {
  const path = `users/${user.uid}`;
  try {
    const userDocRef = doc(db, 'users', user.uid);
    await setDoc(
      userDocRef,
      {
        uid: user.uid,
        email: user.email || '',
        displayName: user.displayName || 'Builder',
        photoURL: user.photoURL || '',
        createdAt: new Date().toISOString(),
      },
      { merge: true }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

// Record a new purchase order
export async function createOrderInFirestore(order: Omit<FirestoreOrder, 'createdAt'>): Promise<void> {
  const path = `orders/${order.orderId}`;
  try {
    const orderDocRef = doc(db, 'orders', order.orderId);
    await setDoc(orderDocRef, {
      ...order,
      createdAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

// Record an opt-in lead for free resources
export async function recordLeadInFirestore(
  firstName: string,
  email: string,
  resourceName: string
): Promise<void> {
  const leadId = `lead_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const path = `leads/${leadId}`;
  try {
    const leadDocRef = doc(db, 'leads', leadId);
    await setDoc(leadDocRef, {
      firstName: firstName.slice(0, 128),
      email: email.slice(0, 256),
      resourceName: resourceName.slice(0, 256),
      createdAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

// Subscribe to real-time purchases for current user
export function subscribeToUserOrders(
  userId: string,
  onUpdate: (orders: FirestoreOrder[]) => void
): () => void {
  const path = 'orders';
  try {
    const q = query(collection(db, 'orders'), where('userId', '==', userId));
    return onSnapshot(
      q,
      (snapshot) => {
        const orders: FirestoreOrder[] = [];
        snapshot.forEach((d) => {
          orders.push(d.data() as FirestoreOrder);
        });
        onUpdate(orders);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, path);
      }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

// Subscribe to saved/bookmarked items for current user
export function subscribeToSavedItems(
  userId: string,
  onUpdate: (items: FirestoreSavedItem[]) => void
): () => void {
  const path = 'savedItems';
  try {
    const q = query(collection(db, 'savedItems'), where('userId', '==', userId));
    return onSnapshot(
      q,
      (snapshot) => {
        const items: FirestoreSavedItem[] = [];
        snapshot.forEach((d) => {
          items.push({ id: d.id, ...(d.data() as Omit<FirestoreSavedItem, 'id'>) });
        });
        onUpdate(items);
      },
      (error) => {
        handleFirestoreError(error, OperationType.LIST, path);
      }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

// Toggle bookmark on/off
export async function toggleSaveProduct(
  userId: string,
  productId: string,
  productTitle: string,
  existingSavedId?: string
): Promise<void> {
  if (existingSavedId) {
    const path = `savedItems/${existingSavedId}`;
    try {
      await deleteDoc(doc(db, 'savedItems', existingSavedId));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, path);
    }
  } else {
    const savedItemId = `save_${userId.slice(0, 16)}_${productId}`;
    const path = `savedItems/${savedItemId}`;
    try {
      await setDoc(doc(db, 'savedItems', savedItemId), {
        userId,
        productId,
        productTitle,
        createdAt: new Date().toISOString(),
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, path);
    }
  }
}

// ==========================================
// DYNAMIC BLOG POSTS SERVICE
// ==========================================

export function formatContentArray(content: string | string[]): string[] {
  if (Array.isArray(content)) return content;
  return content
    .split('\n\n')
    .map((p) => p.trim())
    .filter(Boolean);
}

// Subscribe to real-time Blog Posts
export function subscribeToBlogPosts(onUpdate: (posts: BlogPost[]) => void): () => void {
  const path = 'blogPosts';
  try {
    const colRef = collection(db, 'blogPosts');
    return onSnapshot(
      colRef,
      (snapshot) => {
        if (snapshot.empty) {
          // If no posts in Firestore yet, provide default data
          onUpdate(BLOG_POSTS_DATA);
        } else {
          const list: BlogPost[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data();
            list.push({
              id: docSnap.id,
              title: data.title || 'Untitled Post',
              category: data.category || 'AI Insights',
              readTime: data.readTime || '5 min read',
              date: data.publishedAt || data.date || 'Recent',
              excerpt: data.excerpt || '',
              content: typeof data.content === 'string' ? formatContentArray(data.content) : (Array.isArray(data.content) ? data.content : []),
              keyTakeaways: typeof data.keyTakeaways === 'string' ? (data.keyTakeaways as string).split('\n').filter(Boolean) : (Array.isArray(data.keyTakeaways) ? data.keyTakeaways : []),
              author: data.author || 'ApexAI Editorial',
              imageUrl: data.imageUrl || '',
              tags: data.tags || '',
              featured: !!data.featured,
              slug: data.slug || docSnap.id,
              updatedAt: data.updatedAt,
            });
          });
          onUpdate(list);
        }
      },
      (error) => {
        console.warn('Falling back to local blog data due to:', error);
        onUpdate(BLOG_POSTS_DATA);
        handleFirestoreError(error, OperationType.LIST, path);
      }
    );
  } catch (error) {
    onUpdate(BLOG_POSTS_DATA);
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

// Create new dynamic blog post
export async function createBlogPostInFirestore(post: {
  id?: string;
  title: string;
  category: string;
  readTime: string;
  date?: string;
  excerpt: string;
  content: string | string[];
  keyTakeaways?: string | string[];
  author?: string;
  imageUrl?: string;
  tags?: string;
  featured?: boolean;
  slug?: string;
}
): Promise<string> {
  const id = post.id || `post_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const path = `blogPosts/${id}`;
  
  const contentString = Array.isArray(post.content) ? post.content.join('\n\n') : post.content;
  const takeaways = Array.isArray(post.keyTakeaways) ? post.keyTakeaways.join('\n') : (post.keyTakeaways || '');

  try {
    const postDocRef = doc(db, 'blogPosts', id);
    await setDoc(postDocRef, {
      id,
      slug: post.slug || id,
      title: post.title.slice(0, 256),
      category: post.category.slice(0, 64),
      readTime: (post.readTime || '5 min read').slice(0, 32),
      publishedAt: post.date || new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
      excerpt: post.excerpt.slice(0, 512),
      content: contentString.slice(0, 50000),
      keyTakeaways: takeaways.slice(0, 2000),
      author: (post.author || 'ApexAI Editorial').slice(0, 128),
      imageUrl: (post.imageUrl || '').slice(0, 2048),
      tags: (post.tags || '').slice(0, 256),
      featured: !!post.featured,
      updatedAt: new Date().toISOString(),
    });
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

// Update existing blog post
export async function updateBlogPostInFirestore(
  id: string,
  post: {
    title?: string;
    category?: string;
    readTime?: string;
    date?: string;
    excerpt?: string;
    content?: string | string[];
    keyTakeaways?: string | string[];
    author?: string;
    imageUrl?: string;
    tags?: string;
    featured?: boolean;
    slug?: string;
  }
): Promise<void> {
  const path = `blogPosts/${id}`;
  try {
    const postDocRef = doc(db, 'blogPosts', id);
    const updateData: Record<string, any> = {
      updatedAt: new Date().toISOString(),
    };
    if (post.title !== undefined) updateData.title = post.title.slice(0, 256);
    if (post.category !== undefined) updateData.category = post.category.slice(0, 64);
    if (post.readTime !== undefined) updateData.readTime = post.readTime.slice(0, 32);
    if (post.date !== undefined) updateData.publishedAt = post.date.slice(0, 64);
    if (post.excerpt !== undefined) updateData.excerpt = post.excerpt.slice(0, 512);
    if (post.content !== undefined) {
      updateData.content = (Array.isArray(post.content) ? post.content.join('\n\n') : post.content).slice(0, 50000);
    }
    if (post.keyTakeaways !== undefined) {
      updateData.keyTakeaways = (Array.isArray(post.keyTakeaways) ? post.keyTakeaways.join('\n') : post.keyTakeaways).slice(0, 2000);
    }
    if (post.author !== undefined) updateData.author = post.author.slice(0, 128);
    if (post.imageUrl !== undefined) updateData.imageUrl = post.imageUrl.slice(0, 2048);
    if (post.tags !== undefined) updateData.tags = post.tags.slice(0, 256);
    if (post.featured !== undefined) updateData.featured = !!post.featured;
    if (post.slug !== undefined) updateData.slug = post.slug.slice(0, 128);

    await updateDoc(postDocRef, updateData);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

// Delete blog post
export async function deleteBlogPostInFirestore(id: string): Promise<void> {
  const path = `blogPosts/${id}`;
  try {
    await deleteDoc(doc(db, 'blogPosts', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

// Seed default sample blogs into Firestore
export async function seedDefaultBlogPostsInFirestore(): Promise<void> {
  for (const post of BLOG_POSTS_DATA) {
    await createBlogPostInFirestore({
      id: post.id,
      title: post.title,
      category: post.category,
      readTime: post.readTime,
      date: post.date,
      imageUrl: post.imageUrl,
      excerpt: post.excerpt,
      content: post.content,
      keyTakeaways: post.keyTakeaways,
      author: 'ApexAI Editorial',
      tags: 'AI, Automation, Workflows',
      featured: true,
      slug: post.id,
    });
  }
}

// ==========================================
// DYNAMIC PRODUCTS SERVICE
// ==========================================

export function subscribeToProducts(onUpdate: (products: Product[]) => void): () => void {
  const path = 'products';
  try {
    const colRef = collection(db, 'products');
    return onSnapshot(
      colRef,
      (snapshot) => {
        if (snapshot.empty) {
          // If no products in Firestore yet, provide default catalog
          onUpdate(PRODUCTS_DATA);
        } else {
          const list: Product[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data();
            list.push({
              id: docSnap.id,
              slug: data.slug || docSnap.id,
              title: data.title || 'Untitled Product',
              category: data.category || 'automation',
              categoryLabel: data.categoryLabel || 'AI Business Automation',
              tagline: data.tagline || '',
              description: data.description || '',
              fullDescription: data.fullDescription || '',
              priceINR: typeof data.priceINR === 'number' ? data.priceINR : 999,
              originalPriceINR: typeof data.originalPriceINR === 'number' ? data.originalPriceINR : 1999,
              badge: data.badge || '',
              rating: typeof data.rating === 'number' ? data.rating : 4.9,
              reviewsCount: typeof data.reviewsCount === 'number' ? data.reviewsCount : 120,
              format: data.format || 'PDF Guide + Blueprints',
              deliverables: Array.isArray(data.deliverables) ? data.deliverables : [],
              learningPoints: Array.isArray(data.learningPoints) ? data.learningPoints : [],
              targetAudience: Array.isArray(data.targetAudience) ? data.targetAudience : [],
              curriculum: Array.isArray(data.curriculum) ? data.curriculum : [],
              bonuses: Array.isArray(data.bonuses) ? data.bonuses : [],
              faqs: Array.isArray(data.faqs) ? data.faqs : [],
              authorBio: data.authorBio || '',
              guaranteeText: data.guaranteeText || '',
              samplePreviewTitle: data.samplePreviewTitle || '',
              samplePreviewContent: data.samplePreviewContent || '',
              difficulty: data.difficulty || 'Beginner',
              popular: !!data.popular,
              featured: !!data.featured,
              imageUrl: data.imageUrl || '',
              paymentLink: data.paymentLink || '',
              pdfUrl: data.pdfUrl || '',
              pdfFileName: data.pdfFileName || '',
              updatedAt: data.updatedAt,
            });
          });
          onUpdate(list);
        }
      },
      (error) => {
        console.warn('Falling back to local products data due to:', error);
        onUpdate(PRODUCTS_DATA);
        handleFirestoreError(error, OperationType.LIST, path);
      }
    );
  } catch (error) {
    onUpdate(PRODUCTS_DATA);
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function createProductInFirestore(product: Partial<Product>): Promise<string> {
  const id = product.id || `prod_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const path = `products/${id}`;

  try {
    const productDocRef = doc(db, 'products', id);
    const dataToSave: Record<string, any> = {
      id,
      slug: product.slug || id,
      title: (product.title || 'New Digital Product').slice(0, 256),
      category: (product.category || 'automation').slice(0, 64),
      categoryLabel: (product.categoryLabel || 'AI Business Automation').slice(0, 128),
      tagline: (product.tagline || '').slice(0, 512),
      description: (product.description || '').slice(0, 2048),
      fullDescription: (product.fullDescription || '').slice(0, 25000),
      priceINR: product.priceINR !== undefined ? Number(product.priceINR) : 999,
      originalPriceINR: product.originalPriceINR !== undefined ? Number(product.originalPriceINR) : 1999,
      badge: (product.badge || '').slice(0, 64),
      rating: product.rating !== undefined ? Number(product.rating) : 4.9,
      reviewsCount: product.reviewsCount !== undefined ? Number(product.reviewsCount) : 85,
      format: (product.format || 'PDF Guide + Templates').slice(0, 128),
      difficulty: (product.difficulty || 'Beginner').slice(0, 64),
      imageUrl: (product.imageUrl || '').slice(0, 2048),
      paymentLink: (product.paymentLink || '').slice(0, 2048),
      pdfUrl: (product.pdfUrl || '').slice(0, 2048),
      pdfFileName: (product.pdfFileName || '').slice(0, 256),
      samplePreviewTitle: (product.samplePreviewTitle || '').slice(0, 256),
      samplePreviewContent: (product.samplePreviewContent || '').slice(0, 2048),
      deliverables: Array.isArray(product.deliverables) ? product.deliverables : [],
      learningPoints: Array.isArray(product.learningPoints) ? product.learningPoints : [],
      curriculum: Array.isArray(product.curriculum) ? product.curriculum : [],
      targetAudience: Array.isArray(product.targetAudience) ? product.targetAudience : [],
      bonuses: Array.isArray(product.bonuses) ? product.bonuses : [],
      faqs: Array.isArray(product.faqs) ? product.faqs : [],
      authorBio: (product.authorBio || '').slice(0, 2048),
      guaranteeText: (product.guaranteeText || '').slice(0, 1024),
      popular: !!product.popular,
      featured: !!product.featured,
      updatedAt: new Date().toISOString(),
    };

    await setDoc(productDocRef, dataToSave);
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateProductInFirestore(id: string, product: Partial<Product>): Promise<void> {
  const path = `products/${id}`;
  try {
    const productDocRef = doc(db, 'products', id);
    const updateData: Record<string, any> = {
      updatedAt: new Date().toISOString(),
    };

    if (product.title !== undefined) updateData.title = product.title.slice(0, 256);
    if (product.slug !== undefined) updateData.slug = product.slug.slice(0, 128);
    if (product.category !== undefined) updateData.category = product.category.slice(0, 64);
    if (product.categoryLabel !== undefined) updateData.categoryLabel = product.categoryLabel.slice(0, 128);
    if (product.tagline !== undefined) updateData.tagline = product.tagline.slice(0, 512);
    if (product.description !== undefined) updateData.description = product.description.slice(0, 2048);
    if (product.fullDescription !== undefined) updateData.fullDescription = product.fullDescription.slice(0, 25000);
    if (product.priceINR !== undefined) updateData.priceINR = Number(product.priceINR);
    if (product.originalPriceINR !== undefined) updateData.originalPriceINR = Number(product.originalPriceINR);
    if (product.badge !== undefined) updateData.badge = product.badge.slice(0, 64);
    if (product.rating !== undefined) updateData.rating = Number(product.rating);
    if (product.reviewsCount !== undefined) updateData.reviewsCount = Number(product.reviewsCount);
    if (product.format !== undefined) updateData.format = product.format.slice(0, 128);
    if (product.difficulty !== undefined) updateData.difficulty = product.difficulty.slice(0, 64);
    if (product.imageUrl !== undefined) updateData.imageUrl = product.imageUrl.slice(0, 2048);
    if (product.paymentLink !== undefined) updateData.paymentLink = product.paymentLink.slice(0, 2048);
    if (product.pdfUrl !== undefined) updateData.pdfUrl = product.pdfUrl.slice(0, 2048);
    if (product.pdfFileName !== undefined) updateData.pdfFileName = product.pdfFileName.slice(0, 256);
    if (product.samplePreviewTitle !== undefined) updateData.samplePreviewTitle = product.samplePreviewTitle.slice(0, 256);
    if (product.samplePreviewContent !== undefined) updateData.samplePreviewContent = product.samplePreviewContent.slice(0, 2048);
    if (product.deliverables !== undefined) updateData.deliverables = Array.isArray(product.deliverables) ? product.deliverables : [];
    if (product.learningPoints !== undefined) updateData.learningPoints = Array.isArray(product.learningPoints) ? product.learningPoints : [];
    if (product.curriculum !== undefined) updateData.curriculum = Array.isArray(product.curriculum) ? product.curriculum : [];
    if (product.targetAudience !== undefined) updateData.targetAudience = Array.isArray(product.targetAudience) ? product.targetAudience : [];
    if (product.bonuses !== undefined) updateData.bonuses = Array.isArray(product.bonuses) ? product.bonuses : [];
    if (product.faqs !== undefined) updateData.faqs = Array.isArray(product.faqs) ? product.faqs : [];
    if (product.authorBio !== undefined) updateData.authorBio = product.authorBio.slice(0, 2048);
    if (product.guaranteeText !== undefined) updateData.guaranteeText = product.guaranteeText.slice(0, 1024);
    if (product.popular !== undefined) updateData.popular = !!product.popular;
    if (product.featured !== undefined) updateData.featured = !!product.featured;

    await updateDoc(productDocRef, updateData);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteProductInFirestore(id: string): Promise<void> {
  const path = `products/${id}`;
  try {
    await deleteDoc(doc(db, 'products', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function seedDefaultProductsInFirestore(): Promise<void> {
  for (const prod of PRODUCTS_DATA) {
    await createProductInFirestore({
      id: prod.id,
      slug: prod.id,
      title: prod.title,
      category: prod.category,
      categoryLabel: prod.categoryLabel,
      tagline: prod.tagline,
      description: prod.description,
      fullDescription: prod.fullDescription || prod.description,
      priceINR: prod.priceINR,
      originalPriceINR: prod.originalPriceINR,
      badge: prod.badge,
      rating: prod.rating,
      reviewsCount: prod.reviewsCount,
      format: prod.format,
      difficulty: prod.difficulty,
      imageUrl: prod.imageUrl || '',
      pdfUrl: prod.pdfUrl || '',
      pdfFileName: prod.pdfFileName || `${prod.id}.pdf`,
      samplePreviewTitle: prod.samplePreviewTitle,
      samplePreviewContent: prod.samplePreviewContent,
      deliverables: prod.deliverables || [],
      learningPoints: prod.learningPoints || [],
      targetAudience: prod.targetAudience || [],
      popular: prod.popular,
      featured: prod.featured,
    });
  }
}

// ----------------------------------------------------------------------
// BUNDLES FIRESTORE SERVICES (Dynamic High-Value Bundles)
// ----------------------------------------------------------------------

export function subscribeToBundles(onUpdate: (bundles: Bundle[]) => void): () => void {
  const path = 'bundles';
  try {
    const q = query(collection(db, 'bundles'));
    return onSnapshot(
      q,
      (snapshot) => {
        if (snapshot.empty) {
          onUpdate(BUNDLES_DATA);
        } else {
          const list: Bundle[] = [];
          snapshot.forEach((docSnap) => {
            const data = docSnap.data();
            list.push({
              id: docSnap.id,
              slug: data.slug || docSnap.id,
              title: data.title || 'Untitled Bundle',
              subtitle: data.subtitle || '',
              badge: data.badge || 'SPECIAL BUNDLE',
              badgeType: (data.badgeType as any) || 'popular',
              priceINR: typeof data.priceINR === 'number' ? data.priceINR : 2999,
              originalPriceINR: typeof data.originalPriceINR === 'number' ? data.originalPriceINR : 6999,
              savingsPercent: typeof data.savingsPercent === 'number' ? data.savingsPercent : 50,
              features: Array.isArray(data.features) ? data.features : [],
              includedProducts: Array.isArray(data.includedProducts) ? data.includedProducts : [],
              deliverables: Array.isArray(data.deliverables) ? data.deliverables : [],
              curriculum: Array.isArray(data.curriculum) ? data.curriculum : [],
              targetAudience: Array.isArray(data.targetAudience) ? data.targetAudience : [],
              bonuses: Array.isArray(data.bonuses) ? data.bonuses : [],
              faqs: Array.isArray(data.faqs) ? data.faqs : [],
              imageUrl: data.imageUrl || '',
              paymentLink: data.paymentLink || '',
              fullDescription: data.fullDescription || '',
              pdfUrl: data.pdfUrl || '',
              pdfFileName: data.pdfFileName || '',
              updatedAt: data.updatedAt,
            });
          });
          onUpdate(list);
        }
      },
      (error) => {
        console.warn('Falling back to local bundles data:', error);
        onUpdate(BUNDLES_DATA);
        handleFirestoreError(error, OperationType.LIST, path);
      }
    );
  } catch (error) {
    onUpdate(BUNDLES_DATA);
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function createBundleInFirestore(bundle: Partial<Bundle>): Promise<string> {
  const id = bundle.id || `bundle_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  const path = `bundles/${id}`;

  try {
    const bundleDocRef = doc(db, 'bundles', id);
    const dataToSave: Record<string, any> = {
      id,
      slug: bundle.slug || id,
      title: (bundle.title || 'New Bundle Pack').slice(0, 256),
      subtitle: (bundle.subtitle || '').slice(0, 512),
      badge: (bundle.badge || 'POPULAR BUNDLE').slice(0, 64),
      badgeType: bundle.badgeType || 'popular',
      priceINR: bundle.priceINR !== undefined ? Number(bundle.priceINR) : 2999,
      originalPriceINR: bundle.originalPriceINR !== undefined ? Number(bundle.originalPriceINR) : 6999,
      savingsPercent: bundle.savingsPercent !== undefined ? Number(bundle.savingsPercent) : 55,
      features: Array.isArray(bundle.features) ? bundle.features : [],
      includedProducts: Array.isArray(bundle.includedProducts) ? bundle.includedProducts : [],
      deliverables: Array.isArray(bundle.deliverables) ? bundle.deliverables : [],
      curriculum: Array.isArray(bundle.curriculum) ? bundle.curriculum : [],
      targetAudience: Array.isArray(bundle.targetAudience) ? bundle.targetAudience : [],
      bonuses: Array.isArray(bundle.bonuses) ? bundle.bonuses : [],
      faqs: Array.isArray(bundle.faqs) ? bundle.faqs : [],
      imageUrl: (bundle.imageUrl || '').slice(0, 2048),
      paymentLink: (bundle.paymentLink || '').slice(0, 2048),
      fullDescription: (bundle.fullDescription || '').slice(0, 25000),
      pdfUrl: (bundle.pdfUrl || '').slice(0, 2048),
      pdfFileName: (bundle.pdfFileName || '').slice(0, 256),
      updatedAt: new Date().toISOString(),
    };

    await setDoc(bundleDocRef, dataToSave);
    return id;
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateBundleInFirestore(id: string, bundle: Partial<Bundle>): Promise<void> {
  const path = `bundles/${id}`;
  try {
    const bundleDocRef = doc(db, 'bundles', id);
    const updateData: Record<string, any> = {
      updatedAt: new Date().toISOString(),
    };

    if (bundle.title !== undefined) updateData.title = bundle.title.slice(0, 256);
    if (bundle.slug !== undefined) updateData.slug = bundle.slug.slice(0, 128);
    if (bundle.subtitle !== undefined) updateData.subtitle = bundle.subtitle.slice(0, 512);
    if (bundle.badge !== undefined) updateData.badge = bundle.badge.slice(0, 64);
    if (bundle.badgeType !== undefined) updateData.badgeType = bundle.badgeType;
    if (bundle.priceINR !== undefined) updateData.priceINR = Number(bundle.priceINR);
    if (bundle.originalPriceINR !== undefined) updateData.originalPriceINR = Number(bundle.originalPriceINR);
    if (bundle.savingsPercent !== undefined) updateData.savingsPercent = Number(bundle.savingsPercent);
    if (bundle.features !== undefined) updateData.features = Array.isArray(bundle.features) ? bundle.features : [];
    if (bundle.includedProducts !== undefined) updateData.includedProducts = Array.isArray(bundle.includedProducts) ? bundle.includedProducts : [];
    if (bundle.deliverables !== undefined) updateData.deliverables = Array.isArray(bundle.deliverables) ? bundle.deliverables : [];
    if (bundle.curriculum !== undefined) updateData.curriculum = Array.isArray(bundle.curriculum) ? bundle.curriculum : [];
    if (bundle.targetAudience !== undefined) updateData.targetAudience = Array.isArray(bundle.targetAudience) ? bundle.targetAudience : [];
    if (bundle.bonuses !== undefined) updateData.bonuses = Array.isArray(bundle.bonuses) ? bundle.bonuses : [];
    if (bundle.faqs !== undefined) updateData.faqs = Array.isArray(bundle.faqs) ? bundle.faqs : [];
    if (bundle.imageUrl !== undefined) updateData.imageUrl = bundle.imageUrl.slice(0, 2048);
    if (bundle.paymentLink !== undefined) updateData.paymentLink = bundle.paymentLink.slice(0, 2048);
    if (bundle.fullDescription !== undefined) updateData.fullDescription = bundle.fullDescription.slice(0, 25000);
    if (bundle.pdfUrl !== undefined) updateData.pdfUrl = bundle.pdfUrl.slice(0, 2048);
    if (bundle.pdfFileName !== undefined) updateData.pdfFileName = bundle.pdfFileName.slice(0, 256);

    await updateDoc(bundleDocRef, updateData);
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteBundleInFirestore(id: string): Promise<void> {
  const path = `bundles/${id}`;
  try {
    await deleteDoc(doc(db, 'bundles', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function seedDefaultBundlesInFirestore(): Promise<void> {
  for (const b of BUNDLES_DATA) {
    await createBundleInFirestore(b);
  }
}

// ----------------------------------------------------------------------
// PAYMENT GATEWAY & RAZORPAY SETTINGS SERVICES
// ----------------------------------------------------------------------

export const DEFAULT_PAYMENT_SETTINGS: PaymentGatewaySettings = {
  defaultRazorpayUrl: '',
  razorpayKeyId: '',
  merchantUpiId: '',
  merchantName: 'ApexAI Technologies',
  directRedirectOnAccess: false,
  resendApiKey: '',
  notificationWebhookUrl: '',
  senderEmail: 'orders@apexai.tools',
};

export function subscribeToPaymentSettings(onUpdate: (settings: PaymentGatewaySettings) => void): () => void {
  const path = 'settings/payment';
  try {
    const docRef = doc(db, 'settings', 'payment');
    return onSnapshot(
      docRef,
      (snapshot) => {
        if (snapshot.exists()) {
          const data = snapshot.data();
          onUpdate({
            defaultRazorpayUrl: data.defaultRazorpayUrl || '',
            razorpayKeyId: data.razorpayKeyId || '',
            merchantUpiId: data.merchantUpiId || '',
            merchantName: data.merchantName || 'ApexAI Technologies',
            directRedirectOnAccess: !!data.directRedirectOnAccess,
            resendApiKey: data.resendApiKey || '',
            notificationWebhookUrl: data.notificationWebhookUrl || '',
            senderEmail: data.senderEmail || 'orders@apexai.tools',
            updatedAt: data.updatedAt,
          });
        } else {
          // fallback to localStorage or default
          const local = typeof window !== 'undefined' ? localStorage.getItem('apex_payment_settings') : null;
          if (local) {
            try {
              onUpdate(JSON.parse(local));
            } catch {
              onUpdate(DEFAULT_PAYMENT_SETTINGS);
            }
          } else {
            onUpdate(DEFAULT_PAYMENT_SETTINGS);
          }
        }
      },
      (error) => {
        console.warn('Error reading payment settings from Firestore:', error);
        const local = typeof window !== 'undefined' ? localStorage.getItem('apex_payment_settings') : null;
        if (local) {
          try {
            onUpdate(JSON.parse(local));
          } catch {
            onUpdate(DEFAULT_PAYMENT_SETTINGS);
          }
        } else {
          onUpdate(DEFAULT_PAYMENT_SETTINGS);
        }
      }
    );
  } catch (error) {
    onUpdate(DEFAULT_PAYMENT_SETTINGS);
    return () => {};
  }
}

export async function savePaymentSettingsToFirestore(settings: PaymentGatewaySettings): Promise<void> {
  const path = 'settings/payment';
  // Always save to localStorage immediately for instant offline reliability
  if (typeof window !== 'undefined') {
    localStorage.setItem('apex_payment_settings', JSON.stringify(settings));
  }

  try {
    const docRef = doc(db, 'settings', 'payment');
    await setDoc(docRef, {
      ...settings,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    console.warn('Saved payment settings locally. Firestore sync note:', error);
  }
}

// Automated Order Email Notification Dispatcher
export async function sendAutomatedOrderEmail(params: {
  toEmail: string;
  customerName: string;
  productTitle: string;
  orderId: string;
  totalPaid: number;
  pdfUrl?: string;
  settings?: PaymentGatewaySettings;
}): Promise<{ success: boolean; message: string }> {
  const settings = params.settings || DEFAULT_PAYMENT_SETTINGS;
  const directLink = params.pdfUrl || window.location.origin;

  // 1. If Resend API Key is configured in CMS
  if (settings.resendApiKey && settings.resendApiKey.trim().startsWith('re_')) {
    try {
      const response = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${settings.resendApiKey.trim()}`,
        },
        body: JSON.stringify({
          from: settings.senderEmail || 'onboarding@resend.dev',
          to: [params.toEmail],
          subject: `[Verified Download] Your access to ${params.productTitle} (#${params.orderId})`,
          html: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e2e8f0; border-radius: 12px; background: #ffffff;">
              <div style="text-align: center; margin-bottom: 24px;">
                <h1 style="color: #2563eb; margin: 0; font-size: 24px; font-weight: 800;">ApexAI Workkits</h1>
                <p style="color: #64748b; font-size: 13px; margin-top: 4px;">Official Digital Delivery &amp; Receipt</p>
              </div>
              <div style="background: #f8fafc; padding: 16px; border-radius: 8px; margin-bottom: 20px;">
                <p style="margin: 0 0 8px 0; font-size: 14px; color: #334155;">Hello <strong>${params.customerName}</strong>,</p>
                <p style="margin: 0; font-size: 14px; color: #334155;">Your payment of <strong>₹${params.totalPaid}</strong> has been verified. You have lifetime access to your digital PDF deliverable.</p>
              </div>
              <div style="border-left: 4px solid #10b981; padding: 12px 16px; background: #ecfdf5; margin-bottom: 24px; border-radius: 4px;">
                <p style="margin: 0; font-size: 12px; color: #065f46; font-weight: bold; text-transform: uppercase;">Product Deliverable</p>
                <p style="margin: 4px 0 0 0; font-size: 16px; color: #047857; font-weight: 800;">${params.productTitle}</p>
                <p style="margin: 4px 0 0 0; font-size: 12px; color: #047857;">Order ID: #${params.orderId}</p>
              </div>
              <div style="text-align: center; margin-bottom: 24px;">
                <a href="${directLink}" target="_blank" style="display: inline-block; background: #2563eb; color: #ffffff; text-decoration: none; padding: 14px 28px; border-radius: 8px; font-weight: bold; font-size: 15px; box-shadow: 0 4px 6px -1px rgba(37,99,235,0.3);">
                  Download Your Official PDF
                </a>
              </div>
              <p style="font-size: 12px; color: #94a3b8; text-align: center; margin-top: 20px;">
                You can also access your purchases anytime by clicking "My Downloads" on the ApexAI website using email: ${params.toEmail}.
              </p>
            </div>
          `,
        }),
      });
      if (response.ok) {
        return { success: true, message: 'Automated email successfully delivered via Resend!' };
      }
    } catch (e) {
      console.warn('Resend API dispatch notice:', e);
    }
  }

  // 2. If Custom Webhook URL is configured (Zapier/Make/Pabbly)
  if (settings.notificationWebhookUrl && settings.notificationWebhookUrl.trim().startsWith('http')) {
    try {
      await fetch(settings.notificationWebhookUrl.trim(), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          event: 'order_completed',
          orderId: params.orderId,
          customerEmail: params.toEmail,
          customerName: params.customerName,
          productTitle: params.productTitle,
          totalPaid: params.totalPaid,
          pdfUrl: params.pdfUrl,
          downloadLink: directLink,
          timestamp: new Date().toISOString(),
        }),
      });
      return { success: true, message: 'Automated notification posted to Webhook!' };
    } catch (e) {
      console.warn('Webhook dispatch notice:', e);
    }
  }

  return { success: false, message: 'No automated email service configured in CMS settings yet.' };
}
