import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  User,
  signInWithPopup,
  GoogleAuthProvider,
  signOut,
  onAuthStateChanged,
} from 'firebase/auth';
import { auth } from './config';
import {
  syncUserProfile,
  subscribeToUserOrders,
  subscribeToSavedItems,
  toggleSaveProduct,
  subscribeToBlogPosts,
  createBlogPostInFirestore,
  updateBlogPostInFirestore,
  deleteBlogPostInFirestore,
  seedDefaultBlogPostsInFirestore,
  subscribeToProducts,
  createProductInFirestore,
  updateProductInFirestore,
  deleteProductInFirestore,
  seedDefaultProductsInFirestore,
  subscribeToBundles,
  createBundleInFirestore,
  updateBundleInFirestore,
  deleteBundleInFirestore,
  seedDefaultBundlesInFirestore,
  subscribeToPaymentSettings,
  savePaymentSettingsToFirestore,
  DEFAULT_PAYMENT_SETTINGS,
  FirestoreOrder,
  FirestoreSavedItem,
} from './services';
import { BlogPost, Product, Bundle, PaymentGatewaySettings } from '../types';

export const ADMIN_EMAIL = 'dipakprajapati102@gmail.com';

interface FirebaseContextType {
  user: User | null;
  loading: boolean;
  isAdmin: boolean;
  orders: FirestoreOrder[];
  savedItems: FirestoreSavedItem[];
  blogPosts: BlogPost[];
  loadingBlogs: boolean;
  products: Product[];
  loadingProducts: boolean;
  bundles: Bundle[];
  loadingBundles: boolean;
  paymentSettings: PaymentGatewaySettings;
  updatePaymentSettings: (settings: PaymentGatewaySettings) => Promise<void>;
  purchasedProductIds: string[];
  markProductPurchased: (productId: string) => void;
  signInWithGoogle: () => Promise<void>;
  signOutUser: () => Promise<void>;
  toggleBookmark: (productId: string, productTitle: string) => Promise<void>;
  isBookmarked: (productId: string) => boolean;
  createBlog: (post: {
    id?: string;
    title: string;
    category: string;
    readTime: string;
    date?: string;
    excerpt: string;
    content: string | string[];
    keyTakeaways?: string | string[];
    author?: string;
    imageUrl?: string;
    tags?: string;
    featured?: boolean;
    slug?: string;
  }) => Promise<string>;
  updateBlog: (
    id: string,
    post: {
      title?: string;
      category?: string;
      readTime?: string;
      date?: string;
      excerpt?: string;
      content?: string | string[];
      keyTakeaways?: string | string[];
      author?: string;
      imageUrl?: string;
      tags?: string;
      featured?: boolean;
      slug?: string;
    }
  ) => Promise<void>;
  deleteBlog: (id: string) => Promise<void>;
  seedBlogs: () => Promise<void>;
  createProduct: (product: Partial<Product>) => Promise<string>;
  updateProduct: (id: string, product: Partial<Product>) => Promise<void>;
  deleteProduct: (id: string) => Promise<void>;
  seedProducts: () => Promise<void>;
  createBundle: (bundle: Partial<Bundle>) => Promise<string>;
  updateBundle: (id: string, bundle: Partial<Bundle>) => Promise<void>;
  deleteBundle: (id: string) => Promise<void>;
  seedBundles: () => Promise<void>;
}

const FirebaseContext = createContext<FirebaseContextType | undefined>(undefined);

export const FirebaseProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [orders, setOrders] = useState<FirestoreOrder[]>([]);
  const [savedItems, setSavedItems] = useState<FirestoreSavedItem[]>([]);
  const [blogPosts, setBlogPosts] = useState<BlogPost[]>([]);
  const [loadingBlogs, setLoadingBlogs] = useState(true);
  const [products, setProducts] = useState<Product[]>([]);
  const [loadingProducts, setLoadingProducts] = useState(true);
  const [bundles, setBundles] = useState<Bundle[]>([]);
  const [loadingBundles, setLoadingBundles] = useState(true);
  const [paymentSettings, setPaymentSettings] = useState<PaymentGatewaySettings>(() => {
    try {
      const stored = localStorage.getItem('apex_payment_settings');
      return stored ? JSON.parse(stored) : DEFAULT_PAYMENT_SETTINGS;
    } catch {
      return DEFAULT_PAYMENT_SETTINGS;
    }
  });
  const [purchasedProductIds, setPurchasedProductIds] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('apex_purchased_products');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  const isAdmin = !!(user && user.email && user.email.toLowerCase() === ADMIN_EMAIL.toLowerCase());

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      setLoading(false);

      if (currentUser) {
        // Sync profile to Firestore
        try {
          await syncUserProfile(currentUser);
        } catch (err) {
          console.error('Error syncing user profile:', err);
        }
      } else {
        setOrders([]);
        setSavedItems([]);
      }
    });

    return () => unsubscribeAuth();
  }, []);

  // Subscribe to dynamic blog posts globally
  useEffect(() => {
    setLoadingBlogs(true);
    const unsubscribeBlogs = subscribeToBlogPosts((posts) => {
      setBlogPosts(posts);
      setLoadingBlogs(false);
    });

    return () => {
      if (unsubscribeBlogs) unsubscribeBlogs();
    };
  }, []);

  // Subscribe to dynamic products globally
  useEffect(() => {
    setLoadingProducts(true);
    const unsubscribeProducts = subscribeToProducts((prods) => {
      setProducts(prods);
      setLoadingProducts(false);
    });

    return () => {
      if (unsubscribeProducts) unsubscribeProducts();
    };
  }, []);

  // Subscribe to dynamic bundles globally
  useEffect(() => {
    setLoadingBundles(true);
    const unsubscribeBundles = subscribeToBundles((b) => {
      setBundles(b);
      setLoadingBundles(false);
    });

    return () => {
      if (unsubscribeBundles) unsubscribeBundles();
    };
  }, []);

  // Subscribe to dynamic payment gateway settings globally
  useEffect(() => {
    const unsubscribePay = subscribeToPaymentSettings((settings) => {
      setPaymentSettings(settings);
    });

    return () => {
      if (unsubscribePay) unsubscribePay();
    };
  }, []);

  // Listen to orders and saved items when user logs in
  useEffect(() => {
    if (!user) return;

    const unsubscribeOrders = subscribeToUserOrders(user.uid, (data) => {
      setOrders(data);
      // Strictly derive purchased product IDs from user orders
      setPurchasedProductIds((prev) => {
        const merged = new Set(prev);
        data.forEach((order) => {
          if (order.productId) {
            merged.add(order.productId);
          }
          const orderTitleClean = order.productTitle.trim().toLowerCase();
          products.forEach((p) => {
            if (p.title.trim().toLowerCase() === orderTitleClean || p.id === order.productId) {
              merged.add(p.id);
            }
          });
          bundles.forEach((b) => {
            if (b.title.trim().toLowerCase() === orderTitleClean || b.id === order.productId) {
              merged.add(b.id);
            }
          });
        });
        const arr = Array.from(merged);
        try {
          localStorage.setItem('apex_purchased_products', JSON.stringify(arr));
        } catch {}
        return arr;
      });
    });

    const unsubscribeSaved = subscribeToSavedItems(user.uid, (data) => {
      setSavedItems(data);
    });

    return () => {
      if (unsubscribeOrders) unsubscribeOrders();
      if (unsubscribeSaved) unsubscribeSaved();
    };
  }, [user, products, bundles]);

  const markProductPurchased = (productId: string) => {
    setPurchasedProductIds((prev) => {
      if (!prev.includes(productId)) {
        const updated = [...prev, productId];
        try {
          localStorage.setItem('apex_purchased_products', JSON.stringify(updated));
        } catch {}
        return updated;
      }
      return prev;
    });
  };

  const signInWithGoogle = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (err: any) {
      if (err?.code !== 'auth/popup-closed-by-user') {
        console.error('Sign in error:', err);
      }
    }
  };

  const signOutUser = async () => {
    try {
      await signOut(auth);
    } catch (err) {
      console.error('Sign out error:', err);
    }
  };

  const toggleBookmark = async (productId: string, productTitle: string) => {
    if (!user) {
      await signInWithGoogle();
      return;
    }
    const existing = savedItems.find((item) => item.productId === productId);
    await toggleSaveProduct(user.uid, productId, productTitle, existing?.id);
  };

  const isBookmarked = (productId: string) => {
    return savedItems.some((item) => item.productId === productId);
  };

  const createBlog = async (post: Parameters<typeof createBlogPostInFirestore>[0]) => {
    return await createBlogPostInFirestore(post);
  };

  const updateBlog = async (id: string, post: Parameters<typeof updateBlogPostInFirestore>[1]) => {
    return await updateBlogPostInFirestore(id, post);
  };

  const deleteBlog = async (id: string) => {
    return await deleteBlogPostInFirestore(id);
  };

  const seedBlogs = async () => {
    return await seedDefaultBlogPostsInFirestore();
  };

  const createProduct = async (product: Parameters<typeof createProductInFirestore>[0]) => {
    return await createProductInFirestore(product);
  };

  const updateProduct = async (id: string, product: Parameters<typeof updateProductInFirestore>[1]) => {
    return await updateProductInFirestore(id, product);
  };

  const deleteProduct = async (id: string) => {
    return await deleteProductInFirestore(id);
  };

  const seedProducts = async () => {
    return await seedDefaultProductsInFirestore();
  };

  const createBundle = async (bundle: Parameters<typeof createBundleInFirestore>[0]) => {
    return await createBundleInFirestore(bundle);
  };

  const updateBundle = async (id: string, bundle: Parameters<typeof updateBundleInFirestore>[1]) => {
    return await updateBundleInFirestore(id, bundle);
  };

  const deleteBundle = async (id: string) => {
    return await deleteBundleInFirestore(id);
  };

  const seedBundles = async () => {
    return await seedDefaultBundlesInFirestore();
  };

  const updatePaymentSettings = async (settings: PaymentGatewaySettings) => {
    setPaymentSettings(settings);
    await savePaymentSettingsToFirestore(settings);
  };

  return (
    <FirebaseContext.Provider
      value={{
        user,
        loading,
        isAdmin,
        orders,
        savedItems,
        blogPosts,
        loadingBlogs,
        products,
        loadingProducts,
        bundles,
        loadingBundles,
        paymentSettings,
        updatePaymentSettings,
        purchasedProductIds,
        markProductPurchased,
        signInWithGoogle,
        signOutUser,
        toggleBookmark,
        isBookmarked,
        createBlog,
        updateBlog,
        deleteBlog,
        seedBlogs,
        createProduct,
        updateProduct,
        deleteProduct,
        seedProducts,
        createBundle,
        updateBundle,
        deleteBundle,
        seedBundles,
      }}
    >
      {children}
    </FirebaseContext.Provider>
  );
};

export const useFirebase = (): FirebaseContextType => {
  const context = useContext(FirebaseContext);
  if (!context) {
    throw new Error('useFirebase must be used within a FirebaseProvider');
  }
  return context;
};
