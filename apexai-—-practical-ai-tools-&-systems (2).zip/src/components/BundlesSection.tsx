import React from 'react';
import { Bundle } from '../types';
import { Sparkles, Check, ArrowRight, ShieldCheck, Zap } from 'lucide-react';

interface BundlesSectionProps {
  bundles: Bundle[];
  onOpenCheckoutForBundle: (bundle: Bundle) => void;
  onViewBundleDetails?: (bundle: Bundle) => void;
  onQuickViewBundle?: (bundle: Bundle) => void;
  onEditInCMS?: (bundleId: string) => void;
  currency: 'INR' | 'USD';
}

export const BundlesSection: React.FC<BundlesSectionProps> = ({
  bundles,
  onOpenCheckoutForBundle,
  onViewBundleDetails,
  onQuickViewBundle,
  onEditInCMS,
  currency,
}) => {
  const isOwnerVerified = typeof window !== 'undefined' && localStorage.getItem('apex_owner_verified') === 'true';

  const formatPrice = (inrPrice: number) => {
    if (currency === 'USD') {
      const usd = Math.round(inrPrice / 83);
      return `$${usd}`;
    }
    return `₹${inrPrice.toLocaleString('en-IN')}`;
  };

  return (
    <section id="bundles" className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="text-center max-w-2xl mx-auto mb-14">
        <span className="text-blue-600 text-xs font-extrabold uppercase tracking-widest flex items-center justify-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5" />
          MAXIMUM VALUE
        </span>
        <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-[#0F172A] mt-1">
          Complete AI Bundles & Toolkits
        </h2>
        <p className="mt-3 text-slate-600 text-base">
          Save more and get complete multi-product ecosystems built around your exact goals.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {bundles.map((bundle) => {
          const isFeatured = bundle.badgeType === 'popular' || bundle.badgeType === 'ultimate';
          return (
            <div
              key={bundle.id}
              id={`bundle-card-${bundle.id}`}
              className={`bg-white rounded-3xl p-8 flex flex-col justify-between relative transition-all hover:shadow-2xl ${
                isFeatured
                  ? 'border-2 border-blue-500 shadow-xl shadow-blue-500/10'
                  : 'border-2 border-blue-500/30 shadow-lg'
              }`}
            >
              {/* Savings Corner Tag */}
              <div className="absolute top-6 right-6">
                <span className="bg-emerald-600 text-white text-xs font-black px-3 py-1.5 rounded-full shadow-sm">
                  SAVE {bundle.savingsPercent}%
                </span>
              </div>

              <div>
                <span className="bg-blue-100 text-blue-700 text-xs font-extrabold px-3.5 py-1.5 rounded-full uppercase tracking-wider">
                  {bundle.badge}
                </span>

                <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-4 tracking-tight">
                  {bundle.title}
                </h3>

                <p className="mt-2 text-slate-600 text-sm leading-relaxed">
                  {bundle.subtitle}
                </p>

                {/* Features List */}
                <ul className="mt-6 space-y-3 text-sm text-slate-700 font-medium">
                  {bundle.features.map((feat, idx) => (
                    <li key={idx} className="flex items-start gap-2.5">
                      <div className="w-5 h-5 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center shrink-0 mt-0.5">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </div>
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>

                {/* What's Inside Pill Tags */}
                <div className="mt-6 pt-5 border-t border-slate-100">
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-wider block mb-2">
                    Included Toolkits:
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {bundle.includedProducts.map((prod, i) => (
                      <span
                        key={i}
                        className="bg-slate-100 text-slate-700 text-xs px-2.5 py-1 rounded-lg font-medium"
                      >
                        {prod}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Actions & Price */}
              <div className="mt-8 pt-6 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-400 line-through">
                      {formatPrice(bundle.originalPriceINR)}
                    </span>
                    <span className="text-[11px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded">
                      Lifetime Access
                    </span>
                  </div>
                  <div className="text-3xl font-extrabold text-slate-900">
                    {formatPrice(bundle.priceINR)}
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                  {onEditInCMS && isOwnerVerified && (
                    <button
                      type="button"
                      onClick={() => onEditInCMS(bundle.id)}
                      className="bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-300 px-3 py-2.5 rounded-xl font-bold text-xs transition cursor-pointer text-center"
                      title="Edit this high-value bundle in WordPress CMS"
                    >
                      ✏️ Edit CMS
                    </button>
                  )}
                  {onQuickViewBundle && (
                    <button
                      type="button"
                      onClick={() => onQuickViewBundle(bundle)}
                      className="bg-slate-100 hover:bg-slate-200 text-slate-700 px-3.5 py-2.5 rounded-xl font-bold text-xs transition cursor-pointer text-center"
                    >
                      Quick Preview
                    </button>
                  )}
                  {onViewBundleDetails && (
                    <button
                      type="button"
                      onClick={() => onViewBundleDetails(bundle)}
                      className="bg-blue-50 hover:bg-blue-100 text-blue-700 px-3.5 py-2.5 rounded-xl font-bold text-xs transition cursor-pointer text-center"
                    >
                      Landing Page
                    </button>
                  )}
                  <button
                    id={`bundle-checkout-btn-${bundle.id}`}
                    onClick={() => onOpenCheckoutForBundle(bundle)}
                    className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-xl font-bold text-xs transition shadow-md shadow-blue-500/20 flex items-center justify-center gap-1.5 active:scale-95 cursor-pointer"
                  >
                    <span>Get Bundle</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
