import React from 'react';
import { Bundle } from '../types';
import { X, Sparkles, Check, ArrowRight, ShieldCheck, Layers, FileText } from 'lucide-react';

interface BundleDetailModalProps {
  bundle: Bundle | null;
  onClose: () => void;
  onViewDetails: (bundle: Bundle) => void;
  onProceedToCheckout: (bundle: Bundle) => void;
  currency: 'INR' | 'USD';
}

export const BundleDetailModal: React.FC<BundleDetailModalProps> = ({
  bundle,
  onClose,
  onViewDetails,
  onProceedToCheckout,
  currency,
}) => {
  if (!bundle) return null;

  const formatPrice = (inrPrice: number) => {
    if (currency === 'USD') {
      const usd = Math.round(inrPrice / 83);
      return `$${usd < 1 ? 1 : usd}`;
    }
    return `₹${inrPrice.toLocaleString('en-IN')}`;
  };

  return (
    <div
      id="bundle-quickview-modal"
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-fadeIn"
    >
      <div className="bg-slate-900 text-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 relative shadow-2xl my-8 max-h-[92vh] overflow-y-auto border border-slate-800">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-6 right-6 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-full w-9 h-9 flex items-center justify-center text-lg font-bold transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Top Badge & Title */}
        <div className="flex items-center gap-2 mb-3">
          <span className="bg-blue-600/30 border border-blue-500/50 text-blue-400 text-xs font-black px-3 py-1 rounded-full uppercase tracking-wider flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{bundle.badge || 'MEGA VALUE BUNDLE'}</span>
          </span>
          <span className="bg-emerald-500/20 text-emerald-400 text-xs font-extrabold px-3 py-1 rounded-full">
            SAVE {bundle.savingsPercent}%
          </span>
        </div>

        <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white">
          {bundle.title}
        </h2>
        <p className="mt-2 text-slate-400 text-sm leading-relaxed">
          {bundle.subtitle}
        </p>

        {/* Key Features Quick Preview */}
        <div className="mt-6 bg-slate-950 p-5 rounded-2xl border border-slate-800/80">
          <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">
            What You Get Inside This High-Value Pack:
          </h4>
          <ul className="space-y-2.5">
            {bundle.features.map((feat, idx) => (
              <li key={idx} className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-300 font-medium">
                <div className="w-4 h-4 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0 mt-0.5">
                  <Check className="w-3 h-3 stroke-[3]" />
                </div>
                <span>{feat}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Included Products Mini Pills */}
        <div className="mt-5">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block mb-2">
            Included Product Ecosystems:
          </span>
          <div className="flex flex-wrap gap-1.5">
            {bundle.includedProducts.map((p, i) => (
              <span
                key={i}
                className="bg-slate-800 text-slate-200 text-xs px-3 py-1 rounded-lg border border-slate-700/60 font-medium"
              >
                {p}
              </span>
            ))}
          </div>
        </div>

        {/* Pricing & Footer Actions */}
        <div className="mt-8 pt-6 border-t border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500 line-through">
                {formatPrice(bundle.originalPriceINR)}
              </span>
              <span className="text-xs font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded">
                Save {bundle.savingsPercent}%
              </span>
            </div>
            <div className="text-3xl font-black text-white">
              {formatPrice(bundle.priceINR)}
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-2.5">
            <button
              onClick={onClose}
              className="bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white px-4 py-3 rounded-xl font-bold text-xs transition cursor-pointer"
            >
              Continue Browsing
            </button>
            <button
              onClick={() => {
                onViewDetails(bundle);
                onClose();
              }}
              className="bg-slate-700 hover:bg-slate-600 text-white px-4 py-3 rounded-xl font-bold text-xs transition flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <span>View Full Details Page</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => {
                onProceedToCheckout(bundle);
                onClose();
              }}
              className="bg-blue-600 hover:bg-blue-500 text-white px-6 py-3 rounded-xl font-bold text-xs sm:text-sm transition shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 cursor-pointer active:scale-95"
            >
              <span>Get the Bundle</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
