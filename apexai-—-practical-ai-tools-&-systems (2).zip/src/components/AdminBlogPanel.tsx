import React, { useState, useMemo } from 'react';
import { useFirebase, ADMIN_EMAIL } from '../firebase/context';
import { BlogPost } from '../types';
import {
  X,
  Plus,
  Edit3,
  Trash2,
  Eye,
  Search,
  CheckCircle2,
  AlertCircle,
  FileText,
  Clock,
  UserCheck,
  RotateCcw,
  Shield,
  Image as ImageIcon,
  Link as LinkIcon,
  Sparkles,
  Heading2,
  Heading3,
  Bold,
  List,
  Quote,
  Code,
  Globe,
  Check,
} from 'lucide-react';

interface AdminBlogPanelProps {
  isOpen: boolean;
  onClose: () => void;
  onPreviewPost: (post: BlogPost) => void;
}

const IMAGE_PRESETS = [
  {
    name: 'AI Business & Office',
    url: 'https://images.unsplash.com/photo-1551836022-d5d88e9218df?auto=format&fit=crop&w=1200&q=80',
  },
  {
    name: 'Automation & Hardware',
    url: 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=1200&q=80',
  },
  {
    name: 'Modern Tech Workspace',
    url: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=1200&q=80',
  },
  {
    name: 'Data & Growth Marketing',
    url: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1200&q=80',
  },
  {
    name: 'Code, AI & Algorithms',
    url: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=1200&q=80',
  },
];

export const AdminBlogPanel: React.FC<AdminBlogPanelProps> = ({
  isOpen,
  onClose,
  onPreviewPost,
}) => {
  const {
    user,
    isAdmin,
    blogPosts,
    loadingBlogs,
    signInWithGoogle,
    signOutUser,
    createBlog,
    updateBlog,
    deleteBlog,
    seedBlogs,
  } = useFirebase();

  // Mode: 'list' | 'create' | 'edit'
  const [viewMode, setViewMode] = useState<'list' | 'create' | 'edit'>('list');
  const [editingPostId, setEditingPostId] = useState<string | null>(null);

  // Form State
  const [formTitle, setFormTitle] = useState('');
  const [formSlug, setFormSlug] = useState('');
  const [formImageUrl, setFormImageUrl] = useState('');
  const [formCategory, setFormCategory] = useState('AI Business');
  const [formReadTime, setFormReadTime] = useState('6 min read');
  const [formAuthor, setFormAuthor] = useState('Dipak Prajapati');
  const [formExcerpt, setFormExcerpt] = useState('');
  const [formContent, setFormContent] = useState('');
  const [formTakeaways, setFormTakeaways] = useState('');
  const [formTags, setFormTags] = useState('AI, Business, Automation');
  const [formFeatured, setFormFeatured] = useState(false);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // UI state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; message: string } | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
  const [editorTab, setEditorTab] = useState<'editor' | 'seo' | 'preview'>('editor');

  const showNotification = (type: 'success' | 'error', message: string) => {
    setNotification({ type, message });
    setTimeout(() => setNotification(null), 3500);
  };

  const handleTitleChange = (val: string) => {
    setFormTitle(val);
    if (viewMode === 'create') {
      const slug = val
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/(^-|-$)/g, '');
      setFormSlug(slug);
    }
  };

  // Auto-calculate word count and reading time
  const wordCount = useMemo(() => {
    const text = formContent.trim();
    if (!text) return 0;
    return text.split(/\s+/).filter(Boolean).length;
  }, [formContent]);

  const handleAutoCalcReadTime = () => {
    const words = wordCount;
    const minutes = Math.max(1, Math.ceil(words / 180));
    setFormReadTime(`${minutes} min read`);
    showNotification('success', `Calculated: ${minutes} min read (${words} words)`);
  };

  // Helper to insert formatting snippets into content
  const insertFormatting = (prefix: string, suffix: string = '') => {
    const textarea = document.getElementById('blog-content-textarea') as HTMLTextAreaElement | null;
    if (!textarea) {
      setFormContent((prev) => prev + `\n\n${prefix}Sample Text${suffix}`);
      return;
    }

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = formContent.substring(start, end) || 'Heading Text';
    const replacement = `${prefix}${selectedText}${suffix}`;

    const newContent = formContent.substring(0, start) + replacement + formContent.substring(end);
    setFormContent(newContent);

    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + prefix.length, start + prefix.length + selectedText.length);
    }, 50);
  };

  const resetForm = () => {
    setFormTitle('');
    setFormSlug('');
    setFormImageUrl('');
    setFormCategory('AI Business');
    setFormReadTime('6 min read');
    setFormAuthor('Dipak Prajapati');
    setFormExcerpt('');
    setFormContent('');
    setFormTakeaways('');
    setFormTags('AI, Business, Automation');
    setFormFeatured(false);
    setEditingPostId(null);
    setEditorTab('editor');
  };

  const startCreate = () => {
    resetForm();
    setViewMode('create');
  };

  const startEdit = (post: BlogPost) => {
    setEditingPostId(post.id);
    setFormTitle(post.title);
    setFormSlug(post.slug || post.id);
    setFormImageUrl(post.imageUrl || '');
    setFormCategory(post.category);
    setFormReadTime(post.readTime);
    setFormAuthor(post.author || 'Dipak Prajapati');
    setFormExcerpt(post.excerpt);
    setFormContent(Array.isArray(post.content) ? post.content.join('\n\n') : post.content);
    setFormTakeaways(Array.isArray(post.keyTakeaways) ? post.keyTakeaways.join('\n') : (post.keyTakeaways || ''));
    setFormTags(post.tags || '');
    setFormFeatured(!!post.featured);
    setViewMode('edit');
    setEditorTab('editor');
  };

  const handleSubmitForm = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formTitle.trim() || !formContent.trim()) {
      showNotification('error', 'Title and Content are required.');
      return;
    }

    setIsSubmitting(true);
    try {
      const contentArray = formContent
        .split('\n\n')
        .map((p) => p.trim())
        .filter(Boolean);

      const takeawaysArray = formTakeaways
        .split('\n')
        .map((t) => t.trim())
        .filter(Boolean);

      const cleanSlug = formSlug.trim() || formTitle.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-');

      if (viewMode === 'create') {
        const generatedId = `post_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
        await createBlog({
          id: generatedId,
          slug: cleanSlug,
          title: formTitle.trim(),
          imageUrl: formImageUrl.trim(),
          category: formCategory,
          readTime: formReadTime,
          excerpt: formExcerpt.trim() || formTitle.trim(),
          content: contentArray,
          keyTakeaways: takeawaysArray,
          author: formAuthor.trim() || 'Dipak Prajapati',
          tags: formTags.trim(),
          featured: formFeatured,
          date: `Updated ${new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}`,
        });
        showNotification('success', 'Article published to live website!');
      } else if (viewMode === 'edit' && editingPostId) {
        await updateBlog(editingPostId, {
          title: formTitle.trim(),
          slug: cleanSlug,
          imageUrl: formImageUrl.trim(),
          category: formCategory,
          readTime: formReadTime,
          excerpt: formExcerpt.trim(),
          content: contentArray,
          keyTakeaways: takeawaysArray,
          author: formAuthor.trim() || 'Dipak Prajapati',
          tags: formTags.trim(),
          featured: formFeatured,
          date: `Updated ${new Date().toLocaleDateString('en-US', { month: 'short', year: 'numeric' })}`,
        });
        showNotification('success', 'Article updated successfully!');
      }
      setViewMode('list');
      resetForm();
    } catch (err: any) {
      console.error('Save blog error:', err);
      showNotification('error', err?.message || 'Failed to save blog post.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteBlog(id);
      showNotification('success', 'Article permanently deleted.');
      setDeleteConfirmId(null);
    } catch (err: any) {
      console.error('Delete error:', err);
      showNotification('error', 'Failed to delete post.');
    }
  };

  const handleSeedDefaults = async () => {
    if (!window.confirm('This will seed the master articles into Firestore. Continue?')) return;
    setIsSubmitting(true);
    try {
      await seedBlogs();
      showNotification('success', 'Default master articles seeded to Firestore!');
    } catch (err: any) {
      console.error('Seed error:', err);
      showNotification('error', 'Failed to seed sample blogs.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const filteredPosts = useMemo(() => {
    return blogPosts.filter((post) => {
      if (selectedCategory !== 'all' && post.category !== selectedCategory) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        return (
          post.title.toLowerCase().includes(q) ||
          post.excerpt.toLowerCase().includes(q) ||
          (post.tags && post.tags.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [blogPosts, selectedCategory, searchQuery]);

  const categories = ['all', 'AI Business', 'AI Side Hustles', 'Automation', 'Prompts & Productivity', 'Creator & Media'];

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 overflow-y-auto animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-5xl w-full p-6 sm:p-8 relative shadow-2xl my-6 max-h-[92vh] overflow-y-auto border border-slate-200 flex flex-col">
        {/* Header Bar */}
        <div className="flex items-start justify-between pb-5 border-b border-slate-100 gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-blue-600 text-white rounded-2xl flex items-center justify-center shadow-md shadow-blue-500/20 shrink-0">
              <Shield className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-black text-slate-900">
                  WordPress-Style Blog CMS &amp; Manager
                </h2>
                <span className="bg-blue-100 text-blue-800 text-[11px] font-extrabold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                  Admin Exclusive
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Authorized editor for <span className="font-semibold text-slate-700">{ADMIN_EMAIL}</span>. Write, update, attach images, and optimize for Google.
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-full w-9 h-9 flex items-center justify-center text-lg font-bold transition cursor-pointer shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Feedback Notification */}
        {notification && (
          <div
            className={`my-3 p-3.5 rounded-xl text-xs font-semibold flex items-center gap-2 transition animate-fadeIn ${
              notification.type === 'success'
                ? 'bg-emerald-50 text-emerald-800 border border-emerald-200'
                : 'bg-rose-50 text-rose-800 border border-rose-200'
            }`}
          >
            {notification.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <span>{notification.message}</span>
          </div>
        )}

        {/* Admin Authentication Gate */}
        {!user ? (
          <div className="my-auto py-12 text-center max-w-md mx-auto">
            <div className="w-16 h-16 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <Shield className="w-8 h-8" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">Dipak Prajapati - Owner Sign-In</h3>
            <p className="text-xs text-slate-500 mt-1 mb-6">
              Only the verified site owner (<span className="font-semibold text-slate-800">{ADMIN_EMAIL}</span>) can manage articles.
            </p>
            <button
              onClick={signInWithGoogle}
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm px-6 py-3 rounded-xl shadow-md transition flex items-center justify-center gap-2 mx-auto cursor-pointer"
            >
              <UserCheck className="w-4 h-4" />
              <span>Sign In with Admin Google Account</span>
            </button>
          </div>
        ) : !isAdmin ? (
          <div className="my-auto py-10 text-center max-w-md mx-auto bg-amber-50 rounded-2xl p-6 border border-amber-200">
            <AlertCircle className="w-10 h-10 text-amber-600 mx-auto mb-2" />
            <h3 className="text-base font-bold text-slate-900">Access Restricted</h3>
            <p className="text-xs text-slate-600 mt-1">
              Signed in as <span className="font-semibold">{user.email}</span>. Only the site owner has CMS access:
            </p>
            <div className="font-mono text-xs font-bold text-amber-800 bg-amber-100/80 py-1.5 px-3 rounded-lg my-3">
              {ADMIN_EMAIL}
            </div>
            <button
              onClick={async () => {
                await signOutUser();
                await signInWithGoogle();
              }}
              className="bg-slate-900 hover:bg-black text-white text-xs font-bold px-4 py-2 rounded-xl transition cursor-pointer"
            >
              Switch Account
            </button>
          </div>
        ) : (
          /* Logged In Admin View */
          <div className="flex-1 mt-4">
            {/* Top Stats Strip */}
            <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-50 p-3.5 rounded-2xl border border-slate-200 mb-6">
              <div className="flex items-center gap-4 text-xs">
                <div>
                  <span className="text-slate-400">Total Live Articles:</span>{' '}
                  <span className="font-bold text-slate-900">{blogPosts.length}</span>
                </div>
                <div className="h-3 w-px bg-slate-300" />
                <div>
                  <span className="text-slate-400">Admin:</span>{' '}
                  <span className="font-mono text-blue-600 font-bold">{user.email}</span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                {viewMode === 'list' ? (
                  <>
                    <button
                      onClick={handleSeedDefaults}
                      disabled={isSubmitting}
                      title="Seed Default AI Articles"
                      className="bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 text-xs font-semibold px-3 py-2 rounded-xl transition flex items-center gap-1.5 cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Re-seed Master Articles</span>
                    </button>
                    <button
                      onClick={startCreate}
                      className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-4 py-2 rounded-xl transition flex items-center gap-1.5 shadow-sm shadow-blue-500/20 cursor-pointer"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Write New Post</span>
                    </button>
                  </>
                ) : (
                  <button
                    onClick={() => {
                      setViewMode('list');
                      resetForm();
                    }}
                    className="bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 text-xs font-semibold px-3.5 py-2 rounded-xl transition cursor-pointer"
                  >
                    Back to All Articles
                  </button>
                )}
              </div>
            </div>

            {/* List View */}
            {viewMode === 'list' && (
              <div>
                {/* Search & Category Tabs */}
                <div className="flex flex-col sm:flex-row gap-3 items-center justify-between mb-4">
                  <div className="relative w-full sm:w-72">
                    <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search articles by title, tag..."
                      className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-slate-200 rounded-xl focus:outline-none focus:border-blue-600"
                    />
                  </div>

                  <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1">
                    {categories.map((cat) => (
                      <button
                        key={cat}
                        onClick={() => setSelectedCategory(cat)}
                        className={`text-xs px-3 py-1.5 rounded-lg whitespace-nowrap font-semibold transition cursor-pointer ${
                          selectedCategory === cat
                            ? 'bg-blue-600 text-white'
                            : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        }`}
                      >
                        {cat === 'all' ? 'All' : cat}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Table / Cards */}
                {loadingBlogs ? (
                  <div className="text-center py-12 text-slate-400 text-sm">
                    Connecting to Firestore &amp; streaming articles...
                  </div>
                ) : filteredPosts.length > 0 ? (
                  <div className="space-y-3">
                    {filteredPosts.map((post) => (
                      <div
                        key={post.id}
                        className="bg-white p-4 rounded-2xl border border-slate-200 hover:border-blue-300 transition flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-2xs"
                      >
                        {/* Thumbnail image if available */}
                        <div className="flex items-center gap-4 flex-1 min-w-0">
                          {post.imageUrl ? (
                            <div className="w-20 h-16 rounded-xl overflow-hidden bg-slate-900 shrink-0 border border-slate-200">
                              <img
                                src={post.imageUrl}
                                alt={post.title}
                                className="w-full h-full object-cover"
                              />
                            </div>
                          ) : (
                            <div className="w-20 h-16 rounded-xl bg-slate-100 border border-dashed border-slate-300 flex flex-col items-center justify-center text-slate-400 shrink-0">
                              <ImageIcon className="w-4 h-4" />
                              <span className="text-[9px] mt-0.5">No image</span>
                            </div>
                          )}

                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1 flex-wrap">
                              <span className="bg-blue-50 text-blue-700 text-[10px] font-extrabold px-2 py-0.5 rounded-full uppercase">
                                {post.category}
                              </span>
                              <span className="text-xs text-slate-400 flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {post.readTime}
                              </span>
                              <span className="text-xs text-slate-400">• {post.date}</span>
                              {post.featured && (
                                <span className="bg-amber-100 text-amber-800 text-[10px] font-bold px-1.5 py-0.5 rounded">
                                  Featured
                                </span>
                              )}
                              <span className="text-[10px] font-mono text-slate-400">
                                /{post.slug || post.id}
                              </span>
                            </div>

                            <h4 className="text-base font-bold text-slate-900 hover:text-blue-600 transition truncate">
                              {post.title}
                            </h4>
                            <p className="text-xs text-slate-500 line-clamp-1 mt-0.5">
                              {post.excerpt}
                            </p>
                          </div>
                        </div>

                        {/* Action Buttons */}
                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            onClick={() => onPreviewPost(post)}
                            title="View Full Page Article"
                            className="p-2 text-slate-600 hover:text-blue-600 bg-slate-100 hover:bg-blue-50 rounded-xl transition cursor-pointer"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => startEdit(post)}
                            title="Edit in CMS"
                            className="p-2 text-slate-600 hover:text-blue-600 bg-slate-100 hover:bg-blue-50 rounded-xl transition cursor-pointer"
                          >
                            <Edit3 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setDeleteConfirmId(post.id)}
                            title="Delete Article"
                            className="p-2 text-slate-600 hover:text-rose-600 bg-slate-100 hover:bg-rose-50 rounded-xl transition cursor-pointer"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12 bg-slate-50 rounded-2xl border border-slate-200">
                    <FileText className="w-8 h-8 text-slate-400 mx-auto mb-2" />
                    <p className="font-bold text-slate-700 text-sm">No articles match your criteria</p>
                    <p className="text-xs text-slate-500 mt-1">
                      Clear your search or click &quot;Write New Post&quot; to publish your first article.
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Create / Edit Form (WordPress Experience) */}
            {(viewMode === 'create' || viewMode === 'edit') && (
              <form onSubmit={handleSubmitForm} className="space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                  <h3 className="font-extrabold text-slate-900 text-base flex items-center gap-2">
                    <span>{viewMode === 'create' ? 'WordPress Post Editor' : 'Edit Post'}</span>
                    <span className="text-xs font-normal text-slate-400">
                      ({viewMode === 'create' ? 'Draft & Publish' : `ID: ${editingPostId}`})
                    </span>
                  </h3>

                  {/* Tabs: Editor vs SEO vs Live Preview */}
                  <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
                    <button
                      type="button"
                      onClick={() => setEditorTab('editor')}
                      className={`text-xs px-3 py-1 rounded-lg font-bold transition cursor-pointer ${
                        editorTab === 'editor' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500'
                      }`}
                    >
                      Article Content
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditorTab('seo')}
                      className={`text-xs px-3 py-1 rounded-lg font-bold transition cursor-pointer ${
                        editorTab === 'seo' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500'
                      }`}
                    >
                      Google SEO
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditorTab('preview')}
                      className={`text-xs px-3 py-1 rounded-lg font-bold transition cursor-pointer ${
                        editorTab === 'preview' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-500'
                      }`}
                    >
                      Reader Preview
                    </button>
                  </div>
                </div>

                {editorTab === 'editor' ? (
                  <div className="space-y-4">
                    {/* Title & Slug */}
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div className="sm:col-span-2">
                        <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                          Post Title *
                        </label>
                        <input
                          type="text"
                          required
                          value={formTitle}
                          onChange={(e) => handleTitleChange(e.target.value)}
                          placeholder="e.g. How to Build an AI Chatbot for Small Business"
                          className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm font-semibold text-slate-900 focus:outline-none focus:border-blue-600"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                          Permanent URL Slug (Google Indexable)
                        </label>
                        <input
                          type="text"
                          value={formSlug}
                          onChange={(e) => setFormSlug(e.target.value)}
                          placeholder="how-to-build-an-ai-chatbot..."
                          className="w-full bg-white border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs font-mono text-slate-700 focus:outline-none focus:border-blue-600"
                        />
                      </div>
                    </div>

                    {/* Blog Cover Image Section */}
                    <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
                      <div className="flex items-center justify-between">
                        <label className="block text-xs font-bold text-slate-800 uppercase flex items-center gap-1.5">
                          <ImageIcon className="w-4 h-4 text-blue-600" />
                          <span>Featured Cover Image URL</span>
                        </label>
                        <span className="text-[11px] text-slate-400">Direct image link (Unsplash, Imgur, Cloudinary)</span>
                      </div>

                      <div className="flex flex-col sm:flex-row gap-3">
                        <div className="relative flex-1">
                          <LinkIcon className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                          <input
                            type="url"
                            value={formImageUrl}
                            onChange={(e) => setFormImageUrl(e.target.value)}
                            placeholder="https://images.unsplash.com/... or paste image URL"
                            className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-slate-300 rounded-xl focus:outline-none focus:border-blue-600"
                          />
                        </div>

                        {formImageUrl && (
                          <button
                            type="button"
                            onClick={() => setFormImageUrl('')}
                            className="text-xs text-rose-600 hover:text-rose-700 font-semibold px-2 py-1 cursor-pointer"
                          >
                            Remove Image
                          </button>
                        )}
                      </div>

                      {/* Presets */}
                      <div className="flex items-center gap-2 flex-wrap pt-1">
                        <span className="text-[11px] font-semibold text-slate-500">Curated Presets:</span>
                        {IMAGE_PRESETS.map((preset) => (
                          <button
                            key={preset.name}
                            type="button"
                            onClick={() => setFormImageUrl(preset.url)}
                            className={`text-[11px] px-2.5 py-1 rounded-lg border font-medium transition cursor-pointer ${
                              formImageUrl === preset.url
                                ? 'bg-blue-600 text-white border-blue-600'
                                : 'bg-white border-slate-200 text-slate-700 hover:border-blue-400 hover:text-blue-600'
                            }`}
                          >
                            {preset.name}
                          </button>
                        ))}
                      </div>

                      {/* Live Image Preview in Editor */}
                      {formImageUrl && (
                        <div className="mt-2 relative w-full h-36 rounded-xl overflow-hidden bg-slate-900 border border-slate-200">
                          <img
                            src={formImageUrl}
                            alt="Cover Preview"
                            className="w-full h-full object-cover"
                            onError={(e) => {
                              e.currentTarget.style.display = 'none';
                            }}
                          />
                          <div className="absolute bottom-2 left-2 bg-black/60 backdrop-blur-xs text-white text-[10px] px-2 py-0.5 rounded font-mono">
                            Cover Image Active
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Metadata Grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                          Category
                        </label>
                        <select
                          value={formCategory}
                          onChange={(e) => setFormCategory(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-700 focus:outline-none focus:border-blue-600"
                        >
                          <option value="AI Business">AI Business</option>
                          <option value="AI Side Hustles">AI Side Hustles</option>
                          <option value="Automation">Automation</option>
                          <option value="Prompts &amp; Productivity">Prompts &amp; Productivity</option>
                          <option value="Creator &amp; Media">Creator &amp; Media</option>
                          <option value="Tutorials">Tutorials</option>
                        </select>
                      </div>

                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <label className="block text-xs font-bold text-slate-700 uppercase">
                            Read Time
                          </label>
                          <button
                            type="button"
                            onClick={handleAutoCalcReadTime}
                            className="text-[10px] text-blue-600 hover:underline font-bold"
                          >
                            Auto
                          </button>
                        </div>
                        <input
                          type="text"
                          value={formReadTime}
                          onChange={(e) => setFormReadTime(e.target.value)}
                          placeholder="e.g. 6 min read"
                          className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-700 focus:outline-none focus:border-blue-600"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                          Author Name
                        </label>
                        <input
                          type="text"
                          value={formAuthor}
                          onChange={(e) => setFormAuthor(e.target.value)}
                          placeholder="Dipak Prajapati"
                          className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-700 focus:outline-none focus:border-blue-600"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                          Tags (comma-separated)
                        </label>
                        <input
                          type="text"
                          value={formTags}
                          onChange={(e) => setFormTags(e.target.value)}
                          placeholder="AI, Automation, Side Hustle"
                          className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-700 focus:outline-none focus:border-blue-600"
                        />
                      </div>
                    </div>

                    {/* Excerpt */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                        Short Lead Excerpt (Shown on cards &amp; under post title) *
                      </label>
                      <textarea
                        required
                        rows={2}
                        value={formExcerpt}
                        onChange={(e) => setFormExcerpt(e.target.value)}
                        placeholder="A concise, high-impact summary of what the reader will discover in this article..."
                        className="w-full bg-white border border-slate-300 rounded-xl p-3 text-xs text-slate-800 focus:outline-none focus:border-blue-600"
                      />
                    </div>

                    {/* Key Takeaways */}
                    <div>
                      <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                        Key Actionable Takeaways (TL;DR box - 1 per line)
                      </label>
                      <textarea
                        rows={3}
                        value={formTakeaways}
                        onChange={(e) => setFormTakeaways(e.target.value)}
                        placeholder="Key point 1&#10;Key point 2&#10;Key point 3"
                        className="w-full bg-white border border-slate-300 rounded-xl p-3 text-xs text-slate-800 focus:outline-none focus:border-blue-600"
                      />
                    </div>

                    {/* WordPress-Style Post Body Editor */}
                    <div>
                      <div className="flex items-center justify-between mb-1.5 flex-wrap gap-2">
                        <label className="block text-xs font-bold text-slate-800 uppercase">
                          Article Body (Supports Headings, Quotes, Lists) *
                        </label>
                        <div className="text-[11px] text-slate-500 font-mono">
                          {wordCount} words • {formContent.length} chars
                        </div>
                      </div>

                      {/* Formatting Helper Toolbar */}
                      <div className="bg-slate-100 p-2 rounded-t-xl border border-b-0 border-slate-300 flex items-center gap-1.5 flex-wrap text-xs text-slate-700">
                        <button
                          type="button"
                          onClick={() => insertFormatting('## ')}
                          className="px-2 py-1 rounded bg-white hover:bg-slate-200 border border-slate-200 font-bold flex items-center gap-1 cursor-pointer"
                          title="H2 Main Heading"
                        >
                          <Heading2 className="w-3.5 h-3.5 text-blue-600" />
                          <span>H2</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => insertFormatting('### ')}
                          className="px-2 py-1 rounded bg-white hover:bg-slate-200 border border-slate-200 font-bold flex items-center gap-1 cursor-pointer"
                          title="H3 Subheading"
                        >
                          <Heading3 className="w-3.5 h-3.5 text-blue-600" />
                          <span>H3</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => insertFormatting('> ')}
                          className="px-2 py-1 rounded bg-white hover:bg-slate-200 border border-slate-200 font-bold flex items-center gap-1 cursor-pointer"
                          title="Quote block"
                        >
                          <Quote className="w-3.5 h-3.5 text-amber-600" />
                          <span>Quote</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => insertFormatting('* ')}
                          className="px-2 py-1 rounded bg-white hover:bg-slate-200 border border-slate-200 font-bold flex items-center gap-1 cursor-pointer"
                          title="Bullet list item"
                        >
                          <List className="w-3.5 h-3.5 text-emerald-600" />
                          <span>Bullet</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => insertFormatting('`', '`')}
                          className="px-2 py-1 rounded bg-white hover:bg-slate-200 border border-slate-200 font-mono text-[11px] flex items-center gap-1 cursor-pointer"
                          title="Inline Code / Prompt"
                        >
                          <Code className="w-3.5 h-3.5 text-indigo-600" />
                          <span>Code</span>
                        </button>
                      </div>

                      <textarea
                        id="blog-content-textarea"
                        required
                        rows={10}
                        value={formContent}
                        onChange={(e) => setFormContent(e.target.value)}
                        placeholder="## Introduction&#10;&#10;Write your opening paragraphs here...&#10;&#10;## Step 1: Actionable Strategy&#10;&#10;Explain step-by-step guidance...&#10;&#10;> Important insight or quote from industry experts&#10;&#10;## Summary & Next Steps"
                        className="w-full bg-white border border-slate-300 rounded-b-xl p-3.5 text-xs text-slate-800 focus:outline-none focus:border-blue-600 leading-relaxed font-sans"
                      />
                    </div>

                    {/* Featured Checkbox */}
                    <div className="flex items-center gap-2 pt-1">
                      <input
                        type="checkbox"
                        id="featured-checkbox"
                        checked={formFeatured}
                        onChange={(e) => setFormFeatured(e.target.checked)}
                        className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500 cursor-pointer"
                      />
                      <label htmlFor="featured-checkbox" className="text-xs font-semibold text-slate-700 cursor-pointer">
                        Feature this post in the homepage spotlight
                      </label>
                    </div>
                  </div>
                ) : editorTab === 'seo' ? (
                  /* Google SEO Tab */
                  <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200 space-y-6">
                    <div>
                      <h4 className="text-sm font-bold text-slate-900 flex items-center gap-1.5 mb-1">
                        <Globe className="w-4 h-4 text-blue-600" />
                        <span>Google Search Snippet Preview</span>
                      </h4>
                      <p className="text-xs text-slate-500 mb-4">
                        This is how your article appears when readers find it on Google.
                      </p>

                      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs max-w-xl">
                        <div className="flex items-center gap-1 text-xs text-slate-600 mb-1">
                          <span className="font-semibold">ApexAI</span>
                          <span>›</span>
                          <span className="text-emerald-700 font-mono text-[11px]">
                            blog/{formSlug || 'post-title'}
                          </span>
                        </div>
                        <h5 className="text-lg font-bold text-blue-700 hover:underline leading-snug cursor-pointer">
                          {formTitle || 'Article Title'} | ApexAI Playbooks
                        </h5>
                        <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                          {formExcerpt || 'Your meta description will appear here on Google searches...'}
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                          Target URL Slug
                        </label>
                        <input
                          type="text"
                          value={formSlug}
                          onChange={(e) => setFormSlug(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono text-slate-700 focus:outline-none focus:border-blue-600"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-slate-700 uppercase mb-1">
                          Author Attribution
                        </label>
                        <input
                          type="text"
                          value={formAuthor}
                          onChange={(e) => setFormAuthor(e.target.value)}
                          className="w-full bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-700 focus:outline-none focus:border-blue-600"
                        />
                      </div>
                    </div>
                  </div>
                ) : (
                  /* Reader Preview Tab */
                  <div className="p-6 bg-slate-50 rounded-2xl border border-slate-200 space-y-4">
                    {formImageUrl && (
                      <div className="w-full h-52 sm:h-64 rounded-2xl overflow-hidden relative bg-slate-900 border border-slate-200">
                        <img
                          src={formImageUrl}
                          alt="Cover Preview"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    )}

                    <div className="flex items-center gap-2">
                      <span className="bg-blue-600 text-white text-[11px] font-bold px-3 py-1 rounded-full uppercase">
                        {formCategory}
                      </span>
                      <span className="text-xs text-slate-400">{formReadTime}</span>
                      <span className="text-xs text-slate-400">• By {formAuthor}</span>
                    </div>

                    <h2 className="text-2xl sm:text-3xl font-black text-slate-900 leading-snug">
                      {formTitle || 'Untitled Article'}
                    </h2>

                    <p className="text-sm text-slate-600 italic border-l-4 border-blue-600 pl-3">
                      {formExcerpt || 'No excerpt provided.'}
                    </p>

                    {formTakeaways.trim() && (
                      <div className="bg-white p-4 rounded-xl border border-slate-200">
                        <div className="text-xs font-bold text-blue-600 uppercase tracking-wider mb-2">
                          Key Takeaways
                        </div>
                        <ul className="space-y-1 text-xs text-slate-700">
                          {formTakeaways
                            .split('\n')
                            .filter(Boolean)
                            .map((t, idx) => (
                              <li key={idx} className="flex items-start gap-1.5">
                                <span className="text-blue-600 font-bold">✓</span>
                                <span>{t}</span>
                              </li>
                            ))}
                        </ul>
                      </div>
                    )}

                    <div className="space-y-3 text-xs sm:text-sm text-slate-700 leading-relaxed font-normal">
                      {formContent ? (
                        formContent
                          .split('\n\n')
                          .filter(Boolean)
                          .map((p, idx) => (
                            <p key={idx} className="leading-relaxed">
                              {p}
                            </p>
                          ))
                      ) : (
                        <p className="text-slate-400">Article body will appear here...</p>
                      )}
                    </div>
                  </div>
                )}

                {/* Submit Controls */}
                <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => {
                      setViewMode('list');
                      resetForm();
                    }}
                    className="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold px-4 py-2.5 rounded-xl transition cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-6 py-2.5 rounded-xl shadow-md transition flex items-center gap-1.5 cursor-pointer disabled:opacity-75"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>
                      {isSubmitting
                        ? 'Publishing to Live Site...'
                        : viewMode === 'create'
                        ? 'Publish Post to Live Site'
                        : 'Update Article'}
                    </span>
                  </button>
                </div>
              </form>
            )}
          </div>
        )}

        {/* Delete Confirmation Modal */}
        {deleteConfirmId && (
          <div className="fixed inset-0 z-60 bg-black/50 flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl max-w-sm w-full p-6 text-center space-y-4 shadow-2xl border border-slate-100">
              <div className="w-12 h-12 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center mx-auto">
                <Trash2 className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-slate-900 text-base">Permanently Delete Article?</h4>
              <p className="text-xs text-slate-500">
                This will delete this blog post from your live Firestore database immediately.
              </p>
              <div className="flex gap-2">
                <button
                  onClick={() => setDeleteConfirmId(null)}
                  className="flex-1 bg-slate-100 text-slate-700 text-xs font-semibold py-2.5 rounded-xl hover:bg-slate-200 cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  onClick={() => handleDelete(deleteConfirmId)}
                  className="flex-1 bg-rose-600 text-white text-xs font-bold py-2.5 rounded-xl hover:bg-rose-700 cursor-pointer"
                >
                  Yes, Delete
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
