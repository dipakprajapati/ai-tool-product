import React, { useEffect, useState } from 'react';
import { BlogPost } from '../types';
import {
  Clock,
  Calendar,
  User,
  ArrowLeft,
  Share2,
  Check,
  CheckCircle2,
  Sparkles,
  BookOpen,
  ArrowRight,
  ChevronRight,
  MessageCircle,
  Twitter,
  Linkedin,
  Tag,
  ShoppingBag,
} from 'lucide-react';

interface BlogDetailsPageProps {
  post: BlogPost;
  allPosts: BlogPost[];
  onSelectPost: (post: BlogPost) => void;
  onBackToHome: () => void;
  onExploreProducts: () => void;
}

export const BlogDetailsPage: React.FC<BlogDetailsPageProps> = ({
  post,
  allPosts,
  onSelectPost,
  onBackToHome,
  onExploreProducts,
}) => {
  const [copied, setCopied] = useState(false);
  const [readingProgress, setReadingProgress] = useState(0);

  // Update dynamic SEO tags (title, meta description, JSON-LD structured data)
  useEffect(() => {
    // 1. Update document title
    const prevTitle = document.title;
    document.title = `${post.title} | ApexAI Playbooks`;

    // 2. Update meta description
    let metaDesc = document.querySelector('meta[name="description"]');
    const originalDesc = metaDesc ? metaDesc.getAttribute('content') : '';
    if (!metaDesc) {
      metaDesc = document.createElement('meta');
      metaDesc.setAttribute('name', 'description');
      document.head.appendChild(metaDesc);
    }
    metaDesc.setAttribute('content', post.excerpt || post.title);

    // 3. Update OpenGraph & Twitter tags
    const setMetaProperty = (prop: string, content: string) => {
      let el = document.querySelector(`meta[property="${prop}"]`);
      if (!el) {
        el = document.createElement('meta');
        el.setAttribute('property', prop);
        document.head.appendChild(el);
      }
      el.setAttribute('content', content);
    };

    setMetaProperty('og:title', post.title);
    setMetaProperty('og:description', post.excerpt || post.title);
    setMetaProperty('og:type', 'article');
    if (post.imageUrl) {
      setMetaProperty('og:image', post.imageUrl);
    }

    // 4. Inject Schema.org BlogPosting structured data for Google SEO
    const schemaScriptId = 'blog-post-jsonld';
    let scriptEl = document.getElementById(schemaScriptId) as HTMLScriptElement | null;
    if (!scriptEl) {
      scriptEl = document.createElement('script');
      scriptEl.id = schemaScriptId;
      scriptEl.type = 'application/ld+json';
      document.head.appendChild(scriptEl);
    }

    const structuredData = {
      '@context': 'https://schema.org',
      '@type': 'BlogPosting',
      headline: post.title,
      description: post.excerpt,
      image: post.imageUrl || undefined,
      author: {
        '@type': 'Person',
        name: post.author || 'Dipak Prajapati',
      },
      datePublished: post.date,
      publisher: {
        '@type': 'Organization',
        name: 'ApexAI',
        logo: {
          '@type': 'ImageObject',
          url: 'https://ais-pre-ef2mfci3lkwebsxkbr5zgl-293377309392.asia-east1.run.app/favicon.ico',
        },
      },
      mainEntityOfPage: {
        '@type': 'WebPage',
        '@id': window.location.href,
      },
    };
    scriptEl.textContent = JSON.stringify(structuredData);

    // Scroll to top upon viewing new article
    window.scrollTo({ top: 0, behavior: 'smooth' });

    // 5. Reading progress scroll tracker
    const handleScroll = () => {
      const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
      if (totalHeight > 0) {
        const progress = Math.min(100, Math.max(0, (window.scrollY / totalHeight) * 100));
        setReadingProgress(progress);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });

    return () => {
      document.title = prevTitle;
      if (originalDesc && metaDesc) {
        metaDesc.setAttribute('content', originalDesc);
      }
      window.removeEventListener('scroll', handleScroll);
    };
  }, [post]);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShareTwitter = () => {
    const text = encodeURIComponent(`${post.title} via @ApexAI`);
    const url = encodeURIComponent(window.location.href);
    window.open(`https://twitter.com/intent/tweet?text=${text}&url=${url}`, '_blank');
  };

  const handleShareLinkedIn = () => {
    const url = encodeURIComponent(window.location.href);
    window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${url}`, '_blank');
  };

  const handleShareWhatsApp = () => {
    const text = encodeURIComponent(`*${post.title}*\n${window.location.href}`);
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  // Filter other articles as recent suggestions
  const recentArticles = allPosts
    .filter((p) => p.id !== post.id && (p.slug || p.id) !== (post.slug || post.id))
    .slice(0, 4);

  // Markdown-like block renderer for WordPress-style formatting
  const renderContentParagraph = (text: string, idx: number) => {
    // Check if it's an H2 heading (starts with '## ')
    if (text.startsWith('## ')) {
      return (
        <h2
          key={idx}
          className="text-2xl sm:text-3xl font-black text-slate-900 mt-8 mb-4 tracking-tight leading-snug pt-2 border-t border-slate-100"
        >
          {text.replace(/^##\s+/, '')}
        </h2>
      );
    }

    // Check if it's an H3 heading (starts with '### ')
    if (text.startsWith('### ')) {
      return (
        <h3
          key={idx}
          className="text-xl sm:text-2xl font-bold text-slate-900 mt-6 mb-3 tracking-tight leading-snug"
        >
          {text.replace(/^###\s+/, '')}
        </h3>
      );
    }

    // Check if it's a blockquote (starts with '> ')
    if (text.startsWith('> ')) {
      return (
        <blockquote
          key={idx}
          className="my-5 p-4 bg-blue-50/60 rounded-2xl border-l-4 border-blue-600 text-slate-700 italic text-base leading-relaxed"
        >
          {text.replace(/^>\s+/, '')}
        </blockquote>
      );
    }

    // Standard paragraph with line-breaks
    return (
      <p key={idx} className="text-slate-700 text-base sm:text-lg leading-relaxed mb-5 font-normal">
        {text}
      </p>
    );
  };

  return (
    <div className="min-h-screen bg-[#FAFAFC] text-[#0F172A] relative">
      {/* Top Reading Progress Bar */}
      <div
        className="fixed top-0 left-0 h-1 bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-500 z-50 transition-all duration-150"
        style={{ width: `${readingProgress}%` }}
      />

      {/* Main Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        {/* Breadcrumb Navigation */}
        <nav aria-label="Breadcrumb" className="mb-6 flex items-center gap-2 text-xs text-slate-500 flex-wrap">
          <button
            onClick={onBackToHome}
            className="hover:text-blue-600 font-semibold transition flex items-center gap-1 cursor-pointer"
          >
            <span>Home</span>
          </button>
          <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
          <button
            onClick={onBackToHome}
            className="hover:text-blue-600 font-semibold transition cursor-pointer"
          >
            <span>Blog &amp; Guides</span>
          </button>
          <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-blue-600 font-bold uppercase">{post.category}</span>
          <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-slate-800 font-medium truncate max-w-xs">{post.title}</span>
        </nav>

        {/* Back to Home Button */}
        <div className="mb-8">
          <button
            onClick={onBackToHome}
            className="inline-flex items-center gap-2 text-xs font-bold text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 hover:border-slate-300 px-4 py-2 rounded-xl transition shadow-2xs cursor-pointer group"
          >
            <ArrowLeft className="w-4 h-4 text-blue-600 group-hover:-translate-x-1 transition-transform" />
            <span>Back to All Articles</span>
          </button>
        </div>

        {/* Grid Layout: Main Article Column + Recent Articles Sidebar */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
          {/* Main Article Content (8 cols on desktop) */}
          <article className="lg:col-span-8 bg-white rounded-3xl p-6 sm:p-10 border border-slate-200 shadow-xs">
            {/* Header Metadata */}
            <div className="flex items-center gap-3 text-xs text-slate-500 mb-4 flex-wrap">
              <span className="bg-blue-600 text-white font-extrabold text-[11px] px-3 py-1 rounded-full uppercase tracking-wider shadow-sm">
                {post.category}
              </span>
              <span className="flex items-center gap-1 font-medium">
                <Clock className="w-3.5 h-3.5 text-blue-600" />
                {post.readTime}
              </span>
              <span>•</span>
              <span className="flex items-center gap-1 font-medium">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                {post.date}
              </span>
              {post.author && (
                <>
                  <span>•</span>
                  <span className="flex items-center gap-1 font-medium text-slate-700">
                    <User className="w-3.5 h-3.5 text-slate-400" />
                    By {post.author}
                  </span>
                </>
              )}
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-slate-900 tracking-tight leading-[1.18] mb-6">
              {post.title}
            </h1>

            {/* Excerpt Lead */}
            {post.excerpt && (
              <div className="text-base sm:text-lg text-slate-600 font-medium italic border-l-4 border-blue-600 pl-4 py-1 mb-8 bg-slate-50 rounded-r-2xl">
                {post.excerpt}
              </div>
            )}

            {/* Social Share Bar */}
            <div className="flex items-center justify-between pb-6 mb-8 border-b border-slate-100 flex-wrap gap-3">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
                  Share:
                </span>
                <button
                  onClick={handleCopyLink}
                  title="Copy Article Link"
                  className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition cursor-pointer flex items-center gap-1.5 text-xs font-semibold"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="text-emerald-700">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Share2 className="w-3.5 h-3.5" />
                      <span>Copy URL</span>
                    </>
                  )}
                </button>
                <button
                  onClick={handleShareWhatsApp}
                  title="Share on WhatsApp"
                  className="p-2 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-700 transition cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4" />
                </button>
                <button
                  onClick={handleShareTwitter}
                  title="Share on X / Twitter"
                  className="p-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition cursor-pointer"
                >
                  <Twitter className="w-4 h-4" />
                </button>
                <button
                  onClick={handleShareLinkedIn}
                  title="Share on LinkedIn"
                  className="p-2 rounded-xl bg-blue-50 hover:bg-blue-100 text-blue-700 transition cursor-pointer"
                >
                  <Linkedin className="w-4 h-4" />
                </button>
              </div>

              {post.tags && (
                <div className="flex items-center gap-1.5 flex-wrap">
                  {post.tags.split(',').map((t, idx) => (
                    <span
                      key={idx}
                      className="bg-slate-100 text-slate-600 text-[10px] font-semibold px-2 py-0.5 rounded-md"
                    >
                      #{t.trim()}
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* High-Resolution Hero Cover Image */}
            {post.imageUrl && (
              <div className="w-full aspect-[16/9] sm:aspect-[21/9] rounded-2xl overflow-hidden mb-8 shadow-sm bg-slate-900 border border-slate-100">
                <img
                  src={post.imageUrl}
                  alt={post.title}
                  className="w-full h-full object-cover"
                  loading="eager"
                  onError={(e) => {
                    e.currentTarget.style.display = 'none';
                  }}
                />
              </div>
            )}

            {/* Key Actionable Takeaways (TL;DR) Box */}
            {post.keyTakeaways && post.keyTakeaways.length > 0 && (
              <div className="mb-8 bg-blue-50/70 rounded-2xl p-6 border border-blue-200/80">
                <div className="text-xs font-black text-blue-800 uppercase tracking-wider mb-3 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-blue-600" />
                  <span>Key Actionable Takeaways (TL;DR)</span>
                </div>
                <ul className="space-y-2.5 text-sm sm:text-base text-slate-800">
                  {post.keyTakeaways.map((item, idx) => (
                    <li key={idx} className="flex items-start gap-2.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-600 mt-2 shrink-0" />
                      <span className="leading-relaxed font-medium">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Full Formatted Article Content */}
            <div className="prose prose-slate max-w-none">
              {Array.isArray(post.content) ? (
                post.content.map((paragraph, idx) => renderContentParagraph(paragraph, idx))
              ) : typeof post.content === 'string' ? (
                post.content
                  .split('\n\n')
                  .map((paragraph, idx) => renderContentParagraph(paragraph, idx))
              ) : null}
            </div>

            {/* Author Footer Card */}
            <div className="mt-12 pt-8 border-t border-slate-200 flex items-center justify-between gap-4 flex-wrap bg-slate-50 p-6 rounded-2xl">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-blue-600 text-white rounded-2xl flex items-center justify-center font-bold text-lg shadow-sm">
                  {post.author ? post.author.charAt(0) : 'A'}
                </div>
                <div>
                  <h4 className="text-sm font-bold text-slate-900">
                    {post.author || 'ApexAI Editorial Team'}
                  </h4>
                  <p className="text-xs text-slate-500">
                    AI Systems, Workflows &amp; Productivity Strategist
                  </p>
                </div>
              </div>

              <button
                onClick={handleCopyLink}
                className="text-xs font-bold px-4 py-2 rounded-xl bg-white border border-slate-200 text-slate-700 hover:border-blue-400 hover:text-blue-600 transition shadow-2xs flex items-center gap-1.5 cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Share2 className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Share Article'}</span>
              </button>
            </div>

            {/* In-Article Promotion CTA Banner */}
            <div className="mt-8 bg-gradient-to-r from-slate-900 to-blue-950 rounded-2xl p-6 sm:p-8 text-white flex flex-col sm:flex-row items-center justify-between gap-6">
              <div>
                <span className="bg-blue-600 text-white text-[10px] font-extrabold px-2.5 py-0.5 rounded-full uppercase tracking-wider mb-2 inline-block">
                  Level Up Your AI
                </span>
                <h3 className="text-xl font-bold">Want Ready-to-Use AI Systems?</h3>
                <p className="text-xs text-slate-300 mt-1 max-w-md">
                  Explore our verified collection of 50+ plug-and-play prompt packs, automations, and business toolkits.
                </p>
              </div>
              <button
                onClick={onExploreProducts}
                className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-5 py-3 rounded-xl transition shadow-lg shrink-0 flex items-center gap-2 cursor-pointer"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Explore 50+ Products</span>
              </button>
            </div>
          </article>

          {/* Right Sidebar: Recent & Related Blogs (4 cols on desktop) */}
          <aside className="lg:col-span-4 space-y-6">
            {/* Recent Blogs Widget */}
            <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-xs">
              <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <BookOpen className="w-4 h-4 text-blue-600" />
                  <h3 className="font-extrabold text-slate-900 text-base">Recent Playbooks</h3>
                </div>
                <span className="text-[11px] font-bold text-blue-600 bg-blue-50 px-2 py-0.5 rounded-full">
                  More Articles
                </span>
              </div>

              {recentArticles.length > 0 ? (
                <div className="space-y-4">
                  {recentArticles.map((recent) => (
                    <div
                      key={recent.id}
                      onClick={() => onSelectPost(recent)}
                      className="group flex gap-3.5 p-2 rounded-2xl hover:bg-slate-50 transition cursor-pointer border border-transparent hover:border-slate-200"
                    >
                      {/* Thumbnail */}
                      {recent.imageUrl ? (
                        <div className="w-20 h-16 rounded-xl overflow-hidden bg-slate-900 shrink-0 border border-slate-100">
                          <img
                            src={recent.imageUrl}
                            alt={recent.title}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                            loading="lazy"
                          />
                        </div>
                      ) : (
                        <div className="w-20 h-16 rounded-xl bg-gradient-to-br from-slate-800 to-slate-900 shrink-0 flex items-center justify-center text-blue-400">
                          <BookOpen className="w-5 h-5" />
                        </div>
                      )}

                      {/* Content */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 text-[10px] text-slate-400 mb-0.5">
                          <span className="font-bold text-blue-600 uppercase">{recent.category}</span>
                          <span>•</span>
                          <span>{recent.readTime}</span>
                        </div>
                        <h4 className="text-xs sm:text-sm font-bold text-slate-900 group-hover:text-blue-600 transition leading-snug line-clamp-2">
                          {recent.title}
                        </h4>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-xs text-slate-400 text-center py-4">No additional articles found.</p>
              )}

              <button
                onClick={onBackToHome}
                className="w-full mt-5 py-2.5 bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-bold rounded-xl transition border border-slate-200 flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>View All Articles</span>
                <ArrowRight className="w-3.5 h-3.5 text-blue-600" />
              </button>
            </div>

            {/* Newsletter / Free Prompts Widget */}
            <div className="bg-gradient-to-br from-blue-600 to-indigo-700 rounded-3xl p-6 text-white shadow-md shadow-blue-500/10">
              <span className="text-[10px] font-extrabold uppercase tracking-widest bg-white/20 px-2 py-0.5 rounded-full inline-block mb-3">
                Free Download
              </span>
              <h4 className="text-lg font-black leading-snug">
                Get 50 Master AI Prompts Guide
              </h4>
              <p className="text-xs text-blue-100 mt-2 leading-relaxed">
                Copy-paste prompts engineered for marketing, automation, coding, and sales outreach.
              </p>
              <a
                href="#free-resources"
                onClick={onBackToHome}
                className="mt-4 block w-full bg-white text-blue-700 hover:bg-blue-50 font-bold text-xs py-2.5 rounded-xl text-center shadow-xs transition"
              >
                Claim Free Guide
              </a>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
};
