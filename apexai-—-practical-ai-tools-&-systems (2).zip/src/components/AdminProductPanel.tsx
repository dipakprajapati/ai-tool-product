import React, { useState, useMemo, useEffect } from 'react';
import { useFirebase, ADMIN_EMAIL } from '../firebase/context';
import { Product, Bundle, ProductCurriculumItem, ProductBonusItem, ProductFaqItem } from '../types';
import { PRODUCTS_DATA } from '../data/products';
import { BUNDLES_DATA } from '../data/bundles';
import {
  X,
  Plus,
  Edit3,
  Trash2,
  Search,
  CheckCircle2,
  AlertCircle,
  Shield,
  Image as ImageIcon,
  Download,
  Upload,
  Layers,
  Check,
  ExternalLink,
  RotateCcw,
  Package,
  Lock,
  KeyRound,
  LogOut,
  Sparkles,
  FileText,
  BookOpen,
  Target,
  Gift,
  HelpCircle,
  Award,
  ChevronRight,
  Eye,
  Sliders,
  FolderPlus,
  CreditCard,
  Link as LinkIcon,
  Mail,
} from 'lucide-react';

interface AdminProductPanelProps {
  isOpen: boolean;
  onClose: () => void;
  onPreviewProduct: (product: Product) => void;
  onPreviewBundle?: (bundle: Bundle) => void;
  initialSection?: 'products' | 'bundles' | 'payments';
  initialEditProductId?: string | null;
  initialEditBundleId?: string | null;
}

const PRODUCT_IMAGE_PRESETS = [
  {
    name: 'AI WhatsApp / Bot Automation',
    url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
  },
  {
    name: 'AI Agency & High-Ticket B2B',
    url: 'https://images.unsplash.com/photo-1531482615713-2afd69097998?auto=format&fit=crop&w=1200&q=80',
  },
  {
    name: 'Lead Generation & Sales Outbound',
    url: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1200&q=80',
  },
  {
    name: 'Freelancing & Client Delivery',
    url: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=1200&q=80',
  },
  {
    name: 'Digital Products & Money Assets',
    url: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=1200&q=80',
  },
  {
    name: 'Video Shorts & Content Automation',
    url: 'https://images.unsplash.com/photo-1574717024653-61fd2cf4d44d?auto=format&fit=crop&w=1200&q=80',
  },
  {
    name: 'Prompt Engineering & Master Vault',
    url: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=1200&q=80',
  },
];

const CATEGORIES = [
  { id: 'automation', label: 'AI Business Automation' },
  { id: 'money', label: 'AI Money & Side Hustles' },
  { id: 'clients', label: 'AI Marketing & Sales' },
  { id: 'content', label: 'AI Creator' },
  { id: 'productivity', label: 'AI Prompts & Productivity' },
  { id: 'skills', label: 'Build AI Skills' },
];

export const AdminProductPanel: React.FC<AdminProductPanelProps> = ({
  isOpen,
  onClose,
  onPreviewProduct,
  onPreviewBundle,
  initialSection,
  initialEditProductId,
  initialEditBundleId,
}) => {
  const {
    user,
    isAdmin,
    signInWithGoogle,
    signOutUser,
    products,
    createProduct,
    updateProduct,
    deleteProduct,
    seedProducts,
    loadingProducts,
    bundles,
    createBundle,
    updateBundle,
    deleteBundle,
    seedBundles,
    loadingBundles,
    paymentSettings,
    updatePaymentSettings,
  } = useFirebase();

  // Instant Owner Bypass state
  const [isUnlockedLocally, setIsUnlockedLocally] = useState<boolean>(() => {
    try {
      return localStorage.getItem('apex_owner_verified') === 'true';
    } catch {
      return false;
    }
  });
  const [passcodeInput, setPasscodeInput] = useState('');
  const [passcodeError, setPasscodeError] = useState(false);

  const isAuthorized = isAdmin || isUnlockedLocally;

  // Active Main Section: 'products' | 'bundles' | 'payments'
  const [activeSection, setActiveSection] = useState<'products' | 'bundles' | 'payments'>('products');

  // Payment Gateway Settings Form State
  const [payDefaultUrl, setPayDefaultUrl] = useState(paymentSettings?.defaultRazorpayUrl || '');
  const [payKeyId, setPayKeyId] = useState(paymentSettings?.razorpayKeyId || '');
  const [payUpiId, setPayUpiId] = useState(paymentSettings?.merchantUpiId || '');
  const [payMerchantName, setPayMerchantName] = useState(paymentSettings?.merchantName || 'ApexAI Technologies');
  const [payDirectRedirect, setPayDirectRedirect] = useState(paymentSettings?.directRedirectOnAccess || false);
  const [payResendApiKey, setPayResendApiKey] = useState(paymentSettings?.resendApiKey || '');
  const [payWebhookUrl, setPayWebhookUrl] = useState(paymentSettings?.notificationWebhookUrl || '');
  const [paySenderEmail, setPaySenderEmail] = useState(paymentSettings?.senderEmail || 'orders@apexai.tools');
  const [isSavingPaymentSettings, setIsSavingPaymentSettings] = useState(false);

  useEffect(() => {
    if (paymentSettings) {
      setPayDefaultUrl(paymentSettings.defaultRazorpayUrl || '');
      setPayKeyId(paymentSettings.razorpayKeyId || '');
      setPayUpiId(paymentSettings.merchantUpiId || '');
      setPayMerchantName(paymentSettings.merchantName || 'ApexAI Technologies');
      setPayDirectRedirect(!!paymentSettings.directRedirectOnAccess);
      setPayResendApiKey(paymentSettings.resendApiKey || '');
      setPayWebhookUrl(paymentSettings.notificationWebhookUrl || '');
      setPaySenderEmail(paymentSettings.senderEmail || 'orders@apexai.tools');
    }
  }, [paymentSettings]);

  // Product Editor States
  const [prodViewMode, setProdViewMode] = useState<'list' | 'editor'>('list');
  const [prodEditorSubTab, setProdEditorSubTab] = useState<'general' | 'landing' | 'assets'>('general');
  const [editingProductId, setEditingProductId] = useState<string | null>(null);

  // Bundle Editor States
  const [bundleViewMode, setBundleViewMode] = useState<'list' | 'editor'>('list');
  const [bundleEditorSubTab, setBundleEditorSubTab] = useState<'general' | 'included' | 'landing' | 'assets'>('general');
  const [editingBundleId, setEditingBundleId] = useState<string | null>(null);

  const [searchTerm, setSearchTerm] = useState('');
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSeeding, setIsSeeding] = useState(false);

  // ----------------------------------------------------
  // PRODUCT FORM FIELDS
  // ----------------------------------------------------
  const [prodTitle, setProdTitle] = useState('');
  const [prodSlug, setProdSlug] = useState('');
  const [prodCategory, setProdCategory] = useState('automation');
  const [prodCategoryLabel, setProdCategoryLabel] = useState('AI Business Automation');
  const [prodTagline, setProdTagline] = useState('');
  const [prodDescription, setProdDescription] = useState('');
  const [prodFullDescription, setProdFullDescription] = useState('');
  const [prodPriceINR, setProdPriceINR] = useState(999);
  const [prodOriginalPriceINR, setProdOriginalPriceINR] = useState(1999);
  const [prodBadge, setProdBadge] = useState('');
  const [prodRating, setProdRating] = useState(4.9);
  const [prodReviewsCount, setProdReviewsCount] = useState(150);
  const [prodFormat, setProdFormat] = useState('PDF Guide + Blueprints');
  const [prodDifficulty, setProdDifficulty] = useState('Beginner');
  const [prodImageUrl, setProdImageUrl] = useState('');
  const [prodPdfUrl, setProdPdfUrl] = useState('');
  const [prodPdfFileName, setProdPdfFileName] = useState('');
  const [prodSampleTitle, setProdSampleTitle] = useState('');
  const [prodSampleContent, setProdSampleContent] = useState('');
  const [prodDeliverablesText, setProdDeliverablesText] = useState('');
  const [prodLearningPointsText, setProdLearningPointsText] = useState('');
  const [prodTargetAudienceText, setProdTargetAudienceText] = useState('');
  const [prodAuthorBio, setProdAuthorBio] = useState('Dipak Prajapati • AI Enterprise Specialist & Founder');
  const [prodGuaranteeText, setProdGuaranteeText] = useState('14-Day 100% Risk-Free Money Back Guarantee');
  const [prodPopular, setProdPopular] = useState(false);
  const [prodFeatured, setProdFeatured] = useState(true);
  const [prodPaymentLink, setProdPaymentLink] = useState('');

  // Dynamic Curriculum for Product
  const [prodCurriculum, setProdCurriculum] = useState<ProductCurriculumItem[]>([
    { title: 'Module 1: Quickstart & Fundamental Blueprints', duration: '45 mins', description: 'Core principles and 1-click template imports.' },
    { title: 'Module 2: Real-World Implementation & Workflows', duration: '90 mins', description: 'Connecting APIs, automation triggers, and client deliverables.' }
  ]);

  // Dynamic Bonuses for Product
  const [prodBonuses, setProdBonuses] = useState<ProductBonusItem[]>([
    { title: 'Client Proposal Deck & Agreement', valueINR: 1999, description: 'Copy-paste pitch deck to sell this system for ₹25,000+.' }
  ]);

  // Dynamic FAQs for Product
  const [prodFaqs, setProdFaqs] = useState<ProductFaqItem[]>([
    { question: 'How do I download the PDF after payment?', answer: 'You get immediate 1-click download access on your order confirmation screen and via email.' },
    { question: 'Can I use this for client projects?', answer: 'Yes! Full commercial implementation rights are granted with your purchase.' }
  ]);

  // ----------------------------------------------------
  // BUNDLE FORM FIELDS
  // ----------------------------------------------------
  const [bundleTitle, setBundleTitle] = useState('');
  const [bundleSlug, setBundleSlug] = useState('');
  const [bundleSubtitle, setBundleSubtitle] = useState('');
  const [bundleBadge, setBundleBadge] = useState('POPULAR BUNDLE');
  const [bundleBadgeType, setBundleBadgeType] = useState<'popular' | 'business' | 'creator' | 'ultimate'>('popular');
  const [bundlePriceINR, setBundlePriceINR] = useState(2999);
  const [bundleOriginalPriceINR, setBundleOriginalPriceINR] = useState(6999);
  const [bundleSavingsPercent, setBundleSavingsPercent] = useState(57);
  const [bundleImageUrl, setBundleImageUrl] = useState('');
  const [bundlePdfUrl, setBundlePdfUrl] = useState('');
  const [bundlePdfFileName, setBundlePdfFileName] = useState('');
  const [bundleFullDescription, setBundleFullDescription] = useState('');
  const [bundleFeaturesText, setBundleFeaturesText] = useState('');
  const [bundleIncludedProductsText, setBundleIncludedProductsText] = useState('');
  const [bundleDeliverablesText, setBundleDeliverablesText] = useState('');
  const [bundleTargetAudienceText, setBundleTargetAudienceText] = useState('');
  const [bundlePaymentLink, setBundlePaymentLink] = useState('');

  // Dynamic Curriculum for Bundle
  const [bundleCurriculum, setBundleCurriculum] = useState<ProductCurriculumItem[]>([
    { title: 'Master Track 1: Foundations & High-Leverage Automations', duration: '3 Hours', description: 'Set up autonomous bots and pipelines.' },
    { title: 'Master Track 2: Monetization & High-Ticket Retainers', duration: '4 Hours', description: 'Package, pitch, and retain ₹50k/month clients.' }
  ]);

  // Dynamic Bonuses for Bundle
  const [bundleBonuses, setBundleBonuses] = useState<ProductBonusItem[]>([
    { title: 'VIP Community Pass & Founder Mastermind', valueINR: 4999, description: 'Direct private group access with Dipak Prajapati.' }
  ]);

  // Dynamic FAQs for Bundle
  const [bundleFaqs, setBundleFaqs] = useState<ProductFaqItem[]>([
    { question: 'Are there any recurring monthly charges?', answer: 'Zero recurring fees. You get permanent lifetime access with all future updates.' }
  ]);

  // Lists display
  const displayProducts = products && products.length > 0 ? products : PRODUCTS_DATA;
  const displayBundles = bundles && bundles.length > 0 ? bundles : BUNDLES_DATA;

  const filteredProducts = useMemo(() => {
    const q = (searchTerm || '').toLowerCase().trim();
    if (!q) return displayProducts;
    return displayProducts.filter((p) => {
      return (
        p.title.toLowerCase().includes(q) ||
        p.tagline.toLowerCase().includes(q) ||
        p.categoryLabel.toLowerCase().includes(q)
      );
    });
  }, [displayProducts, searchTerm]);

  const filteredBundles = useMemo(() => {
    const q = (searchTerm || '').toLowerCase().trim();
    if (!q) return displayBundles;
    return displayBundles.filter((b) => {
      return (
        b.title.toLowerCase().includes(q) ||
        b.subtitle.toLowerCase().includes(q) ||
        b.badge.toLowerCase().includes(q)
      );
    });
  }, [displayBundles, searchTerm]);

  // Auto calculate savings % when pricing changes
  useEffect(() => {
    if (bundleOriginalPriceINR > 0 && bundlePriceINR > 0) {
      const pct = Math.round(((bundleOriginalPriceINR - bundlePriceINR) / bundleOriginalPriceINR) * 100);
      setBundleSavingsPercent(Math.max(1, pct));
    }
  }, [bundlePriceINR, bundleOriginalPriceINR]);

  // Handle external navigation directly into a product or bundle editor
  useEffect(() => {
    if (!isOpen) return;
    if (initialSection) {
      setActiveSection(initialSection);
    }
    if (initialEditProductId) {
      const prod = displayProducts.find(
        (p) => p.id === initialEditProductId || p.slug === initialEditProductId
      );
      if (prod) {
        handleEditProduct(prod);
      }
    } else if (initialEditBundleId) {
      const bnd = displayBundles.find(
        (b) => b.id === initialEditBundleId || b.slug === initialEditBundleId
      );
      if (bnd) {
        handleEditBundle(bnd);
      }
    }
  }, [isOpen, initialSection, initialEditProductId, initialEditBundleId]);

  if (!isOpen) return null;

  // Handle Owner Passcode Login
  const handlePasscodeSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = passcodeInput.trim().toUpperCase();
    if (clean === 'APEX2026' || clean === 'DIPAK' || clean === 'ADMIN' || clean === 'OWNER') {
      setIsUnlockedLocally(true);
      setPasscodeError(false);
      try {
        localStorage.setItem('apex_owner_verified', 'true');
      } catch {}
    } else {
      setPasscodeError(true);
    }
  };

  const handleOwnerLogout = () => {
    setIsUnlockedLocally(false);
    try {
      localStorage.removeItem('apex_owner_verified');
    } catch {}
    if (user) {
      signOutUser();
    }
  };

  // ----------------------------------------------------
  // PRODUCT ACTIONS
  // ----------------------------------------------------
  const handleOpenCreateProduct = () => {
    setEditingProductId(null);
    setProdTitle('');
    setProdSlug('');
    setProdCategory('automation');
    setProdCategoryLabel('AI Business Automation');
    setProdTagline('');
    setProdDescription('');
    setProdFullDescription('');
    setProdPriceINR(999);
    setProdOriginalPriceINR(1999);
    setProdBadge('NEW LAUNCH');
    setProdRating(4.9);
    setProdReviewsCount(95);
    setProdFormat('PDF Guide + Blueprints');
    setProdDifficulty('Beginner');
    setProdImageUrl(PRODUCT_IMAGE_PRESETS[0].url);
    setProdPdfUrl('');
    setProdPdfFileName('');
    setProdSampleTitle('Verified Execution Prompt');
    setProdSampleContent('');
    setProdDeliverablesText('PDF Implementation Guide (60+ pages)\nNotion Workspace Template\nReady-to-Deploy Make Scenarios');
    setProdLearningPointsText('Automate daily business operations\nGenerate client proposals in 2 minutes\nScale revenue without additional staff');
    setProdTargetAudienceText('Freelancers looking to offer AI services\nAgencies and agency founders\nSmall business owners');
    setProdCurriculum([
      { title: 'Module 1: Quickstart & Setup', duration: '45 mins', description: 'Immediate architecture and template imports.' },
      { title: 'Module 2: Advanced Deployment & Delivery', duration: '90 mins', description: 'Client handover and live automation setup.' }
    ]);
    setProdBonuses([
      { title: 'Commercial Service Agreement Template', valueINR: 1999, description: 'Legally vetted contract to protect your work and pricing.' }
    ]);
    setProdFaqs([
      { question: 'How do I download the files?', answer: 'Instant 1-click download access immediately after payment.' },
      { question: 'Do I need programming knowledge?', answer: 'Zero coding required. All workflows are visual and import-ready.' }
    ]);
    setProdPopular(false);
    setProdFeatured(true);
    setProdPaymentLink('');
    setProdEditorSubTab('landing');
    setProdViewMode('editor');
  };

  const handleEditProduct = (product: Product) => {
    setEditingProductId(product.id);
    setProdTitle(product.title);
    setProdSlug(product.slug || product.id);
    setProdCategory(product.category);
    setProdCategoryLabel(product.categoryLabel);
    setProdTagline(product.tagline);
    setProdDescription(product.description);
    setProdFullDescription(product.fullDescription || product.description);
    setProdPriceINR(product.priceINR);
    setProdOriginalPriceINR(product.originalPriceINR);
    setProdBadge(product.badge || '');
    setProdRating(product.rating || 4.9);
    setProdReviewsCount(product.reviewsCount || 100);
    setProdFormat(product.format || 'PDF Guide');
    setProdDifficulty(product.difficulty || 'Beginner');
    setProdImageUrl(product.imageUrl || '');
    setProdPaymentLink(product.paymentLink || '');
    setProdPdfUrl(product.pdfUrl || '');
    setProdPdfFileName(product.pdfFileName || '');
    setProdSampleTitle(product.samplePreviewTitle || '');
    setProdSampleContent(product.samplePreviewContent || '');
    setProdDeliverablesText(Array.isArray(product.deliverables) ? product.deliverables.join('\n') : '');
    setProdLearningPointsText(Array.isArray(product.learningPoints) ? product.learningPoints.join('\n') : '');
    setProdTargetAudienceText(Array.isArray(product.targetAudience) ? product.targetAudience.join('\n') : '');
    setProdAuthorBio(product.authorBio || 'Dipak Prajapati • AI Enterprise Specialist');
    setProdGuaranteeText(product.guaranteeText || '14-Day 100% Risk-Free Money Back Guarantee');
    setProdCurriculum(product.curriculum && product.curriculum.length > 0 ? product.curriculum : [
      { title: 'Module 1: Quickstart & Setup', duration: '45 mins', description: 'Immediate architecture and template imports.' }
    ]);
    setProdBonuses(product.bonuses && product.bonuses.length > 0 ? product.bonuses : []);
    setProdFaqs(product.faqs && product.faqs.length > 0 ? product.faqs : []);
    setProdPopular(!!product.popular);
    setProdFeatured(!!product.featured);
    setProdEditorSubTab('landing');
    setProdViewMode('editor');
  };

  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prodTitle.trim()) {
      setStatusMessage({ type: 'error', text: 'Product title is required.' });
      return;
    }

    setIsSubmitting(true);
    setStatusMessage(null);

    const deliverables = prodDeliverablesText
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean);

    const learningPoints = prodLearningPointsText
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean);

    const targetAudience = prodTargetAudienceText
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean);

    const slug = prodSlug.trim() || prodTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

    const productPayload: Partial<Product> = {
      title: prodTitle.trim(),
      slug,
      category: prodCategory,
      categoryLabel: prodCategoryLabel,
      tagline: prodTagline.trim(),
      description: prodDescription.trim(),
      fullDescription: prodFullDescription.trim() || prodDescription.trim(),
      priceINR: Number(prodPriceINR) || 999,
      originalPriceINR: Number(prodOriginalPriceINR) || 1999,
      badge: prodBadge.trim(),
      rating: Number(prodRating) || 4.9,
      reviewsCount: Number(prodReviewsCount) || 100,
      format: prodFormat.trim(),
      difficulty: prodDifficulty.trim(),
      imageUrl: prodImageUrl.trim(),
      paymentLink: prodPaymentLink.trim(),
      pdfUrl: prodPdfUrl.trim(),
      pdfFileName: prodPdfFileName.trim() || `${slug}.pdf`,
      samplePreviewTitle: prodSampleTitle.trim(),
      samplePreviewContent: prodSampleContent.trim(),
      deliverables,
      learningPoints,
      targetAudience,
      curriculum: prodCurriculum,
      bonuses: prodBonuses,
      faqs: prodFaqs,
      authorBio: prodAuthorBio.trim(),
      guaranteeText: prodGuaranteeText.trim(),
      popular: prodPopular,
      featured: prodFeatured,
    };

    try {
      if (editingProductId) {
        await updateProduct(editingProductId, productPayload);
        setStatusMessage({ type: 'success', text: `Product "${prodTitle}" updated successfully!` });
      } else {
        await createProduct(productPayload);
        setStatusMessage({ type: 'success', text: `New product "${prodTitle}" published successfully!` });
      }
      setTimeout(() => {
        setProdViewMode('list');
      }, 700);
    } catch (err: any) {
      console.error(err);
      setStatusMessage({ type: 'error', text: err?.message || 'Failed to save product.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteProduct = async (id: string, title: string) => {
    if (!window.confirm(`Are you sure you want to delete "${title}"? This cannot be undone.`)) {
      return;
    }
    try {
      await deleteProduct(id);
      setStatusMessage({ type: 'success', text: `Product "${title}" deleted.` });
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: 'Failed to delete product.' });
    }
  };

  const handleSeedProducts = async () => {
    if (!window.confirm('Reset all default products in Firestore database?')) return;
    setIsSeeding(true);
    try {
      await seedProducts();
      setStatusMessage({ type: 'success', text: 'Default products successfully synced into Firestore!' });
    } catch (err) {
      setStatusMessage({ type: 'error', text: 'Failed to seed products.' });
    } finally {
      setIsSeeding(false);
    }
  };

  // ----------------------------------------------------
  // BUNDLE ACTIONS
  // ----------------------------------------------------
  const handleOpenCreateBundle = () => {
    setEditingBundleId(null);
    setBundleTitle('');
    setBundleSlug('');
    setBundleSubtitle('');
    setBundleBadge('POPULAR BUNDLE');
    setBundleBadgeType('popular');
    setBundlePriceINR(2999);
    setBundleOriginalPriceINR(6999);
    setBundleSavingsPercent(57);
    setBundleImageUrl(PRODUCT_IMAGE_PRESETS[6].url);
    setBundlePdfUrl('');
    setBundlePdfFileName('');
    setBundleFullDescription('');
    setBundleFeaturesText('6 Complete Digital Toolkits & Video Guides\n50 Proven AI Income Streams & SOPs\nChatGPT Prompt Mega Pack (500+ Prompts)\nLifetime Access & Free Updates');
    setBundleIncludedProductsText('AI Freelancing Starter Kit\nAI Digital Products Playbook\nChatGPT Prompt Mega Pack\nAI Viral Video Vault');
    setBundleDeliverablesText('Master Side-Hustle Blueprint PDF (120+ pages)\nNotion Digital Command Center\n500+ Copy-Paste Prompts');
    setBundleTargetAudienceText('College students wanting independent income\nProfessionals seeking weekend side cash\nFreelancers offering AI consulting');
    setBundleCurriculum([
      { title: 'Module 1: The AI Income Landscape', duration: '2 Hours', description: 'Overview of top commercial models.' },
      { title: 'Module 2: Packaging & Selling Digital Assets', duration: '3 Hours', description: 'Step-by-step product launch.' }
    ]);
    setBundleBonuses([
      { title: 'Client Outreach Email Vault', valueINR: 1999, description: '15 copy-paste high-converting outreach scripts.' }
    ]);
    setBundleFaqs([
      { question: 'How do I download the bundle after purchase?', answer: 'Instant 1-click download access is provided on screen and via email.' }
    ]);
    setBundlePaymentLink('');
    setBundleEditorSubTab('landing');
    setBundleViewMode('editor');
  };

  const handleEditBundle = (bundle: Bundle) => {
    setEditingBundleId(bundle.id);
    setBundleTitle(bundle.title);
    setBundleSlug(bundle.slug || bundle.id);
    setBundleSubtitle(bundle.subtitle);
    setBundleBadge(bundle.badge);
    setBundleBadgeType(bundle.badgeType || 'popular');
    setBundlePriceINR(bundle.priceINR);
    setBundleOriginalPriceINR(bundle.originalPriceINR);
    setBundleSavingsPercent(bundle.savingsPercent || 50);
    setBundleImageUrl(bundle.imageUrl || '');
    setBundlePaymentLink(bundle.paymentLink || '');
    setBundlePdfUrl(bundle.pdfUrl || '');
    setBundlePdfFileName(bundle.pdfFileName || '');
    setBundleFullDescription(bundle.fullDescription || '');
    setBundleFeaturesText(Array.isArray(bundle.features) ? bundle.features.join('\n') : '');
    setBundleIncludedProductsText(Array.isArray(bundle.includedProducts) ? bundle.includedProducts.join('\n') : '');
    setBundleDeliverablesText(Array.isArray(bundle.deliverables) ? bundle.deliverables.join('\n') : '');
    setBundleTargetAudienceText(Array.isArray(bundle.targetAudience) ? bundle.targetAudience.join('\n') : '');
    setBundleCurriculum(bundle.curriculum && bundle.curriculum.length > 0 ? bundle.curriculum : [
      { title: 'Master Track 1: System Blueprint', duration: '2 Hours', description: 'Step-by-step setup.' }
    ]);
    setBundleBonuses(bundle.bonuses && bundle.bonuses.length > 0 ? bundle.bonuses : []);
    setBundleFaqs(bundle.faqs && bundle.faqs.length > 0 ? bundle.faqs : []);
    setBundleEditorSubTab('landing');
    setBundleViewMode('editor');
  };

  const handleSaveBundle = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bundleTitle.trim()) {
      setStatusMessage({ type: 'error', text: 'Bundle title is required.' });
      return;
    }

    setIsSubmitting(true);
    setStatusMessage(null);

    const features = bundleFeaturesText
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean);

    const includedProducts = bundleIncludedProductsText
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean);

    const deliverables = bundleDeliverablesText
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean);

    const targetAudience = bundleTargetAudienceText
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean);

    const slug = bundleSlug.trim() || bundleTitle.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');

    const bundlePayload: Partial<Bundle> = {
      title: bundleTitle.trim(),
      slug,
      subtitle: bundleSubtitle.trim(),
      badge: bundleBadge.trim() || 'SPECIAL BUNDLE',
      badgeType: bundleBadgeType,
      priceINR: Number(bundlePriceINR) || 2999,
      originalPriceINR: Number(bundleOriginalPriceINR) || 6999,
      savingsPercent: Number(bundleSavingsPercent) || 50,
      imageUrl: bundleImageUrl.trim(),
      paymentLink: bundlePaymentLink.trim(),
      pdfUrl: bundlePdfUrl.trim(),
      pdfFileName: bundlePdfFileName.trim() || `${slug}_Master.pdf`,
      fullDescription: bundleFullDescription.trim(),
      features,
      includedProducts,
      deliverables,
      targetAudience,
      curriculum: bundleCurriculum,
      bonuses: bundleBonuses,
      faqs: bundleFaqs,
    };

    try {
      if (editingBundleId) {
        await updateBundle(editingBundleId, bundlePayload);
        setStatusMessage({ type: 'success', text: `Bundle "${bundleTitle}" updated successfully!` });
      } else {
        await createBundle(bundlePayload);
        setStatusMessage({ type: 'success', text: `New Bundle "${bundleTitle}" created successfully!` });
      }
      setTimeout(() => {
        setBundleViewMode('list');
      }, 700);
    } catch (err: any) {
      console.error(err);
      setStatusMessage({ type: 'error', text: err?.message || 'Failed to save bundle.' });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleDeleteBundle = async (id: string, title: string) => {
    if (!window.confirm(`Are you sure you want to delete bundle "${title}"?`)) return;
    try {
      await deleteBundle(id);
      setStatusMessage({ type: 'success', text: `Bundle "${title}" deleted.` });
    } catch (err) {
      setStatusMessage({ type: 'error', text: 'Failed to delete bundle.' });
    }
  };

  const handleSeedBundles = async () => {
    if (!window.confirm('Reset all starter bundles in Firestore?')) return;
    setIsSeeding(true);
    try {
      await seedBundles();
      setStatusMessage({ type: 'success', text: 'Starter bundles successfully synced to Firestore!' });
    } catch (err) {
      setStatusMessage({ type: 'error', text: 'Failed to seed bundles.' });
    } finally {
      setIsSeeding(false);
    }
  };

  const handleSavePaymentSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingPaymentSettings(true);
    setStatusMessage(null);
    try {
      await updatePaymentSettings({
        defaultRazorpayUrl: payDefaultUrl.trim(),
        razorpayKeyId: payKeyId.trim(),
        merchantUpiId: payUpiId.trim(),
        merchantName: payMerchantName.trim(),
        directRedirectOnAccess: payDirectRedirect,
        resendApiKey: payResendApiKey.trim(),
        notificationWebhookUrl: payWebhookUrl.trim(),
        senderEmail: paySenderEmail.trim(),
      });
      setStatusMessage({
        type: 'success',
        text: 'Payment Gateway & Automated Email Delivery settings successfully updated!',
      });
    } catch (err: any) {
      console.error(err);
      setStatusMessage({
        type: 'error',
        text: err?.message || 'Failed to save payment settings.',
      });
    } finally {
      setIsSavingPaymentSettings(false);
    }
  };

  return (
    <div
      id="admin-products-panel"
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto animate-fadeIn"
    >
      <div className="bg-white rounded-3xl max-w-6xl w-full h-[94vh] flex flex-col shadow-2xl border border-slate-200 overflow-hidden">
        
        {/* TOP HEADER */}
        <header className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-blue-600 flex items-center justify-center shadow-md shadow-blue-500/20">
              <Package className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base sm:text-lg tracking-tight text-white">
                  ApexAI Store &amp; Landing Page CMS
                </h3>
                <span className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-[10px] font-black uppercase px-2 py-0.5 rounded">
                  WordPress Format
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Design details pages, manage PDF access, curriculum, bonuses, and high-value bundles.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 sm:gap-3">
            {isAuthorized && (
              <button
                onClick={handleOwnerLogout}
                className="text-xs text-slate-400 hover:text-rose-400 flex items-center gap-1 px-2 py-1 rounded transition cursor-pointer"
                title="Lock CMS"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Lock</span>
              </button>
            )}

            <button
              onClick={onClose}
              className="text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 w-9 h-9 rounded-xl flex items-center justify-center transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </header>

        {/* AUTH CHECK SCREEN */}
        {!isAuthorized ? (
          <div className="flex-1 p-6 sm:p-12 flex flex-col items-center justify-center max-w-md mx-auto text-center">
            <div className="w-14 h-14 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mb-4 border border-blue-100 shadow-sm">
              <KeyRound className="w-7 h-7" />
            </div>
            <h4 className="text-2xl font-black text-slate-900 tracking-tight">
              Founder &amp; Admin Verification
            </h4>
            <p className="text-xs text-slate-500 mt-2 leading-relaxed">
              Enter the master passcode or sign in with your Google Account ({ADMIN_EMAIL}) to unlock the Landing Page &amp; Product CMS.
            </p>

            <form onSubmit={handlePasscodeSubmit} className="mt-6 w-full space-y-3">
              <div>
                <input
                  type="password"
                  value={passcodeInput}
                  onChange={(e) => {
                    setPasscodeInput(e.target.value);
                    setPasscodeError(false);
                  }}
                  placeholder="Enter Master Passcode (e.g. APEX2026)"
                  className="w-full text-center px-4 py-3 border border-slate-300 rounded-xl font-mono text-sm tracking-widest focus:ring-2 focus:ring-blue-600 focus:outline-none"
                  autoFocus
                />
                {passcodeError && (
                  <p className="text-xs text-rose-600 font-semibold mt-1">
                    Incorrect master passcode. Try: APEX2026 or DIPAK
                  </p>
                )}
              </div>

              <button
                type="submit"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-xl transition text-xs sm:text-sm shadow-md shadow-blue-500/20 cursor-pointer"
              >
                Unlock CMS Dashboard
              </button>
            </form>

            <div className="relative my-6 w-full flex items-center justify-center">
              <div className="border-t border-slate-200 w-full" />
              <span className="bg-white px-3 text-[11px] text-slate-400 uppercase font-semibold absolute">
                or sign in
              </span>
            </div>

            <button
              onClick={signInWithGoogle}
              className="w-full bg-slate-900 hover:bg-slate-800 text-white font-semibold py-3 rounded-xl transition text-xs flex items-center justify-center gap-2 cursor-pointer shadow-sm"
            >
              <span>Sign In with Google ({ADMIN_EMAIL})</span>
            </button>
          </div>
        ) : (
          /* MAIN AUTHORIZED VIEW */
          <div className="flex-1 flex flex-col min-h-0 bg-slate-50">
            
            {/* CMS NAVIGATION TABS (Products vs Bundles) */}
            <div className="bg-white border-b border-slate-200 px-6 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shrink-0">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveSection('products')}
                  className={`px-4 py-2 rounded-xl font-bold text-xs sm:text-sm transition flex items-center gap-2 cursor-pointer ${
                    activeSection === 'products'
                      ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  <Package className="w-4 h-4" />
                  <span>Individual Products CMS</span>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                    activeSection === 'products' ? 'bg-blue-700 text-white' : 'bg-slate-200 text-slate-600'
                  }`}>
                    {displayProducts.length}
                  </span>
                </button>

                <button
                  onClick={() => setActiveSection('bundles')}
                  className={`px-4 py-2 rounded-xl font-bold text-xs sm:text-sm transition flex items-center gap-2 cursor-pointer ${
                    activeSection === 'bundles'
                      ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-500/20'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  <Sparkles className="w-4 h-4" />
                  <span>High-Value Bundles CMS</span>
                  <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                    activeSection === 'bundles' ? 'bg-indigo-700 text-white' : 'bg-slate-200 text-slate-600'
                  }`}>
                    {displayBundles.length}
                  </span>
                </button>

                <button
                  onClick={() => setActiveSection('payments')}
                  className={`px-4 py-2 rounded-xl font-bold text-xs sm:text-sm transition flex items-center gap-2 cursor-pointer ${
                    activeSection === 'payments'
                      ? 'bg-emerald-600 text-white shadow-sm shadow-emerald-500/20'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  }`}
                >
                  <CreditCard className="w-4 h-4" />
                  <span>Razorpay Gateway</span>
                  {paymentSettings?.defaultRazorpayUrl ? (
                    <span className="text-[10px] px-1.5 py-0.5 rounded font-bold bg-emerald-700 text-white">
                      Active
                    </span>
                  ) : (
                    <span className="text-[10px] px-1.5 py-0.5 rounded font-bold bg-amber-100 text-amber-800">
                      Setup
                    </span>
                  )}
                </button>
              </div>

              {/* Status alerts */}
              {statusMessage && (
                <div
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 animate-fadeIn ${
                    statusMessage.type === 'success'
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      : 'bg-rose-50 text-rose-700 border border-rose-200'
                  }`}
                >
                  {statusMessage.type === 'success' ? (
                    <CheckCircle2 className="w-3.5 h-3.5 shrink-0 text-emerald-600" />
                  ) : (
                    <AlertCircle className="w-3.5 h-3.5 shrink-0 text-rose-600" />
                  )}
                  <span>{statusMessage.text}</span>
                </div>
              )}
            </div>

            {/* ========================================================================= */}
            {/* SECTION 1: PRODUCTS CMS */}
            {/* ========================================================================= */}
            {activeSection === 'products' && (
              <div className="flex-1 flex flex-col min-h-0 overflow-y-auto">
                {prodViewMode === 'list' ? (
                  /* PRODUCT LIST VIEW */
                  <div className="p-6 max-w-7xl mx-auto w-full space-y-6">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="relative flex-1 max-w-md">
                        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                        <input
                          type="text"
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          placeholder="Search products by title, category, or tagline..."
                          className="w-full pl-9 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-blue-600"
                        />
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={handleSeedProducts}
                          disabled={isSeeding}
                          className="px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-sm disabled:opacity-50"
                          title="Reset default products in Firestore"
                        >
                          <RotateCcw className={`w-3.5 h-3.5 ${isSeeding ? 'animate-spin' : ''}`} />
                          <span>{isSeeding ? 'Syncing...' : 'Sync Defaults'}</span>
                        </button>

                        <button
                          onClick={handleOpenCreateProduct}
                          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-2 shadow-md shadow-blue-500/20 cursor-pointer"
                        >
                          <Plus className="w-4 h-4" />
                          <span>+ Add New Product</span>
                        </button>
                      </div>
                    </div>

                    {/* Products Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                      {filteredProducts.map((prod) => (
                        <div
                          key={prod.id}
                          className="bg-white rounded-2xl border border-slate-200 p-5 flex flex-col justify-between shadow-sm hover:shadow-md transition"
                        >
                          <div>
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-100">
                                {prod.categoryLabel}
                              </span>
                              {prod.badge && (
                                <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-amber-50 text-amber-700">
                                  {prod.badge}
                                </span>
                              )}
                            </div>

                            <h4 className="font-extrabold text-slate-900 text-base leading-snug line-clamp-1">
                              {prod.title}
                            </h4>
                            <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                              {prod.tagline || prod.description}
                            </p>

                            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                              <div>
                                <span className="font-extrabold text-slate-900 text-sm">
                                  ₹{prod.priceINR.toLocaleString('en-IN')}
                                </span>
                                <span className="text-slate-400 line-through text-[11px] ml-1.5">
                                  ₹{prod.originalPriceINR.toLocaleString('en-IN')}
                                </span>
                              </div>
                              <span className="text-[11px] text-slate-500 font-medium">
                                {prod.format}
                              </span>
                            </div>
                          </div>

                          <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                            <button
                              onClick={() => onPreviewProduct(prod)}
                              className="text-xs font-bold text-blue-600 hover:text-blue-700 hover:underline flex items-center gap-1 cursor-pointer"
                            >
                              <ExternalLink className="w-3 h-3" />
                              <span>View Details Page</span>
                            </button>

                            <div className="flex items-center gap-1.5">
                              <button
                                onClick={() => handleEditProduct(prod)}
                                className="p-2 text-slate-600 hover:text-blue-600 bg-slate-50 hover:bg-blue-50 rounded-lg transition cursor-pointer"
                                title="Edit Product & Landing Page"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDeleteProduct(prod.id, prod.title)}
                                className="p-2 text-slate-400 hover:text-rose-600 bg-slate-50 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                                title="Delete Product"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  /* PRODUCT WORDPRESS-STYLE EDITOR VIEW */
                  <div className="p-6 max-w-5xl mx-auto w-full">
                    <div className="flex items-center justify-between mb-6">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setProdViewMode('list')}
                          className="text-xs font-bold text-slate-500 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 px-3 py-1.5 rounded-lg transition cursor-pointer"
                        >
                          ← Back to Product List
                        </button>
                        <h4 className="font-extrabold text-slate-900 text-lg">
                          {editingProductId ? `Edit: ${prodTitle}` : 'Create New Product Landing Page'}
                        </h4>
                        {editingProductId && onPreviewProduct && (
                          <button
                            type="button"
                            onClick={() => {
                              const p = displayProducts.find((x) => x.id === editingProductId);
                              if (p) onPreviewProduct(p);
                            }}
                            className="text-xs font-bold text-blue-600 hover:text-blue-700 bg-blue-50 hover:bg-blue-100 px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 cursor-pointer ml-2 border border-blue-200"
                            title="Preview this product's dynamic landing page"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>Preview Landing Page</span>
                          </button>
                        )}
                      </div>

                      {/* Sub-tabs in editor - WordPress Builder First */}
                      <div className="flex items-center gap-1 bg-slate-100 p-1.5 rounded-xl border border-slate-200">
                        <button
                          type="button"
                          onClick={() => setProdEditorSubTab('landing')}
                          className={`px-3.5 py-2 rounded-lg text-xs font-extrabold transition cursor-pointer flex items-center gap-1.5 ${
                            prodEditorSubTab === 'landing'
                              ? 'bg-blue-600 text-white shadow-sm'
                              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                          }`}
                        >
                          <BookOpen className="w-3.5 h-3.5" />
                          <span>1. WordPress Landing Page</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setProdEditorSubTab('general')}
                          className={`px-3.5 py-2 rounded-lg text-xs font-bold transition cursor-pointer ${
                            prodEditorSubTab === 'general'
                              ? 'bg-white text-slate-900 shadow-sm'
                              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                          }`}
                        >
                          2. Core Card &amp; Pricing
                        </button>
                        <button
                          type="button"
                          onClick={() => setProdEditorSubTab('assets')}
                          className={`px-3.5 py-2 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                            prodEditorSubTab === 'assets'
                              ? 'bg-white text-slate-900 shadow-sm'
                              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                          }`}
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>3. PDF File &amp; Delivery</span>
                        </button>
                      </div>
                    </div>

                    <form onSubmit={handleSaveProduct} className="space-y-6">
                      
                      {/* TAB 1: CORE & PRICING */}
                      {prodEditorSubTab === 'general' && (
                        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-5 animate-fadeIn">
                          <h5 className="font-extrabold text-slate-900 text-sm border-b border-slate-100 pb-3">
                            Basic Information &amp; Pricing Details
                          </h5>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                              <label className="block text-xs font-bold text-slate-700 mb-1">
                                Product Title *
                              </label>
                              <input
                                type="text"
                                required
                                value={prodTitle}
                                onChange={(e) => setProdTitle(e.target.value)}
                                placeholder="e.g. AI WhatsApp Sales Bot Kit"
                                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold focus:ring-2 focus:ring-blue-600 focus:outline-none"
                              />
                            </div>

                            <div>
                              <label className="block text-xs font-bold text-slate-700 mb-1">
                                URL Slug (WordPress format)
                              </label>
                              <input
                                type="text"
                                value={prodSlug}
                                onChange={(e) => setProdSlug(e.target.value)}
                                placeholder="e.g. ai-whatsapp-sales-bot-kit"
                                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-mono focus:ring-2 focus:ring-blue-600 focus:outline-none"
                              />
                            </div>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                            <div>
                              <label className="block text-xs font-bold text-slate-700 mb-1">
                                Category
                              </label>
                              <select
                                value={prodCategory}
                                onChange={(e) => {
                                  setProdCategory(e.target.value);
                                  const found = CATEGORIES.find((c) => c.id === e.target.value);
                                  if (found) setProdCategoryLabel(found.label);
                                }}
                                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold focus:ring-2 focus:ring-blue-600 focus:outline-none cursor-pointer"
                              >
                                {CATEGORIES.map((cat) => (
                                  <option key={cat.id} value={cat.id}>
                                    {cat.label}
                                  </option>
                                ))}
                              </select>
                            </div>

                            <div>
                              <label className="block text-xs font-bold text-slate-700 mb-1">
                                Category Display Label
                              </label>
                              <input
                                type="text"
                                value={prodCategoryLabel}
                                onChange={(e) => setProdCategoryLabel(e.target.value)}
                                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-blue-600 focus:outline-none"
                              />
                            </div>

                            <div>
                              <label className="block text-xs font-bold text-slate-700 mb-1">
                                Badge Tag
                              </label>
                              <input
                                type="text"
                                value={prodBadge}
                                onChange={(e) => setProdBadge(e.target.value)}
                                placeholder="e.g. BESTSELLER or NEW"
                                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-blue-600 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                              />
                            </div>
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                            <div>
                              <label className="block text-xs font-bold text-slate-700 mb-1">
                                Price (₹ INR) *
                              </label>
                              <input
                                type="number"
                                required
                                value={prodPriceINR}
                                onChange={(e) => setProdPriceINR(Number(e.target.value))}
                                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-black text-slate-900 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                              />
                            </div>

                            <div>
                              <label className="block text-xs font-bold text-slate-700 mb-1">
                                Original Price / MRP (₹)
                              </label>
                              <input
                                type="number"
                                value={prodOriginalPriceINR}
                                onChange={(e) => setProdOriginalPriceINR(Number(e.target.value))}
                                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-500 line-through focus:ring-2 focus:ring-blue-600 focus:outline-none"
                              />
                            </div>

                            <div>
                              <label className="block text-xs font-bold text-slate-700 mb-1">
                                Format
                              </label>
                              <input
                                type="text"
                                value={prodFormat}
                                onChange={(e) => setProdFormat(e.target.value)}
                                placeholder="PDF Guide + Blueprints"
                                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-blue-600 focus:outline-none"
                              />
                            </div>

                            <div>
                              <label className="block text-xs font-bold text-slate-700 mb-1">
                                Difficulty Level
                              </label>
                              <select
                                value={prodDifficulty}
                                onChange={(e) => setProdDifficulty(e.target.value)}
                                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold focus:ring-2 focus:ring-blue-600 focus:outline-none cursor-pointer"
                              >
                                <option value="Beginner">Beginner</option>
                                <option value="Intermediate">Intermediate</option>
                                <option value="Advanced">Advanced</option>
                                <option value="All Levels">All Levels</option>
                              </select>
                            </div>
                          </div>

                          {/* Custom Razorpay Payment Gateway URL */}
                          <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl border-2 border-blue-200/80 space-y-2">
                            <div className="flex items-center justify-between">
                              <label className="text-xs font-bold text-blue-900 flex items-center gap-1.5">
                                <CreditCard className="w-4 h-4 text-blue-600" />
                                <span>Custom Razorpay Payment URL (Direct Payment Gateway Link)</span>
                              </label>
                              {prodPaymentLink && (
                                <a
                                  href={prodPaymentLink}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-[11px] font-bold text-blue-600 hover:text-blue-800 underline flex items-center gap-1"
                                >
                                  <span>Test Link</span>
                                  <ExternalLink className="w-3 h-3" />
                                </a>
                              )}
                            </div>
                            <input
                              type="url"
                              value={prodPaymentLink}
                              onChange={(e) => setProdPaymentLink(e.target.value)}
                              placeholder="e.g. https://rzp.io/l/your-razorpay-link or https://pages.razorpay.com/..."
                              className="w-full px-3.5 py-2.5 bg-white border border-blue-300 rounded-xl text-xs sm:text-sm font-mono text-slate-900 focus:ring-2 focus:ring-blue-600 focus:outline-none"
                            />
                            <p className="text-[11px] text-slate-600 leading-relaxed">
                              Paste your Razorpay Payment Page or Payment Link for this product. When customers click <strong>&quot;Get Access&quot;</strong>, they will be directed to this Razorpay gateway so you receive payment directly to your account. (Leave empty to use store default link).
                            </p>
                          </div>

                          <div>
                            <label className="block text-xs font-bold text-slate-700 mb-1">
                              Tagline / Subheading
                            </label>
                            <input
                              type="text"
                              value={prodTagline}
                              onChange={(e) => setProdTagline(e.target.value)}
                              placeholder="Brief 1-sentence value hook"
                              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-blue-600 focus:outline-none"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-bold text-slate-700 mb-1">
                              Short Description (Modal &amp; Catalog preview)
                            </label>
                            <textarea
                              rows={3}
                              value={prodDescription}
                              onChange={(e) => setProdDescription(e.target.value)}
                              placeholder="Overview shown on product cards and quick-view popups..."
                              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm leading-relaxed focus:ring-2 focus:ring-blue-600 focus:outline-none"
                            />
                          </div>
                        </div>
                      )}

                      {/* TAB 2: WORDPRESS LANDING PAGE BUILDER */}
                      {prodEditorSubTab === 'landing' && (
                        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6 animate-fadeIn">
                          <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                            <div>
                              <h5 className="font-extrabold text-slate-900 text-base">
                                WordPress-Style Landing Page Content
                              </h5>
                              <p className="text-xs text-slate-500">
                                Enter rich curriculum, target audience, bonuses, and deep sales letter copy.
                              </p>
                            </div>
                            <span className="text-[11px] font-bold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-lg">
                              Live Page Renderer
                            </span>
                          </div>

                          {/* Full Longform Description */}
                          <div>
                            <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1.5">
                              <FileText className="w-3.5 h-3.5 text-blue-600" />
                              <span>Full Longform Sales Letter / Story</span>
                            </label>
                            <textarea
                              rows={6}
                              value={prodFullDescription}
                              onChange={(e) => setProdFullDescription(e.target.value)}
                              placeholder="Write a deep, persuasive description of the product, the problem it solves, and how to execute it..."
                              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-sans leading-relaxed focus:ring-2 focus:ring-blue-600 focus:outline-none"
                            />
                          </div>

                          {/* Learning Outcomes / Takeaways */}
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1.5">
                                <Target className="w-3.5 h-3.5 text-emerald-600" />
                                <span>What You Will Achieve (1 outcome per line)</span>
                              </label>
                              <textarea
                                rows={4}
                                value={prodLearningPointsText}
                                onChange={(e) => setProdLearningPointsText(e.target.value)}
                                placeholder="🚀 Save 15+ hours each week&#10;💰 Close ₹50,000 clients&#10;⚡ Zero coding needed"
                                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm leading-relaxed focus:ring-2 focus:ring-blue-600 focus:outline-none"
                              />
                            </div>

                            <div>
                              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1.5">
                                <Target className="w-3.5 h-3.5 text-purple-600" />
                                <span>Target Audience (1 persona per line)</span>
                              </label>
                              <textarea
                                rows={4}
                                value={prodTargetAudienceText}
                                onChange={(e) => setProdTargetAudienceText(e.target.value)}
                                placeholder="Agencies wanting to cut labor costs&#10;Freelancers building an automation agency&#10;E-commerce founders needing 24/7 bots"
                                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm leading-relaxed focus:ring-2 focus:ring-blue-600 focus:outline-none"
                              />
                            </div>
                          </div>

                          {/* Curriculum Syllabus Modules (Dynamic) */}
                          <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/70 space-y-3">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                                <BookOpen className="w-3.5 h-3.5 text-blue-600" />
                                <span>Curriculum Syllabus Modules ({prodCurriculum.length})</span>
                              </span>
                              <button
                                type="button"
                                onClick={() =>
                                  setProdCurriculum([
                                    ...prodCurriculum,
                                    { title: `Module ${prodCurriculum.length + 1}: New Chapter`, duration: '1 Hour', description: 'Module breakdown and deliverables.' }
                                  ])
                                }
                                className="text-xs font-bold text-blue-600 hover:text-blue-700 bg-white border border-slate-200 px-2.5 py-1 rounded-lg transition cursor-pointer"
                              >
                                + Add Module
                              </button>
                            </div>

                            <div className="space-y-2.5">
                              {prodCurriculum.map((mod, idx) => (
                                <div key={idx} className="bg-white p-3 rounded-xl border border-slate-200 flex flex-col gap-2">
                                  <div className="flex items-center gap-2">
                                    <input
                                      type="text"
                                      value={mod.title}
                                      onChange={(e) => {
                                        const next = [...prodCurriculum];
                                        next[idx].title = e.target.value;
                                        setProdCurriculum(next);
                                      }}
                                      placeholder="Module Title"
                                      className="flex-1 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold"
                                    />
                                    <input
                                      type="text"
                                      value={mod.duration || ''}
                                      onChange={(e) => {
                                        const next = [...prodCurriculum];
                                        next[idx].duration = e.target.value;
                                        setProdCurriculum(next);
                                      }}
                                      placeholder="Duration (e.g. 45 mins)"
                                      className="w-32 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                                    />
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const next = prodCurriculum.filter((_, i) => i !== idx);
                                        setProdCurriculum(next);
                                      }}
                                      className="text-rose-500 hover:text-rose-700 p-1 cursor-pointer"
                                      title="Remove Module"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                  <input
                                    type="text"
                                    value={mod.description || ''}
                                    onChange={(e) => {
                                      const next = [...prodCurriculum];
                                      next[idx].description = e.target.value;
                                      setProdCurriculum(next);
                                    }}
                                    placeholder="Brief summary of what's covered..."
                                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-600"
                                  />
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Bonuses Dynamic Stack */}
                          <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/70 space-y-3">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                                <Gift className="w-3.5 h-3.5 text-amber-600" />
                                <span>Exclusive Included Bonuses ({prodBonuses.length})</span>
                              </span>
                              <button
                                type="button"
                                onClick={() =>
                                  setProdBonuses([
                                    ...prodBonuses,
                                    { title: 'New High-Value Bonus', valueINR: 1499, description: 'Exclusive bonus item description.' }
                                  ])
                                }
                                className="text-xs font-bold text-amber-700 hover:text-amber-800 bg-white border border-slate-200 px-2.5 py-1 rounded-lg transition cursor-pointer"
                              >
                                + Add Bonus
                              </button>
                            </div>

                            <div className="space-y-2.5">
                              {prodBonuses.map((bonus, idx) => (
                                <div key={idx} className="bg-white p-3 rounded-xl border border-slate-200 flex flex-col gap-2">
                                  <div className="flex items-center gap-2">
                                    <input
                                      type="text"
                                      value={bonus.title}
                                      onChange={(e) => {
                                        const next = [...prodBonuses];
                                        next[idx].title = e.target.value;
                                        setProdBonuses(next);
                                      }}
                                      placeholder="Bonus Title"
                                      className="flex-1 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold"
                                    />
                                    <div className="flex items-center gap-1 text-xs">
                                      <span>Value ₹</span>
                                      <input
                                        type="number"
                                        value={bonus.valueINR}
                                        onChange={(e) => {
                                          const next = [...prodBonuses];
                                          next[idx].valueINR = Number(e.target.value);
                                          setProdBonuses(next);
                                        }}
                                        className="w-24 px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold"
                                      />
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const next = prodBonuses.filter((_, i) => i !== idx);
                                        setProdBonuses(next);
                                      }}
                                      className="text-rose-500 hover:text-rose-700 p-1 cursor-pointer"
                                      title="Remove Bonus"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                  <input
                                    type="text"
                                    value={bonus.description}
                                    onChange={(e) => {
                                      const next = [...prodBonuses];
                                      next[idx].description = e.target.value;
                                      setProdBonuses(next);
                                    }}
                                    placeholder="Bonus description..."
                                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-600"
                                  />
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Custom FAQs */}
                          <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/70 space-y-3">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                                <HelpCircle className="w-3.5 h-3.5 text-blue-600" />
                                <span>Product FAQs ({prodFaqs.length})</span>
                              </span>
                              <button
                                type="button"
                                onClick={() =>
                                  setProdFaqs([
                                    ...prodFaqs,
                                    { question: 'Common user question?', answer: 'Clear, direct answer explaining the value.' }
                                  ])
                                }
                                className="text-xs font-bold text-blue-600 hover:text-blue-700 bg-white border border-slate-200 px-2.5 py-1 rounded-lg transition cursor-pointer"
                              >
                                + Add FAQ
                              </button>
                            </div>

                            <div className="space-y-2.5">
                              {prodFaqs.map((faq, idx) => (
                                <div key={idx} className="bg-white p-3 rounded-xl border border-slate-200 flex flex-col gap-2">
                                  <div className="flex items-center gap-2">
                                    <input
                                      type="text"
                                      value={faq.question}
                                      onChange={(e) => {
                                        const next = [...prodFaqs];
                                        next[idx].question = e.target.value;
                                        setProdFaqs(next);
                                      }}
                                      placeholder="Question"
                                      className="flex-1 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold"
                                    />
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const next = prodFaqs.filter((_, i) => i !== idx);
                                        setProdFaqs(next);
                                      }}
                                      className="text-rose-500 hover:text-rose-700 p-1 cursor-pointer"
                                      title="Remove FAQ"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                  <textarea
                                    rows={2}
                                    value={faq.answer}
                                    onChange={(e) => {
                                      const next = [...prodFaqs];
                                      next[idx].answer = e.target.value;
                                      setProdFaqs(next);
                                    }}
                                    placeholder="Answer..."
                                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-600"
                                  />
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      )}

                      {/* TAB 3: PDF DELIVERY & ASSETS */}
                      {prodEditorSubTab === 'assets' && (
                        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-5 animate-fadeIn">
                          <h5 className="font-extrabold text-slate-900 text-sm border-b border-slate-100 pb-3">
                            PDF Download Link &amp; Product Deliverables
                          </h5>

                          <div className="p-4 bg-emerald-50 rounded-xl border border-emerald-200 text-emerald-800 text-xs leading-relaxed">
                            <strong>Strict PDF Delivery:</strong> Only customers who purchase this specific product (or an all-access bundle) will be granted access to download this PDF file.
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                              <label className="block text-xs font-bold text-slate-700 mb-1">
                                Direct PDF Download URL
                              </label>
                              <input
                                type="url"
                                value={prodPdfUrl}
                                onChange={(e) => setProdPdfUrl(e.target.value)}
                                placeholder="https://drive.google.com/... or cloud PDF link"
                                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-mono focus:ring-2 focus:ring-blue-600 focus:outline-none"
                              />
                            </div>

                            <div>
                              <label className="block text-xs font-bold text-slate-700 mb-1">
                                Download File Name
                              </label>
                              <input
                                type="text"
                                value={prodPdfFileName}
                                onChange={(e) => setProdPdfFileName(e.target.value)}
                                placeholder="e.g. WhatsApp_Bot_Master_Toolkit.pdf"
                                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-mono focus:ring-2 focus:ring-blue-600 focus:outline-none"
                              />
                            </div>
                          </div>

                          {/* Image Presets */}
                          <div>
                            <label className="block text-xs font-bold text-slate-700 mb-1">
                              Cover Image URL
                            </label>
                            <input
                              type="url"
                              value={prodImageUrl}
                              onChange={(e) => setProdImageUrl(e.target.value)}
                              placeholder="https://images.unsplash.com/..."
                              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-mono focus:ring-2 focus:ring-blue-600 focus:outline-none mb-2"
                            />
                            <span className="text-[11px] font-bold text-slate-500 block mb-1.5">
                              Or pick from curated presets:
                            </span>
                            <div className="flex flex-wrap gap-1.5">
                              {PRODUCT_IMAGE_PRESETS.map((p, i) => (
                                <button
                                  type="button"
                                  key={i}
                                  onClick={() => setProdImageUrl(p.url)}
                                  className="text-[11px] font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 px-2.5 py-1 rounded-lg transition cursor-pointer"
                                >
                                  {p.name}
                                </button>
                              ))}
                            </div>
                          </div>

                          {/* Deliverables list */}
                          <div>
                            <label className="block text-xs font-bold text-slate-700 mb-1">
                              Included Deliverables (1 item per line)
                            </label>
                            <textarea
                              rows={3}
                              value={prodDeliverablesText}
                              onChange={(e) => setProdDeliverablesText(e.target.value)}
                              placeholder="PDF Master Playbook (80+ pages)&#10;Notion Dashboard Workspace&#10;Make.com Automation Blueprints"
                              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm leading-relaxed focus:ring-2 focus:ring-blue-600 focus:outline-none"
                            />
                          </div>

                          {/* Sample Blueprint Snippet */}
                          <div className="border-t border-slate-100 pt-4 space-y-3">
                            <label className="block text-xs font-bold text-slate-700">
                              Free Sample Prompt / Blueprint Snippet (Terminal Preview)
                            </label>
                            <input
                              type="text"
                              value={prodSampleTitle}
                              onChange={(e) => setProdSampleTitle(e.target.value)}
                              placeholder="Prompt Title (e.g. 1-Click Client Outreach Prompt)"
                              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                            />
                            <textarea
                              rows={3}
                              value={prodSampleContent}
                              onChange={(e) => setProdSampleContent(e.target.value)}
                              placeholder="Copy-paste snippet preview that visitors can see on the landing page..."
                              className="w-full px-3.5 py-2 bg-slate-900 text-emerald-400 font-mono text-xs rounded-xl"
                            />
                          </div>
                        </div>
                      )}

                      {/* BOTTOM SUBMIT BAR */}
                      <div className="flex items-center justify-between pt-2">
                        <button
                          type="button"
                          onClick={() => setProdViewMode('list')}
                          className="bg-slate-200 hover:bg-slate-300 text-slate-700 px-5 py-2.5 rounded-xl font-bold text-xs transition cursor-pointer"
                        >
                          Cancel
                        </button>

                        <div className="flex items-center gap-3">
                          <button
                            type="submit"
                            disabled={isSubmitting}
                            className="bg-blue-600 hover:bg-blue-700 text-white font-extrabold px-8 py-3 rounded-xl transition text-xs sm:text-sm shadow-md shadow-blue-500/20 cursor-pointer disabled:opacity-50 flex items-center gap-2"
                          >
                            {isSubmitting ? (
                              <span>Saving to Database...</span>
                            ) : (
                              <>
                                <Check className="w-4 h-4" />
                                <span>{editingProductId ? 'Update Product & Landing Page' : 'Publish Product'}</span>
                              </>
                            )}
                          </button>
                        </div>
                      </div>
                    </form>
                  </div>
                )}
              </div>
            )}

            {/* ========================================================================= */}
            {/* SECTION 2: HIGH-VALUE BUNDLES CMS */}
            {/* ========================================================================= */}
            {activeSection === 'bundles' && (
              <div className="flex-1 flex flex-col min-h-0 overflow-y-auto">
                {bundleViewMode === 'list' ? (
                  /* BUNDLE LIST VIEW */
                  <div className="p-6 max-w-7xl mx-auto w-full space-y-6">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="relative flex-1 max-w-md">
                        <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                        <input
                          type="text"
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          placeholder="Search high-value bundles..."
                          className="w-full pl-9 pr-4 py-2.5 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600"
                        />
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={handleSeedBundles}
                          disabled={isSeeding}
                          className="px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-50 text-slate-700 text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-sm disabled:opacity-50"
                          title="Reset default starter bundles in Firestore"
                        >
                          <RotateCcw className={`w-3.5 h-3.5 ${isSeeding ? 'animate-spin' : ''}`} />
                          <span>{isSeeding ? 'Syncing...' : 'Sync Default Bundles'}</span>
                        </button>

                        <button
                          onClick={handleOpenCreateBundle}
                          className="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-2 shadow-md shadow-indigo-500/20 cursor-pointer"
                        >
                          <Plus className="w-4 h-4" />
                          <span>+ Create High-Value Bundle</span>
                        </button>
                      </div>
                    </div>

                    {/* Bundles Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                      {filteredBundles.map((b) => (
                        <div
                          key={b.id}
                          className="bg-white rounded-2xl border-2 border-indigo-100 p-5 flex flex-col justify-between shadow-sm hover:shadow-md transition"
                        >
                          <div>
                            <div className="flex items-center justify-between mb-2">
                              <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-200">
                                {b.badge}
                              </span>
                              <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded bg-emerald-50 text-emerald-700">
                                SAVE {b.savingsPercent}%
                              </span>
                            </div>

                            <h4 className="font-extrabold text-slate-900 text-base leading-snug line-clamp-1">
                              {b.title}
                            </h4>
                            <p className="text-xs text-slate-500 mt-1 line-clamp-2 leading-relaxed">
                              {b.subtitle}
                            </p>

                            <div className="mt-3 bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-[11px] text-slate-600 font-medium space-y-1">
                              <div>Included: {b.includedProducts.length} Standalone Packs</div>
                              <div>Features: {b.features.length} Highlight Bullets</div>
                            </div>

                            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                              <div>
                                <span className="font-extrabold text-indigo-700 text-base">
                                  ₹{b.priceINR.toLocaleString('en-IN')}
                                </span>
                                <span className="text-slate-400 line-through text-[11px] ml-1.5">
                                  ₹{b.originalPriceINR.toLocaleString('en-IN')}
                                </span>
                              </div>
                              <span className="text-[10px] bg-slate-100 px-2 py-0.5 rounded font-mono font-bold text-slate-600">
                                {b.badgeType || 'bundle'}
                              </span>
                            </div>
                          </div>

                          <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                            {onPreviewBundle ? (
                              <button
                                onClick={() => onPreviewBundle(b)}
                                className="text-xs font-bold text-indigo-600 hover:text-indigo-700 hover:underline flex items-center gap-1 cursor-pointer"
                              >
                                <ExternalLink className="w-3 h-3" />
                                <span>Landing Page</span>
                              </button>
                            ) : (
                              <span className="text-xs text-slate-400 font-medium">Bundle Pack</span>
                            )}

                            <div className="flex items-center gap-1.5">
                              <button
                                onClick={() => handleEditBundle(b)}
                                className="p-2 text-slate-600 hover:text-indigo-600 bg-slate-50 hover:bg-indigo-50 rounded-lg transition cursor-pointer"
                                title="Edit Bundle & Landing Page"
                              >
                                <Edit3 className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDeleteBundle(b.id, b.title)}
                                className="p-2 text-slate-400 hover:text-rose-600 bg-slate-50 hover:bg-rose-50 rounded-lg transition cursor-pointer"
                                title="Delete Bundle"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ) : (
                  /* BUNDLE HIGH-VALUE BUILDER VIEW */
                  <div className="p-6 max-w-5xl mx-auto w-full">
                    <div className="flex items-center justify-between mb-6">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => setBundleViewMode('list')}
                          className="text-xs font-bold text-slate-500 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 px-3 py-1.5 rounded-lg transition cursor-pointer"
                        >
                          ← Back to Bundle List
                        </button>
                        <h4 className="font-extrabold text-slate-900 text-lg">
                          {editingBundleId ? `Edit: ${bundleTitle}` : 'Create High-Value Bundle Landing Page'}
                        </h4>
                        {editingBundleId && onPreviewBundle && (
                          <button
                            type="button"
                            onClick={() => {
                              const b = displayBundles.find((x) => x.id === editingBundleId);
                              if (b) onPreviewBundle(b);
                            }}
                            className="text-xs font-bold text-indigo-600 hover:text-indigo-700 bg-indigo-50 hover:bg-indigo-100 px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 cursor-pointer ml-2 border border-indigo-200"
                            title="Preview this bundle's dynamic sales landing page"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>Preview Bundle Page</span>
                          </button>
                        )}
                      </div>

                      {/* Sub-tabs for bundle - WordPress Page Builder First */}
                      <div className="flex items-center gap-1 bg-slate-100 p-1.5 rounded-xl border border-slate-200">
                        <button
                          type="button"
                          onClick={() => setBundleEditorSubTab('landing')}
                          className={`px-3.5 py-2 rounded-lg text-xs font-extrabold transition cursor-pointer flex items-center gap-1.5 ${
                            bundleEditorSubTab === 'landing'
                              ? 'bg-indigo-600 text-white shadow-sm'
                              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                          }`}
                        >
                          <BookOpen className="w-3.5 h-3.5" />
                          <span>1. WordPress Bundle Landing Page</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => setBundleEditorSubTab('included')}
                          className={`px-3.5 py-2 rounded-lg text-xs font-bold transition cursor-pointer ${
                            bundleEditorSubTab === 'included'
                              ? 'bg-white text-slate-900 shadow-sm'
                              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                          }`}
                        >
                          2. Included Toolkits
                        </button>
                        <button
                          type="button"
                          onClick={() => setBundleEditorSubTab('general')}
                          className={`px-3.5 py-2 rounded-lg text-xs font-bold transition cursor-pointer ${
                            bundleEditorSubTab === 'general'
                              ? 'bg-white text-slate-900 shadow-sm'
                              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                          }`}
                        >
                          3. Pricing &amp; Savings
                        </button>
                        <button
                          type="button"
                          onClick={() => setBundleEditorSubTab('assets')}
                          className={`px-3.5 py-2 rounded-lg text-xs font-bold transition cursor-pointer flex items-center gap-1.5 ${
                            bundleEditorSubTab === 'assets'
                              ? 'bg-white text-slate-900 shadow-sm'
                              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                          }`}
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>4. Media &amp; PDF</span>
                        </button>
                      </div>
                    </div>

                    <form onSubmit={handleSaveBundle} className="space-y-6">
                      
                      {/* BUNDLE TAB 1: CORE SETUP */}
                      {bundleEditorSubTab === 'general' && (
                        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-5 animate-fadeIn">
                          <h5 className="font-extrabold text-slate-900 text-sm border-b border-slate-100 pb-3">
                            Bundle Identity, Pricing &amp; Savings
                          </h5>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                              <label className="block text-xs font-bold text-slate-700 mb-1">
                                Bundle Title *
                              </label>
                              <input
                                type="text"
                                required
                                value={bundleTitle}
                                onChange={(e) => setBundleTitle(e.target.value)}
                                placeholder="e.g. AI Side Hustle Starter Bundle"
                                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold focus:ring-2 focus:ring-indigo-600 focus:outline-none"
                              />
                            </div>

                            <div>
                              <label className="block text-xs font-bold text-slate-700 mb-1">
                                URL Slug (e.g. ai-side-hustle-starter-bundle)
                              </label>
                              <input
                                type="text"
                                value={bundleSlug}
                                onChange={(e) => setBundleSlug(e.target.value)}
                                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-mono focus:ring-2 focus:ring-indigo-600 focus:outline-none"
                              />
                            </div>
                          </div>

                          <div>
                            <label className="block text-xs font-bold text-slate-700 mb-1">
                              Subtitle / Value Promise
                            </label>
                            <input
                              type="text"
                              value={bundleSubtitle}
                              onChange={(e) => setBundleSubtitle(e.target.value)}
                              placeholder="For beginners who want practical AI income streams without guesswork."
                              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-indigo-600 focus:outline-none"
                            />
                          </div>

                          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
                            <div>
                              <label className="block text-xs font-bold text-slate-700 mb-1">
                                Bundle Price (₹ INR) *
                              </label>
                              <input
                                type="number"
                                required
                                value={bundlePriceINR}
                                onChange={(e) => setBundlePriceINR(Number(e.target.value))}
                                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-black text-indigo-700 focus:ring-2 focus:ring-indigo-600 focus:outline-none"
                              />
                            </div>

                            <div>
                              <label className="block text-xs font-bold text-slate-700 mb-1">
                                Original Price / MRP (₹)
                              </label>
                              <input
                                type="number"
                                value={bundleOriginalPriceINR}
                                onChange={(e) => setBundleOriginalPriceINR(Number(e.target.value))}
                                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm text-slate-400 line-through focus:ring-2 focus:ring-indigo-600 focus:outline-none"
                              />
                            </div>

                            <div>
                              <label className="block text-xs font-bold text-slate-700 mb-1">
                                Savings %
                              </label>
                              <input
                                type="number"
                                value={bundleSavingsPercent}
                                onChange={(e) => setBundleSavingsPercent(Number(e.target.value))}
                                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-emerald-600 focus:ring-2 focus:ring-indigo-600 focus:outline-none"
                              />
                            </div>

                            <div>
                              <label className="block text-xs font-bold text-slate-700 mb-1">
                                Badge Type
                              </label>
                              <select
                                value={bundleBadgeType}
                                onChange={(e) => setBundleBadgeType(e.target.value as any)}
                                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold focus:ring-2 focus:ring-indigo-600 focus:outline-none cursor-pointer"
                              >
                                <option value="popular">Popular</option>
                                <option value="business">Business</option>
                                <option value="creator">Creator</option>
                                <option value="ultimate">Ultimate</option>
                              </select>
                            </div>
                          </div>

                          {/* Custom Razorpay Payment Gateway URL for Bundle */}
                          <div className="p-4 bg-gradient-to-r from-indigo-50 to-purple-50 rounded-2xl border-2 border-indigo-200/80 space-y-2">
                            <div className="flex items-center justify-between">
                              <label className="text-xs font-bold text-indigo-950 flex items-center gap-1.5">
                                <CreditCard className="w-4 h-4 text-indigo-600" />
                                <span>Custom Razorpay Payment URL (Direct Bundle Payment Link)</span>
                              </label>
                              {bundlePaymentLink && (
                                <a
                                  href={bundlePaymentLink}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 underline flex items-center gap-1"
                                >
                                  <span>Test Link</span>
                                  <ExternalLink className="w-3 h-3" />
                                </a>
                              )}
                            </div>
                            <input
                              type="url"
                              value={bundlePaymentLink}
                              onChange={(e) => setBundlePaymentLink(e.target.value)}
                              placeholder="e.g. https://rzp.io/l/your-bundle-link or https://pages.razorpay.com/..."
                              className="w-full px-3.5 py-2.5 bg-white border border-indigo-300 rounded-xl text-xs sm:text-sm font-mono text-slate-900 focus:ring-2 focus:ring-indigo-600 focus:outline-none"
                            />
                            <p className="text-[11px] text-slate-600 leading-relaxed">
                              Paste your Razorpay Payment Page or Payment Link for this high-value bundle. When customers click <strong>&quot;Get Instant Access&quot;</strong>, they will be routed to this link to complete their purchase directly to your account. (Leave empty to use store default link).
                            </p>
                          </div>

                          <div>
                            <label className="block text-xs font-bold text-slate-700 mb-1">
                              Badge Label Text
                            </label>
                            <input
                              type="text"
                              value={bundleBadge}
                              onChange={(e) => setBundleBadge(e.target.value)}
                              placeholder="POPULAR BUNDLE or MAXIMUM VALUE"
                              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-bold text-indigo-700 focus:ring-2 focus:ring-indigo-600 focus:outline-none"
                            />
                          </div>
                        </div>
                      )}

                      {/* BUNDLE TAB 2: INCLUDED TOOLKITS & DELIVERABLES */}
                      {bundleEditorSubTab === 'included' && (
                        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-5 animate-fadeIn">
                          <h5 className="font-extrabold text-slate-900 text-sm border-b border-slate-100 pb-3">
                            Included Product Packages &amp; Features
                          </h5>

                          <div>
                            <label className="block text-xs font-bold text-slate-700 mb-1">
                              Included Standalone Products (1 product per line)
                            </label>
                            <p className="text-[11px] text-slate-400 mb-1">
                              These will be shown as cards on the bundle landing page and preview popup.
                            </p>
                            <textarea
                              rows={5}
                              value={bundleIncludedProductsText}
                              onChange={(e) => setBundleIncludedProductsText(e.target.value)}
                              placeholder="AI Freelancing Starter Kit (Worth ₹999)&#10;AI Digital Products Playbook (Worth ₹1,299)&#10;ChatGPT Prompt Mega Pack (Worth ₹899)"
                              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm leading-relaxed focus:ring-2 focus:ring-indigo-600 focus:outline-none"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-bold text-slate-700 mb-1">
                              Key Features (Bullet points on bundle card, 1 per line)
                            </label>
                            <textarea
                              rows={4}
                              value={bundleFeaturesText}
                              onChange={(e) => setBundleFeaturesText(e.target.value)}
                              placeholder="6 Complete Digital Toolkits & Playbooks&#10;50 Proven AI Income Streams&#10;Lifetime Access & All Future Quarterly Updates"
                              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm leading-relaxed focus:ring-2 focus:ring-indigo-600 focus:outline-none"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-bold text-slate-700 mb-1">
                              Deliverables List (1 per line)
                            </label>
                            <textarea
                              rows={3}
                              value={bundleDeliverablesText}
                              onChange={(e) => setBundleDeliverablesText(e.target.value)}
                              placeholder="Master Bundle Blueprint PDF&#10;Notion Command Center Workspace&#10;500+ Copy-Paste Prompts"
                              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm leading-relaxed focus:ring-2 focus:ring-indigo-600 focus:outline-none"
                            />
                          </div>
                        </div>
                      )}

                      {/* BUNDLE TAB 3: LANDING PAGE CONTENT */}
                      {bundleEditorSubTab === 'landing' && (
                        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6 animate-fadeIn">
                          <div className="border-b border-slate-100 pb-3">
                            <h5 className="font-extrabold text-slate-900 text-base">
                              High-Ticket Bundle Landing Page Sections
                            </h5>
                            <p className="text-xs text-slate-500">
                              Craft deep sales copy, master modules, and high-value bonus stack.
                            </p>
                          </div>

                          <div>
                            <label className="block text-xs font-bold text-slate-700 mb-1">
                              Full Longform Pitch / Description
                            </label>
                            <textarea
                              rows={6}
                              value={bundleFullDescription}
                              onChange={(e) => setBundleFullDescription(e.target.value)}
                              placeholder="The ultimate ecosystem for launching income-generating AI micro-businesses..."
                              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm leading-relaxed focus:ring-2 focus:ring-indigo-600 focus:outline-none"
                            />
                          </div>

                          <div>
                            <label className="block text-xs font-bold text-slate-700 mb-1">
                              Target Audience ("Who Is This For?", 1 per line)
                            </label>
                            <textarea
                              rows={3}
                              value={bundleTargetAudienceText}
                              onChange={(e) => setBundleTargetAudienceText(e.target.value)}
                              placeholder="College students wanting independent income&#10;Professionals wanting weekend side cash&#10;Agency owners wanting automated delivery"
                              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm leading-relaxed focus:ring-2 focus:ring-indigo-600 focus:outline-none"
                            />
                          </div>

                          {/* Dynamic Master Tracks / Modules */}
                          <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/70 space-y-3">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                                <BookOpen className="w-3.5 h-3.5 text-indigo-600" />
                                <span>Master Tracks &amp; Execution Roadmap ({bundleCurriculum.length})</span>
                              </span>
                              <button
                                type="button"
                                onClick={() =>
                                  setBundleCurriculum([
                                    ...bundleCurriculum,
                                    { title: `Module ${bundleCurriculum.length + 1}: Execution Phase`, duration: '2 Hours', description: 'Detailed module description.' }
                                  ])
                                }
                                className="text-xs font-bold text-indigo-600 hover:text-indigo-700 bg-white border border-slate-200 px-2.5 py-1 rounded-lg transition cursor-pointer"
                              >
                                + Add Module
                              </button>
                            </div>

                            <div className="space-y-2.5">
                              {bundleCurriculum.map((mod, idx) => (
                                <div key={idx} className="bg-white p-3 rounded-xl border border-slate-200 flex flex-col gap-2">
                                  <div className="flex items-center gap-2">
                                    <input
                                      type="text"
                                      value={mod.title}
                                      onChange={(e) => {
                                        const next = [...bundleCurriculum];
                                        next[idx].title = e.target.value;
                                        setBundleCurriculum(next);
                                      }}
                                      placeholder="Module Title"
                                      className="flex-1 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold"
                                    />
                                    <input
                                      type="text"
                                      value={mod.duration || ''}
                                      onChange={(e) => {
                                        const next = [...bundleCurriculum];
                                        next[idx].duration = e.target.value;
                                        setBundleCurriculum(next);
                                      }}
                                      placeholder="Duration"
                                      className="w-32 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                                    />
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const next = bundleCurriculum.filter((_, i) => i !== idx);
                                        setBundleCurriculum(next);
                                      }}
                                      className="text-rose-500 hover:text-rose-700 p-1 cursor-pointer"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                  <input
                                    type="text"
                                    value={mod.description || ''}
                                    onChange={(e) => {
                                      const next = [...bundleCurriculum];
                                      next[idx].description = e.target.value;
                                      setBundleCurriculum(next);
                                    }}
                                    placeholder="Module explanation..."
                                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-600"
                                  />
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Dynamic Bonuses Stack */}
                          <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/70 space-y-3">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                                <Gift className="w-3.5 h-3.5 text-amber-600" />
                                <span>High-Value Bundle Bonuses ({bundleBonuses.length})</span>
                              </span>
                              <button
                                type="button"
                                onClick={() =>
                                  setBundleBonuses([
                                    ...bundleBonuses,
                                    { title: 'Exclusive Founder VIP Bonus', valueINR: 2499, description: 'Direct consulting or template access.' }
                                  ])
                                }
                                className="text-xs font-bold text-amber-700 hover:text-amber-800 bg-white border border-slate-200 px-2.5 py-1 rounded-lg transition cursor-pointer"
                              >
                                + Add Bonus
                              </button>
                            </div>

                            <div className="space-y-2.5">
                              {bundleBonuses.map((bonus, idx) => (
                                <div key={idx} className="bg-white p-3 rounded-xl border border-slate-200 flex flex-col gap-2">
                                  <div className="flex items-center gap-2">
                                    <input
                                      type="text"
                                      value={bonus.title}
                                      onChange={(e) => {
                                        const next = [...bundleBonuses];
                                        next[idx].title = e.target.value;
                                        setBundleBonuses(next);
                                      }}
                                      placeholder="Bonus Title"
                                      className="flex-1 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold"
                                    />
                                    <div className="flex items-center gap-1 text-xs">
                                      <span>Value ₹</span>
                                      <input
                                        type="number"
                                        value={bonus.valueINR}
                                        onChange={(e) => {
                                          const next = [...bundleBonuses];
                                          next[idx].valueINR = Number(e.target.value);
                                          setBundleBonuses(next);
                                        }}
                                        className="w-24 px-2 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold"
                                      />
                                    </div>
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const next = bundleBonuses.filter((_, i) => i !== idx);
                                        setBundleBonuses(next);
                                      }}
                                      className="text-rose-500 hover:text-rose-700 p-1 cursor-pointer"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                  <input
                                    type="text"
                                    value={bonus.description}
                                    onChange={(e) => {
                                      const next = [...bundleBonuses];
                                      next[idx].description = e.target.value;
                                      setBundleBonuses(next);
                                    }}
                                    placeholder="Bonus description..."
                                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-600"
                                  />
                                </div>
                              ))}
                            </div>
                          </div>

                          {/* Bundle FAQs */}
                          <div className="border border-slate-200 rounded-2xl p-4 bg-slate-50/70 space-y-3">
                            <div className="flex items-center justify-between">
                              <span className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                                <HelpCircle className="w-3.5 h-3.5 text-indigo-600" />
                                <span>Bundle FAQs ({bundleFaqs.length})</span>
                              </span>
                              <button
                                type="button"
                                onClick={() =>
                                  setBundleFaqs([
                                    ...bundleFaqs,
                                    { question: 'Common question regarding the bundle?', answer: 'Comprehensive answer providing clarity.' }
                                  ])
                                }
                                className="text-xs font-bold text-indigo-600 hover:text-indigo-700 bg-white border border-slate-200 px-2.5 py-1 rounded-lg transition cursor-pointer"
                              >
                                + Add FAQ
                              </button>
                            </div>

                            <div className="space-y-2.5">
                              {bundleFaqs.map((faq, idx) => (
                                <div key={idx} className="bg-white p-3 rounded-xl border border-slate-200 flex flex-col gap-2">
                                  <div className="flex items-center gap-2">
                                    <input
                                      type="text"
                                      value={faq.question}
                                      onChange={(e) => {
                                        const next = [...bundleFaqs];
                                        next[idx].question = e.target.value;
                                        setBundleFaqs(next);
                                      }}
                                      placeholder="Question"
                                      className="flex-1 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-bold"
                                    />
                                    <button
                                      type="button"
                                      onClick={() => {
                                        const next = bundleFaqs.filter((_, i) => i !== idx);
                                        setBundleFaqs(next);
                                      }}
                                      className="text-rose-500 hover:text-rose-700 p-1 cursor-pointer"
                                    >
                                      <Trash2 className="w-3.5 h-3.5" />
                                    </button>
                                  </div>
                                  <textarea
                                    rows={2}
                                    value={faq.answer}
                                    onChange={(e) => {
                                      const next = [...bundleFaqs];
                                      next[idx].answer = e.target.value;
                                      setBundleFaqs(next);
                                    }}
                                    placeholder="Answer..."
                                    className="w-full px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-600"
                                  />
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      )}

                      {/* BUNDLE TAB 4: MEDIA & MASTER DELIVERY */}
                      {bundleEditorSubTab === 'assets' && (
                        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-5 animate-fadeIn">
                          <h5 className="font-extrabold text-slate-900 text-sm border-b border-slate-100 pb-3">
                            Master Bundle Assets &amp; Delivery
                          </h5>

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                              <label className="block text-xs font-bold text-slate-700 mb-1">
                                Master Bundle Download URL (Cloud / Drive)
                              </label>
                              <input
                                type="url"
                                value={bundlePdfUrl}
                                onChange={(e) => setBundlePdfUrl(e.target.value)}
                                placeholder="https://..."
                                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-mono focus:ring-2 focus:ring-indigo-600 focus:outline-none"
                              />
                            </div>

                            <div>
                              <label className="block text-xs font-bold text-slate-700 mb-1">
                                Master File Name
                              </label>
                              <input
                                type="text"
                                value={bundlePdfFileName}
                                onChange={(e) => setBundlePdfFileName(e.target.value)}
                                placeholder="ApexAI_Master_Vault.pdf"
                                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-mono focus:ring-2 focus:ring-indigo-600 focus:outline-none"
                              />
                            </div>
                          </div>

                          <div>
                            <label className="block text-xs font-bold text-slate-700 mb-1">
                              Hero Banner Image URL
                            </label>
                            <input
                              type="url"
                              value={bundleImageUrl}
                              onChange={(e) => setBundleImageUrl(e.target.value)}
                              placeholder="https://images.unsplash.com/..."
                              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-mono focus:ring-2 focus:ring-indigo-600 focus:outline-none mb-2"
                            />
                            <div className="flex flex-wrap gap-1.5">
                              {PRODUCT_IMAGE_PRESETS.map((p, i) => (
                                <button
                                  type="button"
                                  key={i}
                                  onClick={() => setBundleImageUrl(p.url)}
                                  className="text-[11px] font-semibold bg-slate-100 hover:bg-slate-200 text-slate-700 px-2.5 py-1 rounded-lg transition cursor-pointer"
                                >
                                  {p.name}
                                </button>
                              ))}
                            </div>
                          </div>
                        </div>
                      )}

                      {/* BOTTOM SUBMIT BAR FOR BUNDLE */}
                      <div className="flex items-center justify-between pt-2">
                        <button
                          type="button"
                          onClick={() => setBundleViewMode('list')}
                          className="bg-slate-200 hover:bg-slate-300 text-slate-700 px-5 py-2.5 rounded-xl font-bold text-xs transition cursor-pointer"
                        >
                          Cancel
                        </button>

                        <button
                          type="submit"
                          disabled={isSubmitting}
                          className="bg-indigo-600 hover:bg-indigo-700 text-white font-extrabold px-8 py-3 rounded-xl transition text-xs sm:text-sm shadow-md shadow-indigo-500/20 cursor-pointer disabled:opacity-50 flex items-center gap-2"
                        >
                          {isSubmitting ? (
                            <span>Saving Bundle...</span>
                          ) : (
                            <>
                              <Check className="w-4 h-4" />
                              <span>{editingBundleId ? 'Update High-Value Bundle' : 'Publish Bundle Landing Page'}</span>
                            </>
                          )}
                        </button>
                      </div>
                    </form>
                  </div>
                )}
              </div>
            )}

            {/* ========================================================================= */}
            {/* SECTION 3: RAZORPAY PAYMENT GATEWAY SETTINGS */}
            {/* ========================================================================= */}
            {activeSection === 'payments' && (
              <div className="flex-1 flex flex-col min-h-0 overflow-y-auto p-4 sm:p-8 bg-slate-50">
                <div className="max-w-4xl mx-auto w-full space-y-6">
                  
                  {/* Top Intro Card */}
                  <div className="bg-gradient-to-r from-emerald-900 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-emerald-800/40 relative overflow-hidden">
                    <div className="relative z-10 space-y-3">
                      <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/30 text-emerald-300 text-xs font-bold uppercase tracking-wider">
                        <CreditCard className="w-3.5 h-3.5" />
                        <span>Razorpay Live Payment Gateway</span>
                      </div>
                      <h3 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
                        Configure Your Razorpay Payment Gateway
                      </h3>
                      <p className="text-slate-300 text-xs sm:text-sm max-w-2xl leading-relaxed">
                        Apni Razorpay payment link yaha enter karein. Customer jab bhi &quot;Get Access&quot; ya checkout button par click karega, payment seedha aapke Razorpay account me receive hoga!
                      </p>
                    </div>
                  </div>

                  {/* Settings Form */}
                  <form onSubmit={handleSavePaymentSettings} className="space-y-6">
                    
                    {/* Primary Gateway URL */}
                    <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-5">
                      <div className="border-b border-slate-100 pb-4">
                        <h4 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                          <CreditCard className="w-5 h-5 text-emerald-600" />
                          <span>Global Default Razorpay Payment URL</span>
                        </h4>
                        <p className="text-xs text-slate-500 mt-1">
                          This link will be used when an individual product or bundle doesn&apos;t have its own custom Razorpay link.
                        </p>
                      </div>

                      <div className="space-y-2">
                        <div className="flex items-center justify-between">
                          <label className="text-xs font-bold text-slate-700">
                            Razorpay Payment Link / Payment Page URL *
                          </label>
                          {payDefaultUrl && (
                            <a
                              href={payDefaultUrl}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-xs font-bold text-emerald-600 hover:text-emerald-700 flex items-center gap-1 underline"
                            >
                              <span>Test Link In New Tab</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          )}
                        </div>
                        <input
                          type="url"
                          value={payDefaultUrl}
                          onChange={(e) => setPayDefaultUrl(e.target.value)}
                          placeholder="https://rzp.io/l/your-razorpay-link or https://pages.razorpay.com/..."
                          className="w-full px-4 py-3 bg-slate-50 border-2 border-emerald-300/60 rounded-2xl text-xs sm:text-sm font-mono text-slate-900 focus:bg-white focus:border-emerald-600 focus:outline-none transition"
                        />
                        <p className="text-[11px] text-slate-500">
                          Format: <code>https://rzp.io/l/...</code> ya <code>https://pages.razorpay.com/...</code>
                        </p>
                      </div>

                      {/* Checkout Mode Toggle */}
                      <div className="pt-4 border-t border-slate-100 space-y-3">
                        <label className="text-xs font-bold text-slate-700 block">
                          Checkout Behavior When User Clicks &quot;Get Access&quot;:
                        </label>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          <button
                            type="button"
                            onClick={() => setPayDirectRedirect(false)}
                            className={`p-4 rounded-2xl border-2 text-left transition cursor-pointer ${
                              !payDirectRedirect
                                ? 'border-emerald-600 bg-emerald-50/50 shadow-sm'
                                : 'border-slate-200 hover:border-slate-300 bg-white'
                            }`}
                          >
                            <div className="flex items-center justify-between mb-1.5">
                              <span className="font-bold text-xs sm:text-sm text-slate-900">
                                Guided Checkout Modal
                              </span>
                              {!payDirectRedirect && (
                                <span className="w-2.5 h-2.5 rounded-full bg-emerald-600" />
                              )}
                            </div>
                            <p className="text-[11px] text-slate-500 leading-relaxed">
                              Opens order popup to collect customer name/email, with direct 1-click &quot;Pay via Razorpay&quot; button and instant digital access.
                            </p>
                          </button>

                          <button
                            type="button"
                            onClick={() => setPayDirectRedirect(true)}
                            className={`p-4 rounded-2xl border-2 text-left transition cursor-pointer ${
                              payDirectRedirect
                                ? 'border-emerald-600 bg-emerald-50/50 shadow-sm'
                                : 'border-slate-200 hover:border-slate-300 bg-white'
                            }`}
                          >
                            <div className="flex items-center justify-between mb-1.5">
                              <span className="font-bold text-xs sm:text-sm text-slate-900">
                                Direct 1-Click Redirect
                              </span>
                              {payDirectRedirect && (
                                <span className="w-2.5 h-2.5 rounded-full bg-emerald-600" />
                              )}
                            </div>
                            <p className="text-[11px] text-slate-500 leading-relaxed">
                              Immediately redirects customer directly to your Razorpay link in a new tab when &quot;Get Access&quot; is clicked.
                            </p>
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Merchant Identity & UPI */}
                    <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-4">
                      <div className="border-b border-slate-100 pb-3">
                        <h4 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                          <Shield className="w-5 h-5 text-indigo-600" />
                          <span>Merchant &amp; Receiving Details</span>
                        </h4>
                        <p className="text-xs text-slate-500 mt-0.5">
                          Display info shown on checkout screens for customer trust and verification.
                        </p>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                        <div>
                          <label className="block text-xs font-bold text-slate-700 mb-1">
                            Merchant Display Name
                          </label>
                          <input
                            type="text"
                            value={payMerchantName}
                            onChange={(e) => setPayMerchantName(e.target.value)}
                            placeholder="ApexAI Technologies"
                            className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-slate-700 mb-1">
                            Merchant UPI ID (Optional)
                          </label>
                          <input
                            type="text"
                            value={payUpiId}
                            onChange={(e) => setPayUpiId(e.target.value)}
                            placeholder="e.g. dipak@upi or store@okhdfcbank"
                            className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-mono focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                          />
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-slate-700 mb-1">
                            Razorpay Key ID (Optional)
                          </label>
                          <input
                            type="text"
                            value={payKeyId}
                            onChange={(e) => setPayKeyId(e.target.value)}
                            placeholder="rzp_live_..."
                            className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-mono focus:ring-2 focus:ring-emerald-600 focus:outline-none"
                          />
                        </div>
                      </div>
                    </div>

                    {/* How to get Razorpay Link Guide */}
                    <div className="bg-emerald-50/70 border border-emerald-200/80 rounded-3xl p-6 sm:p-7 space-y-4">
                      <div className="flex items-center gap-2 text-emerald-900 font-bold text-sm">
                        <BookOpen className="w-4 h-4 text-emerald-700" />
                        <span>How to get your Razorpay Payment Link in 2 Minutes:</span>
                      </div>
                      <ol className="text-xs text-slate-700 space-y-2 list-decimal list-inside leading-relaxed">
                        <li>
                          Open{' '}
                          <a
                            href="https://dashboard.razorpay.com/"
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-emerald-700 font-bold underline inline-flex items-center gap-0.5"
                          >
                            <span>Razorpay Dashboard</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>{' '}
                          and log into your account.
                        </li>
                        <li>
                          Click on <strong>Payment Links</strong> or <strong>Payment Pages</strong> in the left sidebar.
                        </li>
                        <li>
                          Click <strong>&quot;Create Payment Link&quot;</strong>, set your price (e.g. ₹999 or ₹2999) and description.
                        </li>
                        <li>
                          Click <strong>Create</strong> and copy the link (looks like <code>https://rzp.io/l/...</code>).
                        </li>
                        <li>
                          Paste the link above for all products, or edit individual products/bundles in the CMS tabs to set item-specific links!
                        </li>
                      </ol>
                    </div>

                    {/* Automated Customer Email Delivery Configuration */}
                    <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-5">
                      <div className="border-b border-slate-100 pb-3">
                        <div className="flex items-center gap-2 text-blue-600 font-bold text-xs uppercase tracking-wider mb-1">
                          <Mail className="w-3.5 h-3.5" />
                          <span>Automated Delivery Automation</span>
                        </div>
                        <h4 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                          <span>Customer Email Notification &amp; Delivery (Resend / Webhooks)</span>
                        </h4>
                        <p className="text-xs text-slate-500 mt-0.5">
                          Payment hone ke baad customer ko automatically verified order invoice aur unka direct single PDF link email karne ke liye yaha configure karein.
                        </p>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <div className="flex items-center justify-between mb-1">
                            <label className="text-xs font-bold text-slate-700">
                              Resend API Key (Recommended)
                            </label>
                            <a
                              href="https://resend.com"
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-[11px] font-bold text-blue-600 hover:text-blue-700 flex items-center gap-0.5"
                            >
                              <span>Free 3,000 Emails/Mo</span>
                              <ExternalLink className="w-3 h-3" />
                            </a>
                          </div>
                          <input
                            type="password"
                            value={payResendApiKey}
                            onChange={(e) => setPayResendApiKey(e.target.value)}
                            placeholder="re_123456789..."
                            className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-mono text-slate-900 focus:bg-white focus:border-blue-600 focus:outline-none transition"
                          />
                          <p className="text-[11px] text-slate-500 mt-1">
                            Agar aap Resend use karte hain to har order par seedha customer ke inbox me mail chala jayega.
                          </p>
                        </div>

                        <div>
                          <label className="block text-xs font-bold text-slate-700 mb-1">
                            Sender Email Address
                          </label>
                          <input
                            type="text"
                            value={paySenderEmail}
                            onChange={(e) => setPaySenderEmail(e.target.value)}
                            placeholder="onboarding@resend.dev or orders@yourdomain.com"
                            className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-mono text-slate-900 focus:bg-white focus:border-blue-600 focus:outline-none transition"
                          />
                          <p className="text-[11px] text-slate-500 mt-1">
                            Resend test mode me &apos;onboarding@resend.dev&apos; default rehta hai.
                          </p>
                        </div>
                      </div>

                      <div>
                        <label className="block text-xs font-bold text-slate-700 mb-1">
                          Optional Custom Webhook URL (Zapier / Make / Pabbly)
                        </label>
                        <input
                          type="url"
                          value={payWebhookUrl}
                          onChange={(e) => setPayWebhookUrl(e.target.value)}
                          placeholder="https://hook.eu1.make.com/... or https://hooks.zapier.com/..."
                          className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-mono text-slate-900 focus:bg-white focus:border-blue-600 focus:outline-none transition"
                        />
                        <p className="text-[11px] text-slate-500 mt-1">
                          Har verified order par order details aur buyer email is URL par POST webhook ke through send hogi.
                        </p>
                      </div>

                      <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 text-xs text-slate-600 space-y-1">
                        <span className="font-bold text-slate-800 block">Instant Fallback Built-in:</span>
                        <span>
                          Customer ke order screen par 1-click &apos;Open in Gmail&apos; aur &apos;Find by Email in My Downloads&apos; hamesha active rehta hai jisse buyer kabhi bhi apna PDF download kar sake!
                        </span>
                      </div>
                    </div>

                    {/* Quick Inventory Links Overview */}
                    <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-4">
                      <h4 className="text-base font-extrabold text-slate-900 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Package className="w-5 h-5 text-blue-600" />
                          <span>All Products &amp; Bundles Payment Links Status</span>
                        </div>
                        <span className="text-xs font-semibold text-slate-400">
                          {displayProducts.length + displayBundles.length} items total
                        </span>
                      </h4>

                      <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto pr-1">
                        {/* High-Value Bundles */}
                        {displayBundles.map((b) => (
                          <div key={b.id} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-2">
                                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-indigo-100 text-indigo-800 shrink-0">
                                  BUNDLE
                                </span>
                                <span className="font-bold text-slate-900 truncate">{b.title}</span>
                                <span className="text-slate-400 font-mono text-[11px] shrink-0">₹{b.priceINR}</span>
                              </div>
                              <p className="text-[11px] text-slate-500 truncate mt-0.5">
                                {b.paymentLink ? (
                                  <span className="text-emerald-600 font-mono">Custom: {b.paymentLink}</span>
                                ) : (
                                  <span className="text-slate-400 italic">
                                    Uses Default: {payDefaultUrl || 'Not configured'}
                                  </span>
                                )}
                              </p>
                            </div>
                            <button
                              type="button"
                              onClick={() => {
                                handleEditBundle(b);
                                setActiveSection('bundles');
                              }}
                              className="text-indigo-600 hover:text-indigo-800 font-bold px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 transition shrink-0 cursor-pointer text-[11px]"
                            >
                              Edit Link
                            </button>
                          </div>
                        ))}

                        {/* Individual Products */}
                        {displayProducts.map((p) => (
                          <div key={p.id} className="py-2.5 flex items-center justify-between gap-3 text-xs">
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-2">
                                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-100 text-blue-800 shrink-0">
                                  PRODUCT
                                </span>
                                <span className="font-bold text-slate-900 truncate">{p.title}</span>
                                <span className="text-slate-400 font-mono text-[11px] shrink-0">₹{p.priceINR}</span>
                              </div>
                              <p className="text-[11px] text-slate-500 truncate mt-0.5">
                                {p.paymentLink ? (
                                  <span className="text-emerald-600 font-mono">Custom: {p.paymentLink}</span>
                                ) : (
                                  <span className="text-slate-400 italic">
                                    Uses Default: {payDefaultUrl || 'Not configured'}
                                  </span>
                                )}
                              </p>
                            </div>
                            <button
                              type="button"
                              onClick={() => {
                                handleEditProduct(p);
                                setActiveSection('products');
                              }}
                              className="text-blue-600 hover:text-blue-800 font-bold px-2.5 py-1 rounded-lg bg-blue-50 hover:bg-blue-100 transition shrink-0 cursor-pointer text-[11px]"
                            >
                              Edit Link
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Bottom Save Bar */}
                    <div className="sticky bottom-0 bg-white/90 backdrop-blur-md p-4 rounded-2xl border border-slate-200 shadow-lg flex items-center justify-between">
                      <div className="text-xs text-slate-600">
                        Changes are saved instantly to your Firestore database and local storage.
                      </div>
                      <button
                        type="submit"
                        disabled={isSavingPaymentSettings}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold px-8 py-3 rounded-xl transition text-xs sm:text-sm shadow-md shadow-emerald-500/20 cursor-pointer disabled:opacity-50 flex items-center gap-2"
                      >
                        {isSavingPaymentSettings ? (
                          <span>Saving Settings...</span>
                        ) : (
                          <>
                            <Check className="w-4 h-4" />
                            <span>Save Razorpay Settings</span>
                          </>
                        )}
                      </button>
                    </div>

                  </form>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
