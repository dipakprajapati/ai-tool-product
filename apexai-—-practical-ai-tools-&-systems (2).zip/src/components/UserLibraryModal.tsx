import React, { useState } from 'react';
import { useFirebase } from '../firebase/context';
import {
  X,
  PackageCheck,
  Download,
  Bookmark,
  ExternalLink,
  Sparkles,
  LogOut,
  Mail,
  Search,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../firebase/config';
import { FirestoreOrder } from '../firebase/services';

interface UserLibraryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onExploreProducts: () => void;
}

export const UserLibraryModal: React.FC<UserLibraryModalProps> = ({
  isOpen,
  onClose,
  onExploreProducts,
}) => {
  const { user, orders, savedItems, signOutUser, signInWithGoogle } = useFirebase();
  const [activeTab, setActiveTab] = useState<'purchases' | 'saved'>('purchases');

  // Search by email state
  const [lookupEmail, setLookupEmail] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [searchedOrders, setSearchedOrders] = useState<FirestoreOrder[] | null>(null);
  const [searchError, setSearchError] = useState('');

  if (!isOpen) return null;

  // Search purchases across Firestore by email
  const handleSearchByEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    setSearchError('');
    const clean = lookupEmail.trim().toLowerCase();
    if (!clean || !clean.includes('@')) {
      setSearchError('Please enter a valid email address.');
      return;
    }

    setIsSearching(true);
    try {
      const q = query(collection(db, 'orders'), where('customerEmail', '==', clean));
      const snap = await getDocs(q);
      const results: FirestoreOrder[] = [];
      snap.forEach((d) => {
        results.push(d.data() as FirestoreOrder);
      });
      setSearchedOrders(results);
      if (results.length === 0) {
        setSearchError('No completed orders found for this email address.');
      }
    } catch (err) {
      console.error('Email lookup error:', err);
      // Fallback: check local orders
      const localMatches = orders.filter((o) => o.customerEmail?.toLowerCase() === clean);
      setSearchedOrders(localMatches);
      if (localMatches.length === 0) {
        setSearchError('No completed orders found for this email.');
      }
    } finally {
      setIsSearching(false);
    }
  };

  const handleDownloadPurchasedOrder = (order: FirestoreOrder) => {
    if (order.pdfUrl && order.pdfUrl.trim()) {
      window.open(order.pdfUrl, '_blank', 'noopener,noreferrer');
      return;
    }
    // Generate certified digital delivery file for this specific product purchase
    const content = `%PDF-1.4
% ApexAI Digital Asset Delivery
Order ID: ${order.orderId}
Product Deliverable: ${order.productTitle}
Customer: ${order.customerName || 'Verified Buyer'} (${order.customerEmail})
Status: Licensed & Activated
Date: ${order.createdAt}
Total: ₹${order.totalPaid}

Commercial license granted. Custom PDF asset is registered for this order.`;

    const blob = new Blob([content], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${order.productTitle.replace(/\s+/g, '_')}_Official_Guide.pdf`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const displayOrders = searchedOrders !== null ? searchedOrders : orders;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-fadeIn">
      <div className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 relative shadow-2xl my-8 max-h-[90vh] overflow-y-auto border border-slate-100">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-6 right-6 text-slate-400 hover:text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-full w-9 h-9 flex items-center justify-center text-lg font-bold transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* User Info / Login Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-6 border-b border-slate-100">
          <div className="flex items-center gap-3.5">
            {user?.photoURL ? (
              <img
                src={user.photoURL}
                alt={user.displayName || 'User'}
                className="w-11 h-11 rounded-full border-2 border-blue-600 shadow-xs"
                referrerPolicy="no-referrer"
              />
            ) : (
              <div className="w-11 h-11 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold text-base shadow-xs">
                {user?.displayName ? user.displayName.charAt(0).toUpperCase() : 'A'}
              </div>
            )}
            <div className="min-w-0">
              <h3 className="text-lg font-extrabold text-slate-900 truncate">
                {user?.displayName || 'Digital Downloads Portal'}
              </h3>
              <p className="text-xs text-slate-500 truncate">
                {user?.email || 'Instant access to your purchased product PDFs'}
              </p>
            </div>
          </div>

          <div>
            {user ? (
              <button
                onClick={async () => {
                  await signOutUser();
                  onClose();
                }}
                className="text-xs font-semibold text-rose-600 hover:text-rose-700 bg-rose-50 hover:bg-rose-100 px-3 py-1.5 rounded-xl transition flex items-center gap-1 cursor-pointer"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            ) : (
              <button
                onClick={signInWithGoogle}
                className="text-xs font-bold text-slate-700 bg-slate-100 hover:bg-slate-200 px-3 py-1.5 rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow-2xs"
              >
                <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                </svg>
                <span>Sign In with Google</span>
              </button>
            )}
          </div>
        </div>

        {/* Email Recovery & Search Bar */}
        <div className="mb-6 p-4 rounded-2xl bg-blue-50/70 border border-blue-200/80">
          <div className="flex items-center gap-2 mb-2 text-xs font-bold text-blue-900">
            <Mail className="w-3.5 h-3.5 text-blue-600" />
            <span>Find Downloads by Buyer Email Address</span>
          </div>
          <form onSubmit={handleSearchByEmail} className="flex gap-2">
            <div className="relative flex-1">
              <input
                type="email"
                value={lookupEmail}
                onChange={(e) => setLookupEmail(e.target.value)}
                placeholder="Enter email used at checkout (e.g. you@gmail.com)"
                className="w-full bg-white border border-blue-200 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-blue-600 shadow-2xs"
              />
            </div>
            <button
              type="submit"
              disabled={isSearching}
              className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs px-3.5 py-2 rounded-xl transition flex items-center gap-1 cursor-pointer disabled:opacity-75 shrink-0 shadow-xs"
            >
              <Search className="w-3.5 h-3.5" />
              <span>{isSearching ? 'Searching...' : 'Find Files'}</span>
            </button>
            {searchedOrders !== null && (
              <button
                type="button"
                onClick={() => {
                  setSearchedOrders(null);
                  setLookupEmail('');
                  setSearchError('');
                }}
                className="bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs px-2.5 py-2 rounded-xl"
              >
                Reset
              </button>
            )}
          </form>

          {searchError && (
            <p className="text-[11px] text-rose-600 font-medium mt-2 flex items-center gap-1">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>{searchError}</span>
            </p>
          )}

          {searchedOrders !== null && searchedOrders.length > 0 && (
            <p className="text-[11px] text-emerald-700 font-semibold mt-2 flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Found {searchedOrders.length} verified purchase(s) for {lookupEmail}</span>
            </p>
          )}
        </div>

        {/* Tabs */}
        <div className="flex items-center gap-2 mb-5">
          <button
            onClick={() => setActiveTab('purchases')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'purchases'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <PackageCheck className="w-3.5 h-3.5" />
            <span>My Paid Downloads ({displayOrders.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('saved')}
            className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'saved'
                ? 'bg-blue-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            <Bookmark className="w-3.5 h-3.5" />
            <span>Saved Workkits ({savedItems.length})</span>
          </button>
        </div>

        {/* Content */}
        {activeTab === 'purchases' && (
          <div>
            {displayOrders.length > 0 ? (
              <div className="space-y-3">
                {displayOrders.map((order) => (
                  <div
                    key={order.orderId}
                    className="p-4 rounded-2xl border border-slate-200 bg-slate-50/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs"
                  >
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] font-mono font-bold text-emerald-600 bg-emerald-50 border border-emerald-200/60 px-2 py-0.5 rounded">
                          #{order.orderId}
                        </span>
                        <span className="text-[11px] text-slate-400">
                          {new Date(order.createdAt).toLocaleDateString()}
                        </span>
                        <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100/70 px-1.5 py-0.5 rounded">
                          Paid &amp; Verified
                        </span>
                      </div>
                      <h4 className="font-extrabold text-slate-900 text-sm mt-1">
                        {order.productTitle}
                      </h4>
                      <p className="text-xs text-slate-500">
                        Paid: ₹{order.totalPaid.toLocaleString()} • Customer: {order.customerEmail}
                      </p>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => {
                          const dl = order.pdfUrl || 'Inside your ApexAI Downloads';
                          const subject = encodeURIComponent(`[ApexAI Verified Receipt #${order.orderId}] ${order.productTitle}`);
                          const body = encodeURIComponent(
                            `Order ID: #${order.orderId}\nProduct: ${order.productTitle}\nTotal: ₹${order.totalPaid}\nDate: ${order.createdAt}\nStatus: Verified\n\nPDF Download URL:\n${dl}`
                          );
                          window.open(`https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(order.customerEmail)}&su=${subject}&body=${body}`, '_blank');
                        }}
                        className="bg-white border border-slate-300 hover:bg-slate-100 text-slate-700 text-xs font-semibold px-2.5 py-2 rounded-xl transition flex items-center justify-center gap-1 cursor-pointer"
                        title="Send receipt to Gmail"
                      >
                        <Mail className="w-3.5 h-3.5 text-blue-600" />
                        <span>Gmail</span>
                      </button>

                      {/* STRICT: Downloads ONLY the specific product PDF */}
                      <button
                        onClick={() => handleDownloadPurchasedOrder(order)}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-3.5 py-2 rounded-xl transition flex items-center justify-center gap-1.5 shrink-0 cursor-pointer active:scale-95 shadow-xs shadow-emerald-500/20"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Download PDF</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-10 bg-slate-50 rounded-2xl border border-slate-200 p-6">
                <PackageCheck className="w-10 h-10 text-slate-400 mx-auto mb-2" />
                <h4 className="font-bold text-slate-900 text-base">No purchases found</h4>
                <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                  If you bought an AI toolkit previously, enter your email in the search box above to instantly retrieve your verified download link.
                </p>
                <button
                  onClick={() => {
                    onClose();
                    onExploreProducts();
                  }}
                  className="mt-4 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold px-4 py-2 rounded-xl shadow-xs"
                >
                  Explore AI Toolkits
                </button>
              </div>
            )}
          </div>
        )}

        {activeTab === 'saved' && (
          <div>
            {savedItems.length > 0 ? (
              <div className="space-y-3">
                {savedItems.map((item) => (
                  <div
                    key={item.id}
                    className="p-4 rounded-2xl border border-slate-200 bg-slate-50 flex items-center justify-between gap-3"
                  >
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">
                        {item.productTitle}
                      </h4>
                      <p className="text-xs text-slate-400">
                        Saved on {new Date(item.createdAt).toLocaleDateString()}
                      </p>
                    </div>

                    <button
                      onClick={() => {
                        onClose();
                        onExploreProducts();
                      }}
                      className="text-xs font-semibold text-blue-600 hover:text-blue-700 bg-blue-50 px-3.5 py-1.5 rounded-xl transition flex items-center gap-1 cursor-pointer"
                    >
                      <span>View in Shop</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-10 bg-slate-50 rounded-2xl border border-slate-200 p-6">
                <Bookmark className="w-10 h-10 text-slate-400 mx-auto mb-2" />
                <h4 className="font-bold text-slate-900 text-base">No saved workkits</h4>
                <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                  Click the bookmark icon on any product card in the catalog to save it to your personal workspace.
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
