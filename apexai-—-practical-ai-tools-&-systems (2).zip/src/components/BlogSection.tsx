import React from 'react';
import { BlogPost } from '../types';
import { useFirebase } from '../firebase/context';
import { Clock, ArrowRight, BookOpen, Sparkles } from 'lucide-react';

interface BlogSectionProps {
  posts: BlogPost[];
  onReadArticle: (post: BlogPost) => void;
}

export const BlogSection: React.FC<BlogSectionProps> = ({
  posts,
  onReadArticle,
}) => {
  const { loadingBlogs } = useFirebase();

  return (
    <section id="blog" className="py-20 bg-slate-50 border-y border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-blue-600 text-xs font-extrabold uppercase tracking-widest flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                AI RESOURCES &amp; GUIDES
              </span>
              <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full">
                Live Tutorials
              </span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-[#0F172A] mt-1">
              Latest Articles &amp; Playbooks
            </h2>
            <p className="mt-2 text-slate-600 text-sm">
              In-depth strategies, frameworks, and actionable playbooks to scale your productivity and business.
            </p>
          </div>

          <div className="mt-4 md:mt-0 flex items-center gap-3">
            {posts.length > 0 && (
              <a
                href={`#/blog/${posts[0].slug || posts[0].id}`}
                onClick={(e) => {
                  e.preventDefault();
                  onReadArticle(posts[0]);
                }}
                className="text-blue-600 font-bold hover:text-blue-700 hover:underline flex items-center gap-1 text-sm cursor-pointer"
              >
                <span>Read featured playbook</span>
                <ArrowRight className="w-4 h-4" />
              </a>
            )}
          </div>
        </div>

        {loadingBlogs && posts.length === 0 ? (
          <div className="text-center py-16 text-slate-400">
            <div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-3" />
            <p className="text-sm font-semibold">Loading tutorials...</p>
          </div>
        ) : posts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {posts.map((post) => (
              <a
                key={post.id}
                href={`#/blog/${post.slug || post.id}`}
                onClick={(e) => {
                  e.preventDefault();
                  onReadArticle(post);
                }}
                className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-xl hover:border-blue-300 transition-all flex flex-col justify-between cursor-pointer group text-left block"
              >
                <div>
                  {/* Visual Header / Cover Image */}
                  {post.imageUrl ? (
                    <div className="relative aspect-[16/10] overflow-hidden bg-slate-900">
                      <img
                        src={post.imageUrl}
                        alt={post.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                        loading="lazy"
                        onError={(e) => {
                          e.currentTarget.style.display = 'none';
                        }}
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-900/20 to-transparent" />
                      
                      <div className="absolute top-4 left-4 right-4 flex justify-between items-center z-10">
                        <span className="bg-blue-600 text-white text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider shadow-sm">
                          {post.category}
                        </span>
                        <span className="text-white/95 bg-black/50 backdrop-blur-xs px-2.5 py-0.5 rounded-full text-xs flex items-center gap-1 font-medium">
                          <Clock className="w-3.5 h-3.5" />
                          {post.readTime}
                        </span>
                      </div>

                      {post.featured && (
                        <div className="absolute bottom-3 right-4 z-10">
                          <span className="bg-amber-400 text-slate-950 text-[10px] px-2.5 py-0.5 rounded-full font-bold shadow-sm">
                            Featured
                          </span>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="bg-gradient-to-br from-slate-900 to-slate-800 aspect-[16/10] p-6 flex flex-col justify-between text-white relative overflow-hidden">
                      <div className="flex justify-between items-center relative z-10">
                        <span className="bg-blue-600 text-white text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider">
                          {post.category}
                        </span>
                        <span className="text-slate-400 text-xs flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" />
                          {post.readTime}
                        </span>
                      </div>
                      <div className="relative z-10 flex items-center justify-between text-xs font-mono text-blue-300">
                        <div className="flex items-center gap-1.5">
                          <BookOpen className="w-4 h-4 text-blue-400" />
                          <span>Tutorial &amp; Blueprint</span>
                        </div>
                        {post.featured && (
                          <span className="bg-amber-400/20 text-amber-300 text-[10px] px-2 py-0.5 rounded font-sans font-bold">
                            Featured
                          </span>
                        )}
                      </div>
                    </div>
                  )}

                  <div className="p-6">
                    <div className="flex items-center justify-between text-xs mb-1">
                      <span className="text-blue-600 font-bold uppercase tracking-wider">
                        {post.category}
                      </span>
                      <span className="text-slate-400 text-[11px]">{post.date}</span>
                    </div>

                    <h3 className="text-lg font-bold text-slate-900 mt-2 group-hover:text-blue-600 transition leading-snug line-clamp-2">
                      {post.title}
                    </h3>

                    <p className="mt-2 text-sm text-slate-600 line-clamp-3 leading-relaxed">
                      {post.excerpt}
                    </p>

                    {post.tags && (
                      <div className="mt-3 flex items-center gap-1 flex-wrap">
                        {post.tags.split(',').map((t, i) => (
                          <span
                            key={i}
                            className="bg-slate-100 text-slate-600 text-[10px] px-2 py-0.5 rounded"
                          >
                            #{t.trim()}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                <div className="p-6 pt-0 border-t border-slate-100 mt-3 flex items-center justify-between text-xs font-bold text-blue-600 group-hover:translate-x-1 transition-transform">
                  <span>Read Full Article</span>
                  <ArrowRight className="w-4 h-4" />
                </div>
              </a>
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-white rounded-3xl border border-slate-200 p-8">
            <BookOpen className="w-10 h-10 text-slate-400 mx-auto mb-3" />
            <h3 className="font-bold text-slate-900 text-lg">New Guides Coming Soon</h3>
            <p className="text-xs text-slate-500 max-w-md mx-auto mt-1">
              Our team is drafting high-impact AI playbooks and tutorials. Check back soon for fresh updates.
            </p>
          </div>
        )}
      </div>
    </section>
  );
};
