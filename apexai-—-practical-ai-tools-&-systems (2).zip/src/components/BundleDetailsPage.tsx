import React, { useState, useEffect, useMemo } from 'react';
import { Bundle, Product } from '../types';
import { useFirebase } from '../firebase/context';
import {
  ArrowLeft,
  Check,
  CheckCircle2,
  Download,
  Star,
  ShieldCheck,
  Sparkles,
  Clock,
  Layers,
  FileText,
  Share2,
  Bookmark,
  ChevronDown,
  ChevronUp,
  Lock,
  Zap,
  ArrowRight,
  Target,
  Gift,
  Award,
  BookOpen,
  Users
} from 'lucide-react';

interface BundleDetailsPageProps {
  bundle: Bundle;
  allBundles?: Bundle[];
  onBack: () => void;
  onOpenCheckout?: (bundle: Bundle) => void;
  onOpenCheckoutForBundle?: (bundle: Bundle) => void;
  onSelectBundle?: (bundle: Bundle) => void;
  onEditInCMS?: (bundleId: string) => void;
  currency: 'INR' | 'USD';
}

export const BundleDetailsPage: React.FC<BundleDetailsPageProps> = ({
  bundle,
  allBundles = [],
  onBack,
  onOpenCheckout,
  onOpenCheckoutForBundle,
  onSelectBundle,
  onEditInCMS,
  currency,
}) => {
  const { purchasedProductIds, isAdmin } = useFirebase();
  const isOwnerVerified = isAdmin || (typeof window !== 'undefined' && localStorage.getItem('apex_owner_verified') === 'true');
  const [scrollProgress, setScrollProgress] = useState(0);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);
  const [copiedShare, setCopiedShare] = useState(false);

  const isPurchased = purchasedProductIds.includes(bundle.id);

  const handleCheckout = () => {
    if (onOpenCheckout) {
      onOpenCheckout(bundle);
    } else if (onOpenCheckoutForBundle) {
      onOpenCheckoutForBundle(bundle);
    }
  };

  // Scroll tracking
  useEffect(() => {
    const handleScroll = () => {
      const totalScroll = document.documentElement.scrollHeight - window.innerHeight;
      if (totalScroll > 0) {
        const currentProgress = (window.scrollY / totalScroll) * 100;
        setScrollProgress(Math.min(100, Math.max(0, currentProgress)));
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // SEO updates
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    const prevTitle = document.title;
    document.title = `${bundle.title} - Complete High-Value AI Bundle | ApexAI`;
    return () => {
      document.title = prevTitle;
    };
  }, [bundle]);

  const formatPrice = (inrPrice: number) => {
    if (currency === 'USD') {
      const usd = Math.round(inrPrice / 83);
      return `$${usd < 1 ? 1 : usd}`;
    }
    return `₹${inrPrice.toLocaleString('en-IN')}`;
  };

  const handleShare = async () => {
    try {
      if (navigator.clipboard) {
        await navigator.clipboard.writeText(window.location.href);
        setCopiedShare(true);
        setTimeout(() => setCopiedShare(false), 2000);
      }
    } catch {
      // ignore
    }
  };

  const handleDownloadPurchasedBundle = () => {
    if (bundle.pdfUrl && bundle.pdfUrl.trim()) {
      window.open(bundle.pdfUrl, '_blank', 'noopener,noreferrer');
      return;
    }

    const content = `%PDF-1.4
% ApexAI Master High-Value Bundle Delivery
Bundle: ${bundle.title}
Badge: ${bundle.badge}
License: Enterprise Commercial License
Included Packages:
${bundle.includedProducts.map((p, i) => ` ${i + 1}. ${p}`).join('\n')}

All master cloud vaults, notion workspaces, and scenario files are unlocked.
Thank you for joining the ApexAI ecosystem.`;

    const blob = new Blob([content], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${bundle.title.replace(/\s+/g, '_')}_Master_Bundle.pdf`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const bannerImg = bundle.imageUrl && bundle.imageUrl.trim()
    ? bundle.imageUrl
    : 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=1200&q=80';

  const defaultDeliverables = [
    'Complete Multi-Product Digital Vault with Master PDF Guides',
    'Ready-to-Deploy Notion Systems, CRMs & Prompt Chains',
    'Importable Automation Scenarios (Make.com, Zapier, Python)',
    'Commercial Client License for All Included Toolkits',
    'Lifetime Access & All Future Quarterly Content Drops'
  ];

  const deliverablesToDisplay = bundle.deliverables && bundle.deliverables.length > 0
    ? bundle.deliverables
    : defaultDeliverables;

  const totalBonusesValue = (bundle.bonuses || []).reduce((acc, b) => acc + (b.valueINR || 0), 0);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 pb-32">
      {/* Top Reading Progress Bar */}
      <div
        className="fixed top-0 left-0 h-1 bg-gradient-to-r from-blue-500 via-indigo-500 to-emerald-400 z-50 transition-all duration-150"
        style={{ width: `${scrollProgress}%` }}
      />

      {/* Top Navigation */}
      <header className="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-sm font-bold text-slate-300 hover:text-white transition bg-slate-800 hover:bg-slate-700 px-3.5 py-2 rounded-xl cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Bundles</span>
          </button>

          <div className="hidden md:flex items-center gap-2 text-xs text-slate-400 font-medium truncate max-w-md">
            <span>ApexAI</span>
            <span>/</span>
            <span className="text-blue-400 font-bold uppercase tracking-wider">Mega Vault</span>
            <span>/</span>
            <span className="text-slate-200 truncate">{bundle.title}</span>
          </div>

          <div className="flex items-center gap-2">
            {onEditInCMS && isOwnerVerified && (
              <button
                type="button"
                onClick={() => onEditInCMS(bundle.id)}
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold px-3 py-1.5 rounded-xl transition cursor-pointer flex items-center gap-1.5 text-xs shadow-sm"
                title="Edit this high-value bundle in WordPress CMS"
              >
                <span>✏️ Edit CMS</span>
              </button>
            )}
            <button
              onClick={handleShare}
              className="p-2 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition cursor-pointer flex items-center gap-1.5 text-xs font-semibold"
            >
              {copiedShare ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
              <span className="hidden sm:inline">{copiedShare ? 'Link Copied' : 'Share'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Already Purchased Status Banner */}
      {isPurchased && (
        <div className="bg-emerald-600 text-white py-3 px-4 shadow-lg border-b border-emerald-500">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="w-5 h-5 text-emerald-200 shrink-0" />
              <span className="text-sm font-bold">
                You own this High-Value Bundle! All toolkits, templates, and master PDFs are unlocked.
              </span>
            </div>
            <button
              onClick={handleDownloadPurchasedBundle}
              className="bg-white text-emerald-900 hover:bg-emerald-50 px-4 py-1.5 rounded-xl text-xs font-extrabold shadow transition flex items-center gap-1.5 cursor-pointer shrink-0"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Master Vault</span>
            </button>
          </div>
        </div>
      )}

      {/* HERO SECTION */}
      <section className="relative pt-12 pb-16 overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-blue-600/15 blur-[120px] rounded-full" />
          <div className="absolute bottom-10 right-10 w-[400px] h-[300px] bg-indigo-600/10 blur-[100px] rounded-full" />
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto mb-10">
            <div className="inline-flex items-center gap-2 bg-blue-500/10 border border-blue-500/30 text-blue-400 text-xs font-black uppercase tracking-widest px-4 py-1.5 rounded-full mb-4 shadow-sm">
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              <span>{bundle.badge || 'ULTIMATE VALUE BUNDLE'}</span>
            </div>
            <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-tight">
              {bundle.title}
            </h1>
            <p className="mt-4 text-slate-400 text-base sm:text-lg leading-relaxed max-w-2xl mx-auto">
              {bundle.subtitle}
            </p>
          </div>

          {/* Hero Banner Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center bg-slate-900/80 border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-2xl backdrop-blur-xl">
            {/* Left: Image & Badge */}
            <div className="lg:col-span-7 relative group overflow-hidden rounded-2xl border border-slate-800">
              <img
                src={bannerImg}
                alt={bundle.title}
                className="w-full h-80 sm:h-96 object-cover object-center group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
              <div className="absolute top-4 left-4 bg-emerald-500 text-white font-black text-xs px-3.5 py-1.5 rounded-full shadow-lg">
                SAVE {bundle.savingsPercent}% TODAY
              </div>
              <div className="absolute bottom-4 left-4 right-4">
                <span className="text-[11px] font-mono text-blue-400 font-bold uppercase tracking-wider block">
                  Complete Multi-Toolkit Vault
                </span>
                <p className="text-sm font-semibold text-slate-200 mt-0.5">
                  Includes {bundle.includedProducts.length} full standalone product ecosystems
                </p>
              </div>
            </div>

            {/* Right: Pricing Box & Fast Action */}
            <div className="lg:col-span-5 flex flex-col justify-between space-y-6">
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <span className="text-sm text-slate-500 line-through font-medium">
                    Total Retail Value: {formatPrice(bundle.originalPriceINR)}
                  </span>
                  <span className="text-xs font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-800/60 px-2 py-0.5 rounded">
                    Save {bundle.savingsPercent}%
                  </span>
                </div>

                <div className="flex items-baseline gap-3">
                  <span className="text-4xl sm:text-5xl font-black text-white">
                    {formatPrice(bundle.priceINR)}
                  </span>
                  <span className="text-xs text-slate-400 font-bold uppercase tracking-wider">
                    One-time / Lifetime
                  </span>
                </div>

                <p className="text-xs text-slate-400 leading-relaxed">
                  Instant unlimited digital delivery. No monthly recurring subscriptions. All future 2026-2027 updates included.
                </p>
              </div>

              {/* Fast Feature Bullets */}
              <div className="space-y-2.5 pt-4 border-t border-slate-800">
                {bundle.features.slice(0, 4).map((feat, idx) => (
                  <div key={idx} className="flex items-start gap-2.5 text-xs text-slate-300">
                    <CheckCircle2 className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>

              {/* Action Buttons */}
              <div className="pt-2 space-y-2.5">
                {isPurchased ? (
                  <button
                    onClick={handleDownloadPurchasedBundle}
                    className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-4 rounded-2xl transition flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/30 text-sm cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Master Vault Assets</span>
                  </button>
                ) : (
                  <button
                    onClick={handleCheckout}
                    className="w-full bg-blue-600 hover:bg-blue-500 text-white font-bold py-4 rounded-2xl transition flex items-center justify-center gap-2 shadow-lg shadow-blue-600/30 text-sm cursor-pointer active:scale-98"
                  >
                    <Lock className="w-4 h-4" />
                    <span>Claim Complete Bundle ({formatPrice(bundle.priceINR)})</span>
                  </button>
                )}

                <div className="flex items-center justify-center gap-3 text-[11px] text-slate-500 text-center">
                  <span>🔒 256-Bit SSL Checkout</span>
                  <span>•</span>
                  <span>⚡ Instant Download</span>
                  <span>•</span>
                  <span>14-Day Guarantee</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* DEEP SALES LETTER & VALUE CONTENT */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        
        {/* Full Longform Story / Pitch */}
        {bundle.fullDescription && (
          <section className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-lg">
            <h2 className="text-xl sm:text-2xl font-black text-white mb-4 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-blue-400" />
              <span>The Complete System Overview</span>
            </h2>
            <div className="text-slate-300 text-sm sm:text-base leading-relaxed space-y-4 whitespace-pre-line">
              {bundle.fullDescription}
            </div>
          </section>
        )}

        {/* WHAT'S INSIDE THE BUNDLE VAULT (Included standalone products) */}
        <section className="space-y-6">
          <div className="text-center max-w-2xl mx-auto">
            <span className="text-blue-400 text-xs font-black uppercase tracking-widest">
              UNPRECEDENTED ARSENAL
            </span>
            <h2 className="text-2xl sm:text-4xl font-black text-white mt-1">
              Included Toolkits &amp; Deliverables
            </h2>
            <p className="mt-2 text-slate-400 text-sm">
              Each product in this bundle was built as an independent, fully-featured commercial toolkit.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {bundle.includedProducts.map((item, idx) => (
              <div
                key={idx}
                className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 relative flex flex-col justify-between hover:border-blue-500/50 transition shadow-sm"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="w-7 h-7 rounded-lg bg-blue-500/20 text-blue-400 font-bold text-xs flex items-center justify-center">
                      0{idx + 1}
                    </span>
                    <span className="text-[10px] font-bold text-emerald-400 bg-emerald-950/60 border border-emerald-800/40 px-2 py-0.5 rounded">
                      Included In Full
                    </span>
                  </div>
                  <h3 className="font-bold text-white text-base leading-snug">
                    {item}
                  </h3>
                  <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                    Full master guides, Notion architectures, copy-paste prompts, and commercial client rights.
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] text-blue-400 font-semibold flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" />
                  <span>Licensed for Commercial Use</span>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* CURRICULUM / MODULES BREAKDOWN */}
        {bundle.curriculum && bundle.curriculum.length > 0 && (
          <section className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-lg space-y-6">
            <div className="max-w-2xl">
              <span className="text-blue-400 text-xs font-black uppercase tracking-widest">
                STEP-BY-STEP ROADMAP
              </span>
              <h2 className="text-2xl sm:text-3xl font-black text-white mt-1">
                System Master Modules &amp; Execution Plan
              </h2>
              <p className="text-xs sm:text-sm text-slate-400 mt-1">
                Follow this sequential path to set up, deploy, and scale your AI operations.
              </p>
            </div>

            <div className="space-y-4">
              {bundle.curriculum.map((mod, idx) => (
                <div
                  key={idx}
                  className="bg-slate-950 border border-slate-800/80 rounded-2xl p-5 hover:border-slate-700 transition"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="font-bold text-white text-base flex items-center gap-2.5">
                      <span className="w-6 h-6 rounded-md bg-blue-600 text-white text-xs flex items-center justify-center shrink-0">
                        {idx + 1}
                      </span>
                      <span>{mod.title}</span>
                    </div>
                    {mod.duration && (
                      <span className="text-xs text-slate-400 bg-slate-900 px-3 py-1 rounded-lg border border-slate-800 shrink-0 font-medium">
                        ⏱ {mod.duration}
                      </span>
                    )}
                  </div>
                  {mod.description && (
                    <p className="mt-2 text-xs sm:text-sm text-slate-400 leading-relaxed pl-8">
                      {mod.description}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}

        {/* BONUS VAULT STACK */}
        {bundle.bonuses && bundle.bonuses.length > 0 && (
          <section className="bg-gradient-to-br from-blue-950/40 via-slate-900 to-slate-950 border-2 border-blue-500/30 rounded-3xl p-6 sm:p-10 shadow-xl space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-amber-400 text-xs font-black uppercase tracking-widest flex items-center gap-1.5">
                  <Gift className="w-4 h-4" />
                  <span>SPECIAL BUNDLE BONUSES</span>
                </span>
                <h2 className="text-2xl sm:text-3xl font-black text-white mt-1">
                  Exclusive High-Ticket Bonus Stack
                </h2>
                <p className="text-xs sm:text-sm text-slate-400 mt-1">
                  Included FREE when you order this bundle today (Total Bonus Value: ₹{totalBonusesValue.toLocaleString()})
                </p>
              </div>
              <div className="bg-amber-500/20 border border-amber-500/40 px-4 py-2 rounded-2xl text-center shrink-0">
                <span className="text-[10px] uppercase font-bold text-amber-300 block">Total Bonus Value</span>
                <span className="text-lg font-black text-amber-400">₹{totalBonusesValue.toLocaleString()} FREE</span>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
              {bundle.bonuses.map((bonus, idx) => (
                <div
                  key={idx}
                  className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs font-bold text-blue-400">Bonus #{idx + 1}</span>
                      <span className="text-xs font-bold text-amber-400">Worth ₹{bonus.valueINR.toLocaleString()}</span>
                    </div>
                    <h3 className="font-bold text-white text-sm">
                      {bonus.title}
                    </h3>
                    <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                      {bonus.description}
                    </p>
                  </div>
                  <div className="mt-4 pt-3 border-t border-slate-800 text-[11px] font-bold text-emerald-400 flex items-center gap-1">
                    <Check className="w-3.5 h-3.5" />
                    <span>Unlocked for Lifetime</span>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* TARGET AUDIENCE ("Who Is This For?") */}
        {bundle.targetAudience && bundle.targetAudience.length > 0 && (
          <section className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-lg space-y-6">
            <div className="flex items-center gap-2 text-xs font-black text-blue-400 uppercase tracking-widest">
              <Users className="w-4 h-4" />
              <span>PERFECT FIT</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white">
              Who Is This High-Value Pack Designed For?
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {bundle.targetAudience.map((aud, idx) => (
                <div
                  key={idx}
                  className="bg-slate-950 p-4 rounded-2xl border border-slate-800 flex items-start gap-3"
                >
                  <div className="w-6 h-6 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0 mt-0.5">
                    <Check className="w-3.5 h-3.5 stroke-[3]" />
                  </div>
                  <span className="text-sm text-slate-300 leading-relaxed font-medium">{aud}</span>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* FREQUENTLY ASKED QUESTIONS */}
        {bundle.faqs && bundle.faqs.length > 0 && (
          <section className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-lg space-y-6">
            <h2 className="text-2xl font-black text-white">
              Frequently Asked Questions About This Bundle
            </h2>
            <div className="space-y-3">
              {bundle.faqs.map((faq, idx) => (
                <div
                  key={idx}
                  className="border border-slate-800 rounded-2xl overflow-hidden"
                >
                  <button
                    onClick={() => setActiveFaq(activeFaq === idx ? null : idx)}
                    className="w-full text-left p-4.5 bg-slate-950 hover:bg-slate-800/80 transition flex items-center justify-between text-sm font-bold text-white cursor-pointer"
                  >
                    <span>{faq.question}</span>
                    {activeFaq === idx ? (
                      <ChevronUp className="w-4 h-4 text-blue-400 shrink-0" />
                    ) : (
                      <ChevronDown className="w-4 h-4 text-slate-500 shrink-0" />
                    )}
                  </button>
                  {activeFaq === idx && (
                    <div className="p-4.5 bg-slate-900 border-t border-slate-800 text-xs sm:text-sm text-slate-300 leading-relaxed">
                      {faq.answer}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}

        {/* BOTTOM GUARANTEE & STICKY CTA */}
        <section className="bg-gradient-to-r from-blue-900/60 to-indigo-900/60 border border-blue-500/30 rounded-3xl p-8 sm:p-12 text-center relative overflow-hidden shadow-2xl">
          <ShieldCheck className="w-12 h-12 text-blue-400 mx-auto mb-3" />
          <h2 className="text-2xl sm:text-3xl font-black text-white">
            100% Risk-Free 14-Day Money-Back Guarantee
          </h2>
          <p className="mt-3 text-slate-300 text-sm max-w-xl mx-auto leading-relaxed">
            Test and implement every blueprint, prompt library, and automation workflow. If you aren’t blown away by the clarity and execution value, let us know for a complete 100% prompt refund.
          </p>

          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            {isPurchased ? (
              <button
                onClick={handleDownloadPurchasedBundle}
                className="bg-emerald-500 hover:bg-emerald-400 text-white font-extrabold px-8 py-4 rounded-2xl transition shadow-xl shadow-emerald-500/20 text-base cursor-pointer"
              >
                Download Your Bundle
              </button>
            ) : (
              <button
                onClick={handleCheckout}
                className="bg-white hover:bg-slate-100 text-slate-900 font-extrabold px-8 py-4 rounded-2xl transition shadow-xl text-base flex items-center gap-2 cursor-pointer active:scale-98"
              >
                <span>Get Full Access for {formatPrice(bundle.priceINR)}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={onBack}
              className="text-xs font-bold text-slate-400 hover:text-white px-4 py-2 cursor-pointer"
            >
              Browse Other Bundles
            </button>
          </div>
        </section>

      </main>
    </div>
  );
};
