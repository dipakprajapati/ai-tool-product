import React, { useState, useMemo } from 'react';
import { Product, GoalCategory } from '../types';
import { useFirebase } from '../firebase/context';
import {
  Search,
  SlidersHorizontal,
  Star,
  Download,
  Eye,
  Check,
  Zap,
  Tag,
  ArrowUpDown,
  BookOpen,
  FileCode,
  Sparkles,
  Bookmark,
} from 'lucide-react';

interface ProductCatalogProps {
  products: Product[];
  selectedCategory: GoalCategory;
  onSelectCategory: (cat: GoalCategory) => void;
  onOpenCheckout: (product: Product) => void;
  onQuickView: (product: Product) => void;
  onViewProductDetails?: (product: Product) => void;
  onEditInCMS?: (productId: string) => void;
  currency: 'INR' | 'USD';
}

export const ProductCatalog: React.FC<ProductCatalogProps> = ({
  products,
  selectedCategory,
  onSelectCategory,
  onOpenCheckout,
  onQuickView,
  onViewProductDetails,
  onEditInCMS,
  currency,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'popular' | 'price-asc' | 'price-desc' | 'rating'>('popular');
  const [difficultyFilter, setDifficultyFilter] = useState<'all' | 'Beginner' | 'Intermediate'>('all');
  const [visibleCount, setVisibleCount] = useState(9);
  const { isBookmarked, toggleBookmark, isAdmin } = useFirebase();
  const isOwnerVerified = isAdmin || (typeof window !== 'undefined' && localStorage.getItem('apex_owner_verified') === 'true');

  // Conversion rate for USD toggle (1 USD ~ 83 INR)
  const formatPrice = (inrPrice: number) => {
    if (currency === 'USD') {
      const usd = Math.round(inrPrice / 83);
      return `$${usd < 1 ? 1 : usd}`;
    }
    return `₹${inrPrice.toLocaleString('en-IN')}`;
  };

  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      // Category match
      if (selectedCategory !== 'all' && p.category !== selectedCategory) {
        return false;
      }
      // Difficulty match
      if (difficultyFilter !== 'all' && p.difficulty !== difficultyFilter) {
        return false;
      }
      // Search match
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesTitle = p.title.toLowerCase().includes(query);
        const matchesDesc = p.description.toLowerCase().includes(query);
        const matchesCategory = p.categoryLabel.toLowerCase().includes(query);
        const matchesFormat = p.format.toLowerCase().includes(query);
        return matchesTitle || matchesDesc || matchesCategory || matchesFormat;
      }
      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.priceINR - b.priceINR;
      if (sortBy === 'price-desc') return b.priceINR - a.priceINR;
      if (sortBy === 'rating') return b.rating - a.rating;
      // Default: popularity
      return (b.reviewsCount || 0) - (a.reviewsCount || 0);
    });
  }, [products, selectedCategory, difficultyFilter, searchQuery, sortBy]);

  const visibleProducts = filteredProducts.slice(0, visibleCount);

  // Category Pills metadata
  const categoryPills: { id: GoalCategory; label: string }[] = [
    { id: 'all', label: 'All Products (50+)' },
    { id: 'automation', label: 'Business Automation' },
    { id: 'money', label: 'Money & Side Hustles' },
    { id: 'clients', label: 'Marketing & Sales' },
    { id: 'content', label: 'Creator & Media' },
    { id: 'productivity', label: 'Prompts & Productivity' },
    { id: 'skills', label: 'Build Skills' },
  ];

  const getCardIcon = (cat: GoalCategory) => {
    switch (cat) {
      case 'automation':
        return '⚙️';
      case 'money':
        return '💰';
      case 'clients':
        return '📈';
      case 'content':
        return '🚀';
      case 'productivity':
        return '⚡';
      case 'skills':
        return '🎓';
      default:
        return '✨';
    }
  };

  return (
    <section id="shop" className="py-20 bg-slate-50 border-y border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-8">
          <div>
            <span className="text-blue-600 text-xs font-extrabold uppercase tracking-widest flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              PRODUCT ECOSYSTEM
            </span>
            <h2 className="text-3xl sm:text-4xl font-extrabold tracking-tight text-[#0F172A] mt-1">
              Explore All 50+ AI Products
            </h2>
            <p className="mt-2 text-slate-600 text-base max-w-xl">
              Filter or browse our complete collection of practical toolkits, blueprints, and battle-tested prompt systems.
            </p>
          </div>

          {/* Search Bar & Dropdown */}
          <div className="mt-6 md:mt-0 flex flex-col sm:flex-row gap-3 w-full md:w-auto">
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                id="search-input"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search AI products, prompts..."
                className="w-full bg-white border border-slate-300 pl-10 pr-4 py-2.5 rounded-xl text-sm focus:outline-none focus:border-blue-600 focus:ring-1 focus:ring-blue-600 shadow-xs"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-slate-700 cursor-pointer"
                >
                  ✕
                </button>
              )}
            </div>

            {/* Sort Selector */}
            <div className="relative">
              <select
                id="sort-select"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                aria-label="Sort products by"
                className="w-full bg-white border border-slate-300 px-3.5 py-2.5 rounded-xl text-sm focus:outline-none focus:border-blue-600 text-slate-700 shadow-xs cursor-pointer"
              >
                <option value="popular">Sort: Most Popular</option>
                <option value="rating">Sort: Highest Rated</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
              </select>
            </div>
          </div>
        </div>

        {/* Category Pills Strip */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 hide-scrollbar mb-8">
          {categoryPills.map((pill) => (
            <button
              key={pill.id}
              onClick={() => onSelectCategory(pill.id)}
              className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer ${
                selectedCategory === pill.id
                  ? 'bg-blue-600 text-white shadow-sm shadow-blue-500/20'
                  : 'bg-white text-slate-600 border border-slate-200 hover:border-slate-300 hover:text-slate-900'
              }`}
            >
              <span>{pill.label}</span>
              {selectedCategory === pill.id && <Check className="w-3 h-3" />}
            </button>
          ))}
        </div>

        {/* Sub-Filters / Results Count */}
        <div className="flex items-center justify-between text-xs text-slate-500 mb-6 px-1">
          <div>
            Showing <span className="font-bold text-slate-900">{visibleProducts.length}</span> of{' '}
            <span className="font-bold text-slate-900">{filteredProducts.length}</span> items
            {selectedCategory !== 'all' && (
              <span> in {categoryPills.find((p) => p.id === selectedCategory)?.label}</span>
            )}
          </div>
          <div className="flex items-center gap-2">
            <span>Filter Level:</span>
            <button
              onClick={() => setDifficultyFilter('all')}
              className={`px-2 py-1 rounded-md cursor-pointer ${
                difficultyFilter === 'all'
                  ? 'bg-slate-200 text-slate-900 font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setDifficultyFilter('Beginner')}
              className={`px-2 py-1 rounded-md cursor-pointer ${
                difficultyFilter === 'Beginner'
                  ? 'bg-slate-200 text-slate-900 font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Beginner
            </button>
            <button
              onClick={() => setDifficultyFilter('Intermediate')}
              className={`px-2 py-1 rounded-md cursor-pointer ${
                difficultyFilter === 'Intermediate'
                  ? 'bg-slate-200 text-slate-900 font-bold'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Intermediate
            </button>
          </div>
        </div>

        {/* Products Grid */}
        {visibleProducts.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {visibleProducts.map((product) => {
              const savings = Math.round(
                ((product.originalPriceINR - product.priceINR) / product.originalPriceINR) * 100
              );
              const saved = isBookmarked(product.id);

              const productImg = product.imageUrl || (
                product.category === 'automation'
                  ? 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=800&q=80'
                  : product.category === 'money'
                  ? 'https://images.unsplash.com/photo-1553729459-efe14ef6055d?auto=format&fit=crop&w=800&q=80'
                  : product.category === 'clients'
                  ? 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=800&q=80'
                  : product.category === 'content'
                  ? 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&w=800&q=80'
                  : product.category === 'skills'
                  ? 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=800&q=80'
                  : 'https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?auto=format&fit=crop&w=800&q=80'
              );

              return (
                <div
                  key={product.id}
                  id={`product-card-${product.id}`}
                  className="bg-white rounded-3xl border border-slate-200 overflow-hidden flex flex-col justify-between hover:shadow-xl hover:border-blue-400 transition-all group relative"
                >
                  <div>
                    {/* Visual Preview Header with Image */}
                    <div 
                      onClick={() => onViewProductDetails && onViewProductDetails(product)}
                      className="aspect-[16/10] p-6 flex flex-col justify-between text-white relative overflow-hidden cursor-pointer"
                    >
                      <img
                        src={productImg}
                        alt={product.title}
                        className="absolute inset-0 w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/60 to-slate-900/30" />

                      <div className="flex items-center justify-between relative z-10">
                        <span className="text-2xl drop-shadow-md">{getCardIcon(product.category)}</span>
                        <div className="flex items-center gap-1.5">
                          {product.badge && (
                            <span className="bg-blue-600 text-white text-[10px] font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider shadow-sm">
                              {product.badge}
                            </span>
                          )}
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              toggleBookmark(product.id, product.title);
                            }}
                            title={saved ? 'Saved to your Firebase Library' : 'Save to Firebase Library'}
                            className={`w-8 h-8 rounded-full flex items-center justify-center transition backdrop-blur-md cursor-pointer ${
                              saved
                                ? 'bg-amber-500 text-white'
                                : 'bg-black/40 hover:bg-black/60 text-white/90 hover:text-white'
                            }`}
                          >
                            <Bookmark className={`w-4 h-4 ${saved ? 'fill-current' : ''}`} />
                          </button>
                        </div>
                      </div>

                      <div className="relative z-10">
                        <span className="text-[11px] font-mono text-blue-300 font-bold block mb-0.5">
                          {product.format}
                        </span>
                        <div className="text-xs font-semibold text-slate-200 line-clamp-1 drop-shadow-sm">
                          {product.tagline}
                        </div>
                      </div>
                    </div>

                    {/* Content Section */}
                    <div className="p-6">
                      <div className="flex items-center justify-between mb-2">
                        <span className="inline-block bg-blue-50 text-blue-700 text-[11px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                          {product.categoryLabel}
                        </span>
                        <div className="flex items-center gap-1 text-xs font-bold text-amber-500">
                          <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                          <span>{product.rating}</span>
                          <span className="text-slate-400 font-normal">
                            ({product.reviewsCount})
                          </span>
                        </div>
                      </div>

                      <h3 
                        onClick={() => onViewProductDetails && onViewProductDetails(product)}
                        className="text-xl font-bold text-slate-900 group-hover:text-blue-600 transition line-clamp-1 cursor-pointer"
                      >
                        {product.title}
                      </h3>

                      <p className="mt-2 text-sm text-slate-600 line-clamp-2 leading-relaxed">
                        {product.description}
                      </p>

                      {/* Key Deliverables Bullet Preview */}
                      <div className="mt-4 pt-3 border-t border-slate-100 space-y-1.5">
                        {product.deliverables.slice(0, 2).map((item, i) => (
                          <div
                            key={i}
                            className="text-xs text-slate-600 flex items-center gap-1.5 truncate"
                          >
                            <span className="text-blue-600 font-bold">✓</span>
                            <span className="truncate">{item}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Card Bottom / Price & CTA */}
                  <div className="p-6 pt-0 border-t border-slate-100 mt-2">
                    <div className="flex items-center justify-between mb-3 pt-3">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs text-slate-400 line-through">
                            {formatPrice(product.originalPriceINR)}
                          </span>
                          <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                            {savings}% OFF
                          </span>
                        </div>
                        <div className="text-2xl font-extrabold text-slate-900">
                          {formatPrice(product.priceINR)}
                        </div>
                      </div>

                      <div className="flex items-center gap-1.5">
                        {onEditInCMS && isOwnerVerified && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              onEditInCMS(product.id);
                            }}
                            className="text-[11px] font-bold text-amber-700 bg-amber-50 hover:bg-amber-100 border border-amber-300 px-2 py-1 rounded-md transition flex items-center gap-1 cursor-pointer"
                            title="Edit this landing page in WordPress CMS"
                          >
                            <span>✏️ Edit CMS</span>
                          </button>
                        )}
                        <button
                          onClick={() => onQuickView(product)}
                          className="text-xs font-semibold text-slate-500 hover:text-blue-600 flex items-center gap-1 px-2 py-1 rounded hover:bg-slate-100 transition cursor-pointer"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>Quick View</span>
                        </button>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={() => onViewProductDetails && onViewProductDetails(product)}
                        className="flex-1 bg-slate-100 hover:bg-slate-200 text-slate-800 py-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1 cursor-pointer"
                      >
                        <span>Details Page</span>
                        <span>→</span>
                      </button>
                      <button
                        id={`buy-btn-${product.id}`}
                        onClick={() => onOpenCheckout(product)}
                        className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl text-xs font-bold transition shadow-sm shadow-blue-500/20 flex items-center justify-center gap-1.5 active:scale-95 cursor-pointer"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>Get Access</span>
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="bg-white rounded-3xl p-12 text-center border border-slate-200">
            <p className="text-lg font-bold text-slate-900">No products found</p>
            <p className="text-sm text-slate-500 mt-1">
              Try adjusting your search keywords or switching category filters.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                onSelectCategory('all');
                setDifficultyFilter('all');
              }}
              className="mt-4 bg-blue-600 text-white text-xs font-semibold px-4 py-2 rounded-xl"
            >
              Reset Filters
            </button>
          </div>
        )}

        {/* Load More Button */}
        {visibleCount < filteredProducts.length && (
          <div className="mt-12 text-center">
            <button
              id="load-more-products-btn"
              onClick={() => setVisibleCount((prev) => prev + 6)}
              className="bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 font-semibold px-7 py-3.5 rounded-xl text-sm transition shadow-xs inline-flex items-center gap-2 cursor-pointer"
            >
              <span>Load More Products</span>
              <span className="text-xs bg-slate-100 px-2 py-0.5 rounded-full text-slate-600">
                +{filteredProducts.length - visibleCount} more
              </span>
            </button>
            <div className="mt-4 text-center text-slate-500 text-xs">
              Showing {visibleProducts.length} of our directory of 50+ modular products and workflows.
            </div>
          </div>
        )}

        {visibleCount >= filteredProducts.length && filteredProducts.length > 0 && (
          <div className="mt-12 text-center text-slate-500 text-sm">
            Showing top featured items from our directory of 50+ modular products. Scalable for full catalog loading.
          </div>
        )}
      </div>
    </section>
  );
};
