import React, { useState, useEffect, useMemo } from 'react';
import { Product } from '../types';
import { useFirebase } from '../firebase/context';
import {
  ArrowLeft,
  Check,
  CheckCircle2,
  Download,
  Star,
  ShieldCheck,
  Sparkles,
  Clock,
  Layers,
  FileText,
  Share2,
  Bookmark,
  Terminal,
  ChevronDown,
  ChevronUp,
  Lock,
  Zap,
  ArrowRight,
  ExternalLink,
  BookOpen,
  Award,
  Users,
  Target,
  FileCheck,
  Gift
} from 'lucide-react';

interface ProductDetailsPageProps {
  product: Product;
  allProducts?: Product[];
  onBack: () => void;
  onOpenCheckout: (product: Product) => void;
  onSelectProduct?: (product: Product) => void;
  onEditInCMS?: (productId: string) => void;
  currency: 'INR' | 'USD';
}

export const ProductDetailsPage: React.FC<ProductDetailsPageProps> = ({
  product,
  allProducts = [],
  onBack,
  onOpenCheckout,
  onSelectProduct,
  onEditInCMS,
  currency,
}) => {
  const { toggleBookmark, isBookmarked, purchasedProductIds, isAdmin } = useFirebase();
  const isOwnerVerified = isAdmin || (typeof window !== 'undefined' && localStorage.getItem('apex_owner_verified') === 'true');
  const [scrollProgress, setScrollProgress] = useState(0);
  const [activeFaq, setActiveFaq] = useState<number | null>(null);
  const [copiedSnippet, setCopiedSnippet] = useState(false);
  const [copiedShare, setCopiedShare] = useState(false);

  const isPurchased = purchasedProductIds.includes(product.id);
  const saved = isBookmarked(product.id);

  // Scroll tracking
  useEffect(() => {
    const handleScroll = () => {
      const totalScroll = document.documentElement.scrollHeight - window.innerHeight;
      if (totalScroll > 0) {
        const currentProgress = (window.scrollY / totalScroll) * 100;
        setScrollProgress(Math.min(100, Math.max(0, currentProgress)));
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Update dynamic SEO & Structured Data
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });

    const prevTitle = document.title;
    document.title = `${product.title} - Digital AI Toolkit & PDF | ApexAI`;

    let metaDesc = document.querySelector('meta[name="description"]');
    const prevDesc = metaDesc ? metaDesc.getAttribute('content') : '';
    if (metaDesc) {
      metaDesc.setAttribute(
        'content',
        `${product.tagline} Instant PDF & blueprint download. Rated ${product.rating}/5.`
      );
    }

    // JSON-LD Structured Data for Product
    const schemaScript = document.createElement('script');
    schemaScript.type = 'application/ld+json';
    schemaScript.id = 'product-schema-ld';
    schemaScript.text = JSON.stringify({
      '@context': 'https://schema.org',
      '@type': 'Product',
      name: product.title,
      description: product.description,
      image: product.imageUrl || 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
      category: product.categoryLabel,
      offers: {
        '@type': 'Offer',
        priceCurrency: 'INR',
        price: product.priceINR,
        availability: 'https://schema.org/InStock',
        url: window.location.href,
      },
      aggregateRating: {
        '@type': 'AggregateRating',
        ratingValue: product.rating,
        reviewCount: product.reviewsCount,
      },
    });
    document.head.appendChild(schemaScript);

    return () => {
      document.title = prevTitle;
      if (metaDesc && prevDesc) metaDesc.setAttribute('content', prevDesc);
      const existingScript = document.getElementById('product-schema-ld');
      if (existingScript) existingScript.remove();
    };
  }, [product]);

  const formatPrice = (inrPrice: number) => {
    if (currency === 'USD') {
      const usd = Math.round(inrPrice / 83);
      return `$${usd < 1 ? 1 : usd}`;
    }
    return `₹${inrPrice.toLocaleString('en-IN')}`;
  };

  const savingsPercent = Math.round(
    ((product.originalPriceINR - product.priceINR) / product.originalPriceINR) * 100
  );

  // Fallback image helper
  const featureImage = useMemo(() => {
    if (product.imageUrl && product.imageUrl.trim()) return product.imageUrl;
    switch (product.category) {
      case 'automation':
        return 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80';
      case 'money':
        return 'https://images.unsplash.com/photo-1553729459-efe14ef6055d?auto=format&fit=crop&w=1200&q=80';
      case 'clients':
        return 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=1200&q=80';
      case 'content':
        return 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&w=1200&q=80';
      case 'skills':
        return 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=1200&q=80';
      default:
        return 'https://images.unsplash.com/photo-1484480974693-6ca0a78fb36b?auto=format&fit=crop&w=1200&q=80';
    }
  }, [product.imageUrl, product.category]);

  // Related products
  const relatedProducts = useMemo(() => {
    return allProducts
      .filter((p) => p.id !== product.id)
      .slice(0, 3);
  }, [allProducts, product.id]);

  const handleCopySnippet = () => {
    if (product.samplePreviewContent) {
      navigator.clipboard.writeText(product.samplePreviewContent);
      setCopiedSnippet(true);
      setTimeout(() => setCopiedSnippet(false), 2000);
    }
  };

  const handleShare = () => {
    const url = window.location.href;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(url);
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 2000);
    }
  };

  const handleDownloadPurchasedPdf = () => {
    if (product.pdfUrl && product.pdfUrl.trim()) {
      window.open(product.pdfUrl, '_blank', 'noopener,noreferrer');
    } else {
      // Create a clean simulated digital guide blob download
      const content = `%PDF-1.4
% ApexAI Digital Delivery
Toolkit: ${product.title}
Licensed To: Verified Buyer
Deliverables: ${product.deliverables.join(' | ')}
Instructions: Thank you for your purchase. Your complete Notion workspace, prompts, and automation scenario files have been verified.`;
      const blob = new Blob([content], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = product.pdfFileName || `${product.id}_ApexAI_Master_Guide.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }
  };

  const mergedFaqs = useMemo(() => {
    const list: { q: string; a: string }[] = [];
    if (product.faqs && product.faqs.length > 0) {
      product.faqs.forEach((f) => {
        list.push({ q: f.question, a: f.answer });
      });
    }
    const defaultFaqs = [
      {
        q: 'How and when do I get access to the PDF & files?',
        a: 'Instantly! Immediately after completing payment, you will see a direct 1-click Download button on your screen, and an automated email receipt containing your permanent download links and license key will be dispatched to your inbox.',
      },
      {
        q: 'Do I need technical or coding experience?',
        a: `Not at all. This toolkit is rated for ${product.difficulty}. It includes step-by-step documentation, copy-paste prompts, and pre-built templates requiring zero programming background.`,
      },
      {
        q: 'Can I use this for client work or commercial projects?',
        a: 'Yes! All our digital toolkits include an unrestricted commercial implementation license. You can use the blueprints, workflows, and prompts to build solutions for paying clients.',
      },
      {
        q: 'What if I am unhappy with the toolkit?',
        a: product.guaranteeText || 'We offer an unconditional 14-day 100% money-back guarantee. If you test the toolkit and feel it didn’t deliver exceptional value, simply message us for a prompt refund.',
      },
    ];
    return [...list, ...defaultFaqs];
  }, [product]);

  const totalBonusesValue = useMemo(() => {
    return (product.bonuses || []).reduce((acc, b) => acc + (b.valueINR || 0), 0);
  }, [product.bonuses]);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 pb-28">
      {/* Top Reading Progress Bar */}
      <div
        className="fixed top-0 left-0 h-1 bg-gradient-to-r from-blue-600 via-indigo-500 to-emerald-500 z-50 transition-all duration-150"
        style={{ width: `${scrollProgress}%` }}
      />

      {/* Navigation & Header */}
      <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
          <button
            onClick={onBack}
            className="flex items-center gap-2 text-sm font-bold text-slate-700 hover:text-blue-600 transition bg-slate-100 hover:bg-slate-200 px-3.5 py-2 rounded-xl cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span className="hidden sm:inline">Back to All Products</span>
            <span className="sm:hidden">Back</span>
          </button>

          {/* Breadcrumb / Title Snippet */}
          <div className="hidden md:flex items-center gap-2 text-xs text-slate-500 font-medium truncate max-w-md">
            <span>ApexAI</span>
            <span>/</span>
            <span className="text-slate-700 font-semibold">{product.categoryLabel}</span>
            <span>/</span>
            <span className="text-blue-600 truncate">{product.title}</span>
          </div>

          <div className="flex items-center gap-2">
            {onEditInCMS && isOwnerVerified && (
              <button
                type="button"
                onClick={() => onEditInCMS(product.id)}
                className="bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300 px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer shadow-xs"
                title="Edit this product in WordPress CMS"
              >
                <span>✏️ Edit CMS</span>
              </button>
            )}
            <button
              onClick={handleShare}
              className="p-2 text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-xl transition cursor-pointer flex items-center gap-1.5 text-xs font-semibold"
              title="Share Product"
            >
              {copiedShare ? <Check className="w-4 h-4 text-emerald-600" /> : <Share2 className="w-4 h-4" />}
              <span className="hidden sm:inline">{copiedShare ? 'Copied' : 'Share'}</span>
            </button>
            <button
              onClick={() => toggleBookmark(product.id, product.title)}
              className={`p-2 rounded-xl transition cursor-pointer flex items-center gap-1.5 text-xs font-semibold ${
                saved ? 'bg-amber-500 text-white' : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
              }`}
              title={saved ? 'Saved in Firebase Library' : 'Save to Library'}
            >
              <Bookmark className={`w-4 h-4 ${saved ? 'fill-current' : ''}`} />
              <span className="hidden sm:inline">{saved ? 'Saved' : 'Save'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Already Purchased Alert Banner */}
      {isPurchased && (
        <div className="bg-emerald-600 text-white py-3.5 px-4 shadow-md">
          <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
            <div className="flex items-center gap-2.5">
              <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-200" />
              <span className="text-sm font-bold">
                You own this digital product! Your access is active and verified.
              </span>
            </div>
            <button
              onClick={handleDownloadPurchasedPdf}
              className="bg-white text-emerald-800 hover:bg-emerald-50 px-4 py-1.5 rounded-lg text-xs font-extrabold shadow-sm transition flex items-center gap-1.5 cursor-pointer shrink-0"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download PDF &amp; Blueprints</span>
            </button>
          </div>
        </div>
      )}

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 sm:pt-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-start">
          
          {/* LEFT COLUMN: Deep Product Landing Content (8 cols) */}
          <div className="lg:col-span-8 space-y-10">
            
            {/* Hero Card with Feature Image */}
            <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm">
              <div className="relative aspect-[16/9] sm:aspect-[21/9] w-full bg-slate-900 overflow-hidden">
                <img
                  src={featureImage}
                  alt={product.title}
                  className="w-full h-full object-cover object-center opacity-90 hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/40 to-transparent" />
                
                {/* Badges on Hero */}
                <div className="absolute top-4 left-4 flex flex-wrap gap-2">
                  <span className="bg-blue-600/95 backdrop-blur-md text-white text-xs font-extrabold px-3 py-1 rounded-full uppercase tracking-wider shadow-md">
                    {product.categoryLabel}
                  </span>
                  {product.badge && (
                    <span className="bg-amber-500 text-white text-xs font-extrabold px-3 py-1 rounded-full uppercase tracking-wider shadow-md">
                      {product.badge}
                    </span>
                  )}
                  <span className="bg-emerald-600 text-white text-xs font-bold px-3 py-1 rounded-full shadow-md flex items-center gap-1">
                    <FileCheck className="w-3 h-3" />
                    <span>Instant PDF Access</span>
                  </span>
                </div>

                <div className="absolute bottom-4 left-4 right-4 text-white">
                  <span className="text-xs font-mono text-blue-300 font-bold block mb-1">
                    ⚡ {product.format}
                  </span>
                  <div className="flex items-center gap-3 text-xs text-slate-300">
                    <div className="flex items-center gap-1 text-amber-400 font-bold">
                      <Star className="w-4 h-4 fill-current" />
                      <span>{product.rating}</span>
                      <span className="text-slate-300 font-normal">
                        ({product.reviewsCount} verified reviews)
                      </span>
                    </div>
                    <span>•</span>
                    <span>Level: {product.difficulty}</span>
                    <span>•</span>
                    <span className="text-emerald-400 font-semibold">2026 Edition</span>
                  </div>
                </div>
              </div>

              {/* Title & Tagline Header */}
              <div className="p-6 sm:p-8">
                <h1 className="text-2xl sm:text-4xl font-extrabold text-slate-950 tracking-tight leading-tight">
                  {product.title}
                </h1>
                <p className="mt-3 text-base sm:text-lg text-blue-600 font-semibold leading-relaxed">
                  {product.tagline}
                </p>
                <p className="mt-4 text-sm sm:text-base text-slate-600 leading-relaxed">
                  {product.fullDescription || product.description}
                </p>

                {/* Key Metric Highlights */}
                <div className="mt-6 pt-6 border-t border-slate-100 grid grid-cols-2 sm:grid-cols-4 gap-4">
                  <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100 text-center">
                    <Clock className="w-5 h-5 text-blue-600 mx-auto mb-1" />
                    <div className="text-[11px] text-slate-500 font-medium">Setup Time</div>
                    <div className="text-xs font-bold text-slate-900 mt-0.5">&lt; 30 Minutes</div>
                  </div>
                  <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100 text-center">
                    <Layers className="w-5 h-5 text-indigo-600 mx-auto mb-1" />
                    <div className="text-[11px] text-slate-500 font-medium">Deliverables</div>
                    <div className="text-xs font-bold text-slate-900 mt-0.5">{product.deliverables.length} Key Assets</div>
                  </div>
                  <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100 text-center">
                    <ShieldCheck className="w-5 h-5 text-emerald-600 mx-auto mb-1" />
                    <div className="text-[11px] text-slate-500 font-medium">License</div>
                    <div className="text-xs font-bold text-slate-900 mt-0.5">Commercial Use</div>
                  </div>
                  <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-100 text-center">
                    <Download className="w-5 h-5 text-amber-600 mx-auto mb-1" />
                    <div className="text-[11px] text-slate-500 font-medium">Format</div>
                    <div className="text-xs font-bold text-slate-900 mt-0.5 truncate">PDF + Workflows</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Deliverables: What's Inside The Box */}
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm">
              <div className="flex items-center gap-2 text-xs font-extrabold text-blue-600 uppercase tracking-widest mb-1">
                <Sparkles className="w-4 h-4" />
                <span>COMPLETE DELIVERABLE BREAKDOWN</span>
              </div>
              <h2 className="text-2xl font-black text-slate-950">
                What You Get Inside This Digital Product:
              </h2>
              <p className="mt-1 text-sm text-slate-600">
                All components are instantly unlocked upon checkout and sent to your email.
              </p>

              <div className="mt-6 space-y-3">
                {product.deliverables.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-4 rounded-2xl border border-slate-100 bg-slate-50 hover:bg-blue-50/50 hover:border-blue-200 transition flex items-start gap-3.5"
                  >
                    <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 font-bold text-xs mt-0.5 shadow-sm shadow-blue-500/20">
                      0{idx + 1}
                    </div>
                    <div>
                      <div className="text-sm font-bold text-slate-900">{item}</div>
                      <div className="text-xs text-slate-500 mt-0.5 flex items-center gap-1.5">
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span>Ready-to-use template with step-by-step documentation</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* What You Will Achieve (Outcomes) */}
            <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 rounded-3xl p-6 sm:p-8 text-white relative overflow-hidden shadow-lg">
              <div className="absolute top-0 right-0 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
              <div className="relative z-10">
                <div className="flex items-center gap-2 text-xs font-extrabold text-blue-400 uppercase tracking-widest mb-1">
                  <Target className="w-4 h-4" />
                  <span>CONCRETE RESULTS</span>
                </div>
                <h2 className="text-2xl sm:text-3xl font-black tracking-tight">
                  What You Will Achieve With This System:
                </h2>
                <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {product.learningPoints && product.learningPoints.length > 0 ? (
                    product.learningPoints.map((point, idx) => (
                      <div key={idx} className="bg-white/5 border border-white/10 p-4 rounded-2xl backdrop-blur-md flex items-start gap-3">
                        <div className="w-6 h-6 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center shrink-0 mt-0.5">
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                        </div>
                        <span className="text-xs sm:text-sm text-slate-200 font-medium leading-relaxed">
                          {point}
                        </span>
                      </div>
                    ))
                  ) : (
                    <>
                      <div className="bg-white/5 border border-white/10 p-4 rounded-2xl backdrop-blur-md">
                        <div className="text-blue-400 font-extrabold text-sm mb-1">🚀 Save 15+ Hours Every Week</div>
                        <div className="text-xs text-slate-300 leading-relaxed">
                          Automate repetitive manual workflows, client onboarding, and daily copy generation.
                        </div>
                      </div>
                      <div className="bg-white/5 border border-white/10 p-4 rounded-2xl backdrop-blur-md">
                        <div className="text-emerald-400 font-extrabold text-sm mb-1">💰 High-Value Client Offerings</div>
                        <div className="text-xs text-slate-300 leading-relaxed">
                          Deploy professional AI solutions for businesses and charge ₹25,000 to ₹75,000+ per client setup.
                        </div>
                      </div>
                      <div className="bg-white/5 border border-white/10 p-4 rounded-2xl backdrop-blur-md">
                        <div className="text-amber-400 font-extrabold text-sm mb-1">⚡ Zero Coding Needed</div>
                        <div className="text-xs text-slate-300 leading-relaxed">
                          Pre-configured blueprints and templates allow 1-click import into Notion, Zapier, Make, or ChatGPT.
                        </div>
                      </div>
                      <div className="bg-white/5 border border-white/10 p-4 rounded-2xl backdrop-blur-md">
                        <div className="text-purple-400 font-extrabold text-sm mb-1">🔄 Lifetime Updates</div>
                        <div className="text-xs text-slate-300 leading-relaxed">
                          Get access to updated prompt chains and tool revisions at zero additional fee.
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>

            {/* Curriculum / Modules Syllabus (WordPress format) */}
            {product.curriculum && product.curriculum.length > 0 && (
              <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm">
                <div className="flex items-center gap-2 text-xs font-extrabold text-blue-600 uppercase tracking-widest mb-1">
                  <BookOpen className="w-4 h-4" />
                  <span>STEP-BY-STEP CURRICULUM</span>
                </div>
                <h2 className="text-2xl font-black text-slate-950">
                  Execution Modules &amp; Syllabus:
                </h2>
                <p className="mt-1 text-sm text-slate-600">
                  Follow the structured roadmap to implement this toolkit with maximum efficiency.
                </p>

                <div className="mt-6 space-y-3">
                  {product.curriculum.map((mod, idx) => (
                    <div
                      key={idx}
                      className="p-4 rounded-2xl border border-slate-100 bg-slate-50 hover:bg-slate-100/80 transition flex items-start justify-between gap-4"
                    >
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="w-6 h-6 rounded-lg bg-blue-600 text-white font-black text-xs flex items-center justify-center">
                            {idx + 1}
                          </span>
                          <h4 className="font-extrabold text-slate-900 text-sm sm:text-base">
                            {mod.title}
                          </h4>
                        </div>
                        {mod.description && (
                          <p className="text-xs text-slate-600 pl-8 leading-relaxed">
                            {mod.description}
                          </p>
                        )}
                      </div>
                      {mod.duration && (
                        <span className="shrink-0 text-xs font-bold text-slate-600 bg-slate-200/80 px-2.5 py-1 rounded-lg">
                          {mod.duration}
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Target Audience ("Who Is This For?") */}
            {product.targetAudience && product.targetAudience.length > 0 && (
              <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm">
                <div className="flex items-center gap-2 text-xs font-extrabold text-emerald-600 uppercase tracking-widest mb-1">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>PERFECT FIT</span>
                </div>
                <h2 className="text-2xl font-black text-slate-950">
                  Who Is This System Built For?
                </h2>
                <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {product.targetAudience.map((aud, idx) => (
                    <div
                      key={idx}
                      className="p-3.5 rounded-xl border border-slate-100 bg-slate-50 flex items-center gap-3 text-xs sm:text-sm text-slate-800 font-semibold"
                    >
                      <Check className="w-4 h-4 text-emerald-600 shrink-0 stroke-[3]" />
                      <span>{aud}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Included Bonus Stack */}
            {product.bonuses && product.bonuses.length > 0 && (
              <div className="bg-gradient-to-br from-amber-500/10 via-amber-500/5 to-transparent rounded-3xl p-6 sm:p-8 border-2 border-amber-500/30 shadow-sm">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-2">
                    <Gift className="w-5 h-5 text-amber-600" />
                    <span className="text-xs font-extrabold uppercase tracking-wider text-amber-700">
                      FREE EXCLUSIVE BONUSES INCLUDED
                    </span>
                  </div>
                  {totalBonusesValue > 0 && (
                    <span className="bg-amber-600 text-white text-xs font-black px-3 py-1 rounded-full shadow-sm">
                      Total Bonus Value: ₹{totalBonusesValue.toLocaleString('en-IN')}
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {product.bonuses.map((bonus, idx) => (
                    <div
                      key={idx}
                      className="bg-white p-4 rounded-2xl border border-amber-200 shadow-sm flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-[10px] font-black uppercase text-amber-700 bg-amber-100 px-2 py-0.5 rounded">
                            Bonus #{idx + 1}
                          </span>
                          {bonus.valueINR > 0 && (
                            <span className="text-xs font-bold text-slate-500 line-through">
                              Worth ₹{bonus.valueINR.toLocaleString('en-IN')}
                            </span>
                          )}
                        </div>
                        <h4 className="font-extrabold text-slate-900 text-sm mt-1">
                          {bonus.title}
                        </h4>
                        <p className="text-xs text-slate-600 mt-1 leading-relaxed">
                          {bonus.description}
                        </p>
                      </div>
                      <div className="mt-3 pt-2 border-t border-slate-100 text-[11px] font-bold text-emerald-600 flex items-center gap-1">
                        <Check className="w-3.5 h-3.5" />
                        <span>Included Free with Purchase</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Interactive Sample Blueprint / Prompt Snippet */}
            {product.samplePreviewContent && (
              <div className="bg-slate-900 rounded-3xl p-6 sm:p-8 border border-slate-800 text-slate-100 shadow-sm">
                <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                  <div className="flex items-center gap-2 font-mono text-xs text-blue-400 font-bold">
                    <Terminal className="w-4 h-4 text-blue-400" />
                    <span>{product.samplePreviewTitle || 'Verified Blueprint Prompt Preview'}</span>
                  </div>
                  <button
                    onClick={handleCopySnippet}
                    className="text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg transition flex items-center gap-1.5 cursor-pointer"
                  >
                    {copiedSnippet ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Share2 className="w-3.5 h-3.5" />}
                    <span>{copiedSnippet ? 'Copied!' : 'Copy Snippet'}</span>
                  </button>
                </div>
                <div className="mt-4 p-4 rounded-2xl bg-slate-950 border border-slate-800 font-mono text-xs leading-relaxed text-slate-300">
                  &quot;{product.samplePreviewContent}&quot;
                </div>
                <p className="mt-3 text-[11px] text-slate-500">
                  * This is 1 sample of the comprehensive prompt architectures and blueprints included inside the full toolkit download.
                </p>
              </div>
            )}

            {/* Frequently Asked Questions */}
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm">
              <h2 className="text-2xl font-black text-slate-900 mb-6">
                Frequently Asked Questions
              </h2>
              <div className="space-y-3">
                {mergedFaqs.map((faq, idx) => (
                  <div
                    key={idx}
                    className="border border-slate-200 rounded-2xl overflow-hidden transition"
                  >
                    <button
                      onClick={() => setActiveFaq(activeFaq === idx ? null : idx)}
                      className="w-full text-left p-4.5 bg-slate-50 hover:bg-slate-100 transition flex items-center justify-between text-sm font-bold text-slate-900 cursor-pointer"
                    >
                      <span>{faq.q}</span>
                      {activeFaq === idx ? (
                        <ChevronUp className="w-4 h-4 text-blue-600 shrink-0" />
                      ) : (
                        <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                      )}
                    </button>
                    {activeFaq === idx && (
                      <div className="p-4.5 text-xs sm:text-sm text-slate-600 leading-relaxed bg-white border-t border-slate-100">
                        {faq.a}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>

            {/* Author & Creator Guarantee */}
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm flex flex-col sm:flex-row items-center gap-6">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white font-extrabold text-2xl flex items-center justify-center shrink-0 shadow-lg shadow-blue-500/25">
                DP
              </div>
              <div className="text-center sm:text-left">
                <div className="text-xs font-bold text-blue-600 uppercase tracking-wider">
                  Engineered &amp; Curated by
                </div>
                <h3 className="text-lg font-extrabold text-slate-900 mt-0.5">
                  {product.authorBio || 'Dipak Prajapati • Founder, ApexAI'}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 mt-1 leading-relaxed">
                  {product.guaranteeText || 'Every blueprint, script, and prompt sequence is personally tested in active business environments before release. We stand 100% behind the real-world utility of our toolkits with an unconditional 14-day refund guarantee.'}
                </p>
              </div>
            </div>

          </div>

          {/* RIGHT COLUMN: Desktop Sticky Pricing & Buy Card (4 cols) */}
          <div className="lg:col-span-4 sticky top-24 space-y-6">
            <div className="bg-white rounded-3xl p-6 sm:p-8 border-2 border-blue-600/30 shadow-xl relative overflow-hidden">
              
              {/* Highlight ribbon */}
              <div className="absolute top-0 right-0 bg-blue-600 text-white text-[11px] font-extrabold px-3 py-1 rounded-bl-xl uppercase tracking-wider">
                Digital Download
              </div>

              <div className="flex items-center gap-2 mb-3">
                <span className="text-xs text-slate-400 line-through">
                  {formatPrice(product.originalPriceINR)}
                </span>
                <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
                  Save {savingsPercent}% Today
                </span>
              </div>

              {/* Price */}
              <div className="text-4xl font-black text-slate-950 tracking-tight">
                {formatPrice(product.priceINR)}
              </div>
              <div className="text-xs text-slate-500 mt-1">
                One-time payment • Lifetime access • No recurring fees
              </div>

              {/* Action Buttons */}
              <div className="mt-6 space-y-3">
                {isPurchased ? (
                  <button
                    onClick={handleDownloadPurchasedPdf}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold py-4 rounded-2xl text-sm transition shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Your PDF Toolkit</span>
                  </button>
                ) : (
                  <button
                    id="product-details-buy-btn"
                    onClick={() => onOpenCheckout(product)}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white font-extrabold py-4 rounded-2xl text-sm sm:text-base transition shadow-lg shadow-blue-500/30 flex items-center justify-center gap-2 active:scale-95 cursor-pointer"
                  >
                    <Download className="w-5 h-5" />
                    <span>Get Instant Access Now</span>
                  </button>
                )}

                <button
                  onClick={() => toggleBookmark(product.id, product.title)}
                  className={`w-full py-3 rounded-xl text-xs font-bold transition border flex items-center justify-center gap-2 cursor-pointer ${
                    saved
                      ? 'border-amber-400 bg-amber-50 text-amber-800'
                      : 'border-slate-200 hover:border-slate-300 text-slate-700 bg-slate-50'
                  }`}
                >
                  <Bookmark className={`w-3.5 h-3.5 ${saved ? 'fill-current text-amber-600' : ''}`} />
                  <span>{saved ? 'Saved in Firebase Library' : 'Save To Wishlist'}</span>
                </button>
              </div>

              {/* Trust Badges */}
              <div className="mt-6 pt-6 border-t border-slate-100 space-y-3 text-xs text-slate-600">
                <div className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Instant screen download &amp; email delivery</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Verified PDF Playbook &amp; Source Files</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>14-day 100% money-back guarantee</span>
                </div>
                <div className="flex items-center gap-2.5">
                  <Lock className="w-4 h-4 text-blue-600 shrink-0" />
                  <span>256-Bit SSL Encrypted checkout (UPI &amp; Cards)</span>
                </div>
              </div>

              {/* Direct Support Note */}
              <div className="mt-6 bg-slate-50 p-3.5 rounded-2xl border border-slate-100 text-center text-[11px] text-slate-500">
                Need team licensing or custom installation?{' '}
                <a
                  href="mailto:dipakprajapati102@gmail.com"
                  className="text-blue-600 font-bold hover:underline"
                >
                  Contact Founder
                </a>
              </div>
            </div>

            {/* Quick Author Guarantee Box */}
            <div className="bg-emerald-50 rounded-3xl p-5 border border-emerald-100 text-emerald-900">
              <div className="flex items-center gap-2 font-bold text-xs">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Risk-Free Guarantee</span>
              </div>
              <p className="mt-1.5 text-xs text-emerald-800 leading-relaxed">
                If this toolkit doesn&apos;t save you at least 10 hours or help you close your next client, just let us know for a full refund.
              </p>
            </div>

          </div>

        </div>

        {/* RELATED TOOLKITS SECTION */}
        <section className="mt-20 pt-12 border-t border-slate-200">
          <div className="flex items-center justify-between mb-8">
            <div>
              <span className="text-xs font-extrabold uppercase tracking-widest text-blue-600">
                RECOMMENDED ADD-ONS
              </span>
              <h2 className="text-2xl font-black text-slate-900 mt-1">
                More AI Toolkits You Might Like
              </h2>
            </div>
            <button
              onClick={onBack}
              className="text-xs font-bold text-blue-600 hover:text-blue-700 flex items-center gap-1 cursor-pointer"
            >
              <span>View All 50+ Products</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {relatedProducts.map((rel) => (
              <div
                key={rel.id}
                onClick={() => onSelectProduct(rel)}
                className="bg-white rounded-3xl p-6 border border-slate-200 hover:border-blue-400 hover:shadow-xl transition-all cursor-pointer flex flex-col justify-between group"
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-full uppercase">
                      {rel.categoryLabel}
                    </span>
                    <div className="flex items-center gap-1 text-xs font-bold text-amber-500">
                      <Star className="w-3.5 h-3.5 fill-current" />
                      <span>{rel.rating}</span>
                    </div>
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 group-hover:text-blue-600 transition">
                    {rel.title}
                  </h3>
                  <p className="text-xs text-slate-600 mt-2 line-clamp-2">
                    {rel.tagline}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
                  <div className="text-lg font-extrabold text-slate-900">
                    {formatPrice(rel.priceINR)}
                  </div>
                  <span className="text-xs font-bold text-blue-600 group-hover:translate-x-1 transition-transform flex items-center gap-1">
                    <span>View Details</span>
                    <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        </section>

      </main>

      {/* MOBILE STICKY BOTTOM BAR */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 p-4 shadow-2xl flex items-center justify-between gap-4">
        <div>
          <div className="text-xs text-slate-400 line-through">
            {formatPrice(product.originalPriceINR)}
          </div>
          <div className="text-xl font-black text-slate-900 leading-none">
            {formatPrice(product.priceINR)}
          </div>
        </div>

        {isPurchased ? (
          <button
            onClick={handleDownloadPurchasedPdf}
            className="flex-1 bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold py-3 rounded-xl text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-md"
          >
            <Download className="w-4 h-4" />
            <span>Download PDF</span>
          </button>
        ) : (
          <button
            onClick={() => onOpenCheckout(product)}
            className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-extrabold py-3 rounded-xl text-xs flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-blue-500/25"
          >
            <Download className="w-4 h-4" />
            <span>Get Instant Access</span>
          </button>
        )}
      </div>
    </div>
  );
};
