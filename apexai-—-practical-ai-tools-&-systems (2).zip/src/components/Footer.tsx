import React from 'react';
import { GoalCategory } from '../types';
import { Lock } from 'lucide-react';

interface FooterProps {
  onSelectCategory: (cat: GoalCategory) => void;
  onOpenAdmin?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectCategory, onOpenAdmin }) => {
  const handleCategoryClick = (cat: GoalCategory) => {
    onSelectCategory(cat);
    const shopEl = document.getElementById('shop');
    if (shopEl) shopEl.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer id="main-footer" className="bg-white border-t border-slate-200 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-10">
        {/* Brand column */}
        <div className="space-y-3">
          <div className="flex items-center gap-2.5">
            <span className="w-8 h-8 bg-blue-600 text-white rounded-lg flex items-center justify-center text-sm font-bold shadow-sm">
              AI
            </span>
            <span className="text-xl font-extrabold tracking-tight text-[#0F172A]">
              Apex<span className="text-blue-600">AI</span>
            </span>
          </div>
          <p className="text-sm text-slate-600 leading-relaxed">
            Practical AI tools, templates, prompts and systems designed to help you save time,
            create faster, and build new digital opportunities.
          </p>
          <div className="pt-2 text-xs text-slate-400">
            Trusted by 12,400+ creators, freelancers &amp; agencies.
          </div>
        </div>

        {/* Quick Links */}
        <div>
          <h4 className="font-bold text-xs text-slate-900 uppercase tracking-wider mb-4">
            Quick Links
          </h4>
          <ul className="space-y-2.5 text-sm text-slate-600">
            <li>
              <a href="#shop" className="hover:text-blue-600 transition">
                Shop All (50+ Products)
              </a>
            </li>
            <li>
              <a href="#bundles" className="hover:text-blue-600 transition">
                Complete AI Bundles
              </a>
            </li>
            <li>
              <a href="#free-resources" className="hover:text-blue-600 transition">
                Free 50 Prompts Guide
              </a>
            </li>
            <li>
              <a href="#how-it-works" className="hover:text-blue-600 transition">
                How It Works
              </a>
            </li>
            <li>
              <a href="#blog" className="hover:text-blue-600 transition">
                Blog &amp; Tutorials
              </a>
            </li>
            <li>
              <a href="#faq" className="hover:text-blue-600 transition">
                FAQ
              </a>
            </li>
          </ul>
        </div>

        {/* Categories */}
        <div>
          <h4 className="font-bold text-xs text-slate-900 uppercase tracking-wider mb-4">
            Categories
          </h4>
          <ul className="space-y-2.5 text-sm text-slate-600">
            <li>
              <button
                onClick={() => handleCategoryClick('money')}
                className="hover:text-blue-600 transition text-left cursor-pointer"
              >
                AI Money &amp; Side Hustles
              </button>
            </li>
            <li>
              <button
                onClick={() => handleCategoryClick('automation')}
                className="hover:text-blue-600 transition text-left cursor-pointer"
              >
                AI Business &amp; Automation
              </button>
            </li>
            <li>
              <button
                onClick={() => handleCategoryClick('clients')}
                className="hover:text-blue-600 transition text-left cursor-pointer"
              >
                AI Marketing &amp; Sales
              </button>
            </li>
            <li>
              <button
                onClick={() => handleCategoryClick('content')}
                className="hover:text-blue-600 transition text-left cursor-pointer"
              >
                AI Creator Tools
              </button>
            </li>
            <li>
              <button
                onClick={() => handleCategoryClick('productivity')}
                className="hover:text-blue-600 transition text-left cursor-pointer"
              >
                AI Prompts &amp; Productivity
              </button>
            </li>
            <li>
              <button
                onClick={() => handleCategoryClick('skills')}
                className="hover:text-blue-600 transition text-left cursor-pointer"
              >
                Build AI Skills
              </button>
            </li>
          </ul>
        </div>

        {/* Legal & Support */}
        <div>
          <h4 className="font-bold text-xs text-slate-900 uppercase tracking-wider mb-4">
            Legal &amp; Support
          </h4>
          <ul className="space-y-2.5 text-sm text-slate-600">
            <li>
              <a href="#faq" className="hover:text-blue-600 transition">
                Help &amp; Contact Support
              </a>
            </li>
            <li>
              <span className="text-slate-500">Privacy Policy (Standard SSL Secure)</span>
            </li>
            <li>
              <span className="text-slate-500">Terms: Personal &amp; Commercial Use</span>
            </li>
            <li>
              <span className="text-slate-500">14-Day Satisfaction Guarantee</span>
            </li>
            <li className="pt-2 text-xs text-slate-400">
              Support: <span className="text-slate-600 font-medium">support@apexai.tools</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 pt-8 border-t border-slate-100 flex flex-col sm:flex-row justify-between items-center text-xs text-slate-500 gap-2">
        <p>© 2026 ApexAI Systems. All rights reserved.</p>
        <div className="flex items-center gap-3">
          <p>Designed for digital creators, freelancers &amp; businesses.</p>
          {/* Discreet Owner Access */}
          {onOpenAdmin && (
            <button
              type="button"
              onClick={onOpenAdmin}
              title="Ctrl+Shift+A"
              className="text-slate-300 hover:text-slate-400 transition p-1 cursor-pointer"
            >
              <Lock className="w-3 h-3" />
            </button>
          )}
        </div>
      </div>
    </footer>
  );
};
