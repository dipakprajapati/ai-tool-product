import React, { useState, useEffect } from 'react';
import { Product, Bundle, OrderInfo } from '../types';
import { useFirebase } from '../firebase/context';
import { createOrderInFirestore, sendAutomatedOrderEmail } from '../firebase/services';
import {
  X,
  ShieldCheck,
  Download,
  CheckCircle2,
  Lock,
  Tag,
  CreditCard,
  QrCode,
  Building,
  Check,
  Copy,
  Mail,
  ExternalLink,
  AlertCircle,
  Clock,
  ArrowRight,
  ArrowLeft,
  Smartphone,
  RefreshCw,
  Zap,
} from 'lucide-react';

interface CheckoutModalProps {
  item: Product | Bundle | null;
  onClose: () => void;
  currency: 'INR' | 'USD';
}

type PaymentMode = 'upi' | 'card' | 'netbanking' | 'razorpay';

export const CheckoutModal: React.FC<CheckoutModalProps> = ({ item, onClose, currency }) => {
  if (!item) return null;

  const { user, markProductPurchased, paymentSettings, signInWithGoogle } = useFirebase();

  // Step flow: 'details' (contact & discount) -> 'payment' (choose mode & pay) -> 'processing' -> 'complete'
  const [step, setStep] = useState<'details' | 'payment' | 'complete'>('details');

  // Customer details
  const [fullName, setFullName] = useState(user?.displayName || '');
  const [email, setEmail] = useState(user?.email || '');
  const [emailError, setEmailError] = useState('');
  const [nameError, setNameError] = useState('');

  // Coupons
  const [couponCode, setCouponCode] = useState('');
  const [appliedDiscount, setAppliedDiscount] = useState<number | null>(null);
  const [couponError, setCouponError] = useState('');
  const [couponSuccess, setCouponSuccess] = useState('');

  // Payment Method Selection (ALL MODES AVAILABLE)
  const [selectedMethod, setSelectedMethod] = useState<PaymentMode>('upi');

  // UPI Mode states
  const [customerUpiId, setCustomerUpiId] = useState('');
  const [copiedUpi, setCopiedUpi] = useState(false);

  // Card Mode states
  const [cardNumber, setCardNumber] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvv, setCardCvv] = useState('');
  const [cardHolder, setCardHolder] = useState('');
  const [cardError, setCardError] = useState('');

  // Net Banking Mode states
  const [selectedBank, setSelectedBank] = useState('HDFC');

  // Processing state
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStatus, setProcessingStatus] = useState('');

  // Order Complete states
  const [orderComplete, setOrderComplete] = useState<OrderInfo | null>(null);
  const [emailCopied, setEmailCopied] = useState(false);
  const [portalCopied, setPortalCopied] = useState(false);
  const [emailStatusMessage, setEmailStatusMessage] = useState<string | null>(null);

  // Merchant info from settings or sensible defaults
  const merchantUpiId = paymentSettings?.merchantUpiId?.trim() || 'apexai@upi';
  const merchantName = paymentSettings?.merchantName?.trim() || 'ApexAI Technologies';
  const activeRazorpayUrl = item.paymentLink || paymentSettings?.defaultRazorpayUrl || '';

  useEffect(() => {
    if (user) {
      if (!fullName && user.displayName) setFullName(user.displayName);
      if (!email && user.email) setEmail(user.email);
    }
  }, [user]);

  // Price calculations
  const basePriceINR = item.priceINR;
  const discountAmountINR = appliedDiscount ? Math.round((basePriceINR * appliedDiscount) / 100) : 0;
  const finalPriceINR = Math.max(0, basePriceINR - discountAmountINR);

  const formatPrice = (inrPrice: number) => {
    if (currency === 'USD') {
      const usd = Math.round(inrPrice / 83);
      return `$${usd < 1 ? 1 : usd}`;
    }
    return `₹${inrPrice.toLocaleString('en-IN')}`;
  };

  // Strict email validation to prevent dummy emails & assure real delivery
  const validateEmailStrict = (val: string): boolean => {
    const clean = val.trim().toLowerCase();
    const regex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!regex.test(clean)) return false;

    const dummyDomains = [
      'test.com', 'example.com', 'sample.com', 'fake.com', 'asdf.com',
      'xyz.com', 'mailinator.com', 'tempmail.com', 'dummy.com', 'trashmail.com'
    ];
    const dummyPrefixes = ['test', 'fake', 'dummy', 'asdf', 'xyz', 'aaa', '123', 'admin'];

    const parts = clean.split('@');
    if (parts.length !== 2) return false;
    const [local, domain] = parts;

    if (local.length < 3) return false;
    if (dummyDomains.includes(domain)) return false;
    if (dummyPrefixes.includes(local) && (domain.includes('test') || domain.includes('fake') || domain.includes('asdf'))) return false;

    return true;
  };

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    setCouponError('');
    setCouponSuccess('');

    const clean = couponCode.trim().toUpperCase();
    if (clean === 'LAUNCH60') {
      setAppliedDiscount(60);
      setCouponSuccess('Launch promo applied: 60% OFF!');
    } else if (clean === 'WELCOME20' || clean === 'AI20') {
      setAppliedDiscount(20);
      setCouponSuccess('Welcome voucher applied: 20% OFF!');
    } else {
      setCouponError('Invalid coupon code. Try code LAUNCH60');
    }
  };

  // Format Card Number (adds spaces every 4 digits)
  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.replace(/\D/g, '').slice(0, 16);
    val = val.replace(/(\d{4})(?=\d)/g, '$1 ');
    setCardNumber(val);
    setCardError('');
  };

  // Format Expiry MM/YY
  const handleExpiryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let val = e.target.value.replace(/\D/g, '').slice(0, 4);
    if (val.length >= 2) {
      val = `${val.slice(0, 2)}/${val.slice(2)}`;
    }
    setCardExpiry(val);
  };

  // Copy UPI ID helper
  const handleCopyUpi = () => {
    navigator.clipboard.writeText(merchantUpiId);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2000);
  };

  // Step 1 -> Step 2 validation
  const handleProceedToPaymentModes = (e: React.FormEvent) => {
    e.preventDefault();
    setEmailError('');
    setNameError('');

    const trimmedName = fullName.trim();
    const trimmedEmail = email.trim();

    if (!trimmedName || trimmedName.length < 2) {
      setNameError('Please enter your full name.');
      return;
    }

    if (!validateEmailStrict(trimmedEmail)) {
      setEmailError('Please enter a valid, active email address (e.g. name@gmail.com). Your PDF download link will be sent here.');
      return;
    }

    setStep('payment');
  };

  // Final Payment Processing (for UPI, Card, Net Banking, or Razorpay)
  const handleExecutePayment = async (e: React.FormEvent) => {
    e.preventDefault();
    setCardError('');

    // Method-specific validations
    if (selectedMethod === 'card') {
      const cleanNum = cardNumber.replace(/\s+/g, '');
      if (cleanNum.length < 15) {
        setCardError('Please enter a valid 16-digit card number.');
        return;
      }
      if (cardExpiry.length < 5) {
        setCardError('Please enter card expiry date (MM/YY).');
        return;
      }
      if (cardCvv.length < 3) {
        setCardError('Please enter 3-digit CVV.');
        return;
      }
    }

    // If Razorpay gateway option selected and has URL, open it in popup
    if (selectedMethod === 'razorpay' && activeRazorpayUrl) {
      window.open(activeRazorpayUrl, '_blank', 'noopener,noreferrer');
    }

    setIsProcessing(true);
    setProcessingStatus('Initiating secure 256-bit encrypted connection...');

    // Smooth realistic processing transitions
    await new Promise((r) => setTimeout(r, 600));
    setProcessingStatus('Authorizing transaction with bank gateway...');
    await new Promise((r) => setTimeout(r, 700));
    setProcessingStatus('Payment verified! Generating your official PDF license...');
    await new Promise((r) => setTimeout(r, 500));

    try {
      const orderId = `APX-${Math.floor(100000 + Math.random() * 900000)}`;
      const targetPdfUrl = 'pdfUrl' in item && item.pdfUrl ? item.pdfUrl.trim() : '';

      // Create order in Firestore
      await createOrderInFirestore({
        orderId,
        userId: user ? user.uid : 'guest',
        productId: item.id,
        customerName: fullName.trim(),
        customerEmail: email.trim(),
        productTitle: item.title,
        totalPaid: finalPriceINR,
        currency,
        paymentMethod: selectedMethod,
        status: 'completed',
        pdfUrl: targetPdfUrl,
      });

      // Mark purchased locally & in context
      markProductPurchased(item.id);

      // STRICTLY ONLY 1 deliverable: The exact product PDF
      const pdfFileName = 'pdfFileName' in item && item.pdfFileName
        ? item.pdfFileName
        : `${item.title.replace(/\s+/g, '_')}_Official_Guide.pdf`;

      const singleDeliverable = {
        name: pdfFileName,
        type: 'Official Digital PDF',
        size: 'Direct Download',
        downloadUrl: targetPdfUrl,
      };

      const orderData: OrderInfo = {
        orderId,
        productId: item.id,
        customerName: fullName.trim(),
        customerEmail: email.trim(),
        productName: item.title,
        totalPaid: finalPriceINR,
        pdfUrl: targetPdfUrl,
        date: new Date().toLocaleDateString('en-US', {
          month: 'short',
          day: 'numeric',
          year: 'numeric',
        }),
        downloads: [singleDeliverable], // STRICT: ONLY 1 single download
      };

      setOrderComplete(orderData);

      // Trigger automated email notification (Resend / Webhook if configured)
      const mailResult = await sendAutomatedOrderEmail({
        toEmail: email.trim(),
        customerName: fullName.trim(),
        productTitle: item.title,
        orderId,
        totalPaid: finalPriceINR,
        pdfUrl: targetPdfUrl,
        settings: paymentSettings,
      });

      if (mailResult.success) {
        setEmailStatusMessage(mailResult.message);
      }

      setStep('complete');
    } catch (err) {
      console.error('Payment processing failed:', err);
      setCardError('An unexpected error occurred. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  // Download the single verified PDF
  const handleDownloadSinglePdf = () => {
    const targetPdfUrl = 'pdfUrl' in item && item.pdfUrl ? item.pdfUrl.trim() : '';
    if (targetPdfUrl) {
      window.open(targetPdfUrl, '_blank', 'noopener,noreferrer');
      return;
    }

    // If admin has not yet provided direct PDF link in CMS, generate standard verified receipt document
    const fileName = 'pdfFileName' in item && item.pdfFileName
      ? item.pdfFileName
      : `${item.title.replace(/\s+/g, '_')}_Official_Guide.pdf`;

    const content = `%PDF-1.4
% ApexAI Certified Digital Delivery
Order: #${orderComplete?.orderId}
Customer: ${fullName} (${email})
Product Deliverable: ${item.title}
Amount Paid: ₹${finalPriceINR}
Payment Mode: ${selectedMethod.toUpperCase()}
Status: VERIFIED & COMPLETED
Date: ${new Date().toISOString()}

Notice: You hold an active, verified commercial license for this product. If a direct cloud PDF link is configured in CMS, it opens directly.`;

    const blob = new Blob([content], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Webmail direct 1-click links for instant customer receipt & delivery
  const getGmailUrl = () => {
    if (!orderComplete) return '';
    const dlLink = orderComplete.pdfUrl || window.location.href;
    const subject = encodeURIComponent(`[ApexAI Verified Order] Access to ${orderComplete.productName} (#${orderComplete.orderId})`);
    const body = encodeURIComponent(
      `Hello ${orderComplete.customerName},\n\n` +
      `Here is your verified purchase receipt for ${orderComplete.productName}.\n\n` +
      `Order ID: #${orderComplete.orderId}\n` +
      `Amount Paid: ₹${orderComplete.totalPaid}\n` +
      `Payment Method: ${selectedMethod.toUpperCase()}\n` +
      `Payment Status: VERIFIED\n\n` +
      `DIRECT DOWNLOAD PDF LINK:\n${dlLink}\n\n` +
      `You can also download this PDF anytime on the ApexAI website by clicking 'My Downloads' using your email: ${orderComplete.customerEmail}\n\n` +
      `Warm regards,\n` +
      `ApexAI Systems`
    );
    return `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(orderComplete.customerEmail)}&su=${subject}&body=${body}`;
  };

  const handleCopyReceipt = () => {
    if (!orderComplete) return;
    const dlLink = orderComplete.pdfUrl || 'Available in My Downloads';
    const text = `APEXAI VERIFIED ORDER RECEIPT\nOrder ID: #${orderComplete.orderId}\nProduct: ${orderComplete.productName}\nCustomer: ${orderComplete.customerName} (${orderComplete.customerEmail})\nPaid: ₹${orderComplete.totalPaid}\nMethod: ${selectedMethod.toUpperCase()}\nStatus: VERIFIED & LICENSED\nPDF Access Link: ${dlLink}`;
    navigator.clipboard.writeText(text);
    setEmailCopied(true);
    setTimeout(() => setEmailCopied(false), 2000);
  };

  const handleCopyPortalLink = () => {
    const link = `${window.location.origin}/#download?orderId=${orderComplete?.orderId}&email=${encodeURIComponent(email)}`;
    navigator.clipboard.writeText(link);
    setPortalCopied(true);
    setTimeout(() => setPortalCopied(false), 2000);
  };

  // Dynamic QR Code generation for UPI payments
  const upiPayload = `upi://pay?pa=${encodeURIComponent(merchantUpiId)}&pn=${encodeURIComponent(merchantName)}&am=${finalPriceINR}&cu=INR&tn=${encodeURIComponent(`ApexAI-${item.title.slice(0, 15)}`)}`;
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(upiPayload)}`;

  const popularBanks = [
    { id: 'HDFC', name: 'HDFC Bank', code: 'HDFC' },
    { id: 'SBI', name: 'State Bank of India', code: 'SBI' },
    { id: 'ICICI', name: 'ICICI Bank', code: 'ICICI' },
    { id: 'AXIS', name: 'Axis Bank', code: 'AXIS' },
    { id: 'KOTAK', name: 'Kotak Mahindra', code: 'KOTAK' },
    { id: 'PNB', name: 'Punjab National Bank', code: 'PNB' },
  ];

  return (
    <div
      id="checkout-modal"
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 overflow-y-auto animate-fadeIn"
    >
      <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 relative shadow-2xl my-8 max-h-[95vh] overflow-y-auto border border-slate-100">
        {/* Close Button */}
        <button
          onClick={onClose}
          id="close-checkout-modal-btn"
          className="absolute top-6 right-6 text-slate-400 hover:text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-full w-9 h-9 flex items-center justify-center text-lg font-bold transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* STEP 1: CONTACT DETAILS & COUPON */}
        {step === 'details' && (
          <>
            <div className="flex items-center gap-2 text-blue-600 font-bold text-xs uppercase tracking-wider mb-1">
              <Lock className="w-3.5 h-3.5" />
              <span>Step 1 of 2: Buyer &amp; Order Details</span>
            </div>
            <h3 className="text-2xl font-extrabold text-slate-900">
              Instant Access Checkout
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Enter your details to generate your official commercial license.
            </p>

            {/* Product Summary Box */}
            <div className="mt-5 bg-slate-50 p-4 rounded-2xl border border-slate-200">
              <div className="flex items-start justify-between">
                <div>
                  <div id="modal-product-name" className="font-bold text-slate-900 text-sm sm:text-base">
                    {item.title}
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    {'categoryLabel' in item ? item.categoryLabel : 'Complete Multi-Product Bundle'} • 1 Official PDF Guide
                  </div>
                </div>
                <div className="text-right">
                  {appliedDiscount && (
                    <div className="text-xs text-slate-400 line-through">
                      {formatPrice(basePriceINR)}
                    </div>
                  )}
                  <div id="modal-product-price" className="text-xl font-extrabold text-blue-600">
                    {formatPrice(finalPriceINR)}
                  </div>
                </div>
              </div>

              {/* Coupon Code Input */}
              <div className="mt-3 pt-3 border-t border-slate-200">
                <form onSubmit={handleApplyCoupon} className="flex gap-2">
                  <div className="relative flex-1">
                    <Tag className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input
                      type="text"
                      value={couponCode}
                      onChange={(e) => setCouponCode(e.target.value)}
                      placeholder="Promo code (e.g. LAUNCH60)"
                      className="w-full bg-white border border-slate-300 pl-8 pr-3 py-1.5 rounded-xl text-xs uppercase focus:outline-none focus:border-blue-600 font-mono"
                    />
                  </div>
                  <button
                    type="submit"
                    className="bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold px-3 py-1.5 rounded-xl transition cursor-pointer"
                  >
                    Apply
                  </button>
                </form>

                {couponSuccess && (
                  <div className="text-[11px] text-emerald-600 font-bold mt-1.5 flex items-center gap-1">
                    <Check className="w-3 h-3" /> {couponSuccess}
                  </div>
                )}
                {couponError && (
                  <div className="text-[11px] text-rose-600 mt-1.5">
                    {couponError}
                  </div>
                )}
              </div>
            </div>

            {/* Google 1-Click Verification Banner */}
            {!user ? (
              <div className="mt-4 p-3 bg-blue-50/70 border border-blue-200/80 rounded-2xl flex items-center justify-between gap-3">
                <div className="text-xs">
                  <span className="font-bold text-blue-900 block">Fast 1-Click Verified Checkout</span>
                  <span className="text-blue-700/80 text-[11px]">Sign in with Google to auto-verify email &amp; license</span>
                </div>
                <button
                  type="button"
                  onClick={async () => {
                    await signInWithGoogle();
                  }}
                  className="bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 font-bold text-xs px-3 py-1.5 rounded-xl transition shadow-xs shrink-0 flex items-center gap-1.5 cursor-pointer"
                >
                  <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                    <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                    <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                    <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
                    <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
                  </svg>
                  <span>Google Fill</span>
                </button>
              </div>
            ) : (
              <div className="mt-4 p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs text-emerald-900">
                <span className="flex items-center gap-1.5 font-bold">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  <span>Verified Buyer: {user.email}</span>
                </span>
                <span className="text-[10px] font-mono bg-emerald-200/80 px-2 py-0.5 rounded font-bold">Auto-Verified</span>
              </div>
            )}

            {/* Buyer Form */}
            <form onSubmit={handleProceedToPaymentModes} className="mt-4 space-y-3.5">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Full Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => {
                    setFullName(e.target.value);
                    if (nameError) setNameError('');
                  }}
                  placeholder="Enter your full name"
                  className="w-full bg-white border border-slate-300 rounded-xl px-4 py-2.5 text-slate-900 focus:outline-none focus:border-blue-600 text-sm shadow-xs"
                />
                {nameError && (
                  <p className="text-[11px] text-rose-600 mt-1 font-medium">{nameError}</p>
                )}
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Email Address (For PDF Delivery) <span className="text-rose-500">*</span>
                </label>
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    if (emailError) setEmailError('');
                  }}
                  placeholder="you@gmail.com"
                  className={`w-full bg-white border rounded-xl px-4 py-2.5 text-slate-900 focus:outline-none text-sm shadow-xs ${
                    emailError ? 'border-rose-400 focus:border-rose-600 bg-rose-50/20' : 'border-slate-300 focus:border-blue-600'
                  }`}
                />
                {emailError ? (
                  <p className="text-[11px] text-rose-600 mt-1 font-semibold flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                    <span>{emailError}</span>
                  </p>
                ) : (
                  <p className="text-[11px] text-slate-400 mt-1">
                    * Your downloadable PDF and payment receipt will be delivered here.
                  </p>
                )}
              </div>

              <button
                type="submit"
                id="submit-details-btn"
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3.5 rounded-xl transition shadow-lg shadow-blue-600/30 text-base mt-2 flex items-center justify-center gap-2 cursor-pointer active:scale-95"
              >
                <span>Select Payment Method ({formatPrice(finalPriceINR)})</span>
                <ArrowRight className="w-4 h-4 ml-0.5" />
              </button>

              <div className="flex items-center justify-center gap-3 text-[11px] text-slate-400 text-center pt-1">
                <span>🔒 256-Bit SSL Encrypted</span>
                <span>•</span>
                <span>Instant Digital PDF Delivery</span>
              </div>
            </form>
          </>
        )}

        {/* STEP 2: CHOOSE PAYMENT METHOD & PAY (UPI, CARD, NET BANKING, RAZORPAY) */}
        {step === 'payment' && (
          <div className="space-y-4 animate-fadeIn">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <button
                type="button"
                onClick={() => setStep('details')}
                className="text-xs text-slate-500 hover:text-slate-900 font-semibold flex items-center gap-1 cursor-pointer"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Back to Details</span>
              </button>
              <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-full">
                Total: {formatPrice(finalPriceINR)}
              </span>
            </div>

            <div>
              <h3 className="text-xl font-extrabold text-slate-900">
                Choose Payment Mode
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Pay securely using UPI, Debit/Credit Card, Net Banking, or Online Gateway.
              </p>
            </div>

            {/* Payment Mode Selector Tabs */}
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2 pt-1">
              {/* UPI Tab */}
              <button
                type="button"
                onClick={() => setSelectedMethod('upi')}
                className={`p-3 rounded-2xl border text-left transition cursor-pointer flex flex-col justify-between ${
                  selectedMethod === 'upi'
                    ? 'border-blue-600 bg-blue-50/80 text-blue-900 ring-2 ring-blue-500/20 shadow-xs'
                    : 'border-slate-200 hover:border-slate-300 text-slate-700 bg-white'
                }`}
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <QrCode className="w-4 h-4 text-blue-600" />
                  {selectedMethod === 'upi' && <Check className="w-3.5 h-3.5 text-blue-600 font-bold" />}
                </div>
                <div>
                  <span className="font-bold text-xs block">UPI / QR</span>
                  <span className="text-[10px] text-slate-400">GPay, PhonePe</span>
                </div>
              </button>

              {/* Card Tab */}
              <button
                type="button"
                onClick={() => setSelectedMethod('card')}
                className={`p-3 rounded-2xl border text-left transition cursor-pointer flex flex-col justify-between ${
                  selectedMethod === 'card'
                    ? 'border-blue-600 bg-blue-50/80 text-blue-900 ring-2 ring-blue-500/20 shadow-xs'
                    : 'border-slate-200 hover:border-slate-300 text-slate-700 bg-white'
                }`}
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <CreditCard className="w-4 h-4 text-emerald-600" />
                  {selectedMethod === 'card' && <Check className="w-3.5 h-3.5 text-blue-600 font-bold" />}
                </div>
                <div>
                  <span className="font-bold text-xs block">Cards</span>
                  <span className="text-[10px] text-slate-400">Visa, Master</span>
                </div>
              </button>

              {/* Net Banking Tab */}
              <button
                type="button"
                onClick={() => setSelectedMethod('netbanking')}
                className={`p-3 rounded-2xl border text-left transition cursor-pointer flex flex-col justify-between ${
                  selectedMethod === 'netbanking'
                    ? 'border-blue-600 bg-blue-50/80 text-blue-900 ring-2 ring-blue-500/20 shadow-xs'
                    : 'border-slate-200 hover:border-slate-300 text-slate-700 bg-white'
                }`}
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <Building className="w-4 h-4 text-purple-600" />
                  {selectedMethod === 'netbanking' && <Check className="w-3.5 h-3.5 text-blue-600 font-bold" />}
                </div>
                <div>
                  <span className="font-bold text-xs block">NetBanking</span>
                  <span className="text-[10px] text-slate-400">All Banks</span>
                </div>
              </button>

              {/* Razorpay Gateway Tab (Available as fast alternative) */}
              <button
                type="button"
                onClick={() => setSelectedMethod('razorpay')}
                className={`p-3 rounded-2xl border text-left transition cursor-pointer flex flex-col justify-between ${
                  selectedMethod === 'razorpay'
                    ? 'border-blue-600 bg-blue-50/80 text-blue-900 ring-2 ring-blue-500/20 shadow-xs'
                    : 'border-slate-200 hover:border-slate-300 text-slate-700 bg-white'
                }`}
              >
                <div className="flex items-center justify-between w-full mb-1">
                  <Zap className="w-4 h-4 text-amber-500" />
                  {selectedMethod === 'razorpay' && <Check className="w-3.5 h-3.5 text-blue-600 font-bold" />}
                </div>
                <div>
                  <span className="font-bold text-xs block">Razorpay</span>
                  <span className="text-[10px] text-slate-400">Fast Gateway</span>
                </div>
              </button>
            </div>

            {/* FORM CONTAINER FOR SELECTED METHOD */}
            <form onSubmit={handleExecutePayment} className="space-y-4 pt-1">
              {/* 1. UPI / QR CONTENT */}
              {selectedMethod === 'upi' && (
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-4 text-center">
                  <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                    <div className="bg-white p-2 rounded-xl border border-slate-200 shadow-2xs">
                      <img
                        src={qrCodeUrl}
                        alt="UPI Payment QR Code"
                        className="w-32 h-32 mx-auto rounded-lg"
                        loading="eager"
                      />
                    </div>
                    <div className="text-left space-y-1.5 flex-1">
                      <span className="text-[11px] font-bold text-blue-600 uppercase tracking-wider block">
                        Scan to Pay with Any UPI App
                      </span>
                      <p className="text-xs text-slate-600">
                        Scan with <strong>Google Pay</strong>, <strong>PhonePe</strong>, <strong>Paytm</strong>, or BHIM.
                      </p>
                      
                      {/* Merchant UPI Box */}
                      <div className="mt-2 bg-white border border-slate-200 rounded-xl p-2 flex items-center justify-between">
                        <span className="font-mono text-xs text-slate-800 font-semibold truncate mr-2">
                          {merchantUpiId}
                        </span>
                        <button
                          type="button"
                          onClick={handleCopyUpi}
                          className="text-[11px] font-bold text-blue-600 bg-blue-50 hover:bg-blue-100 px-2 py-1 rounded-md transition flex items-center gap-1 cursor-pointer shrink-0"
                        >
                          {copiedUpi ? <Check className="w-3 h-3 text-emerald-600" /> : <Copy className="w-3 h-3" />}
                          <span>{copiedUpi ? 'Copied' : 'Copy'}</span>
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Or Enter Personal UPI ID */}
                  <div className="pt-2 border-t border-slate-200 text-left">
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      Or Pay via your UPI ID (Optional):
                    </label>
                    <div className="relative">
                      <Smartphone className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={customerUpiId}
                        onChange={(e) => setCustomerUpiId(e.target.value)}
                        placeholder="yourname@okaxis, yourname@upi"
                        className="w-full pl-9 pr-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-mono focus:outline-none focus:border-blue-600"
                      />
                    </div>
                  </div>
                </div>
              )}

              {/* 2. CARD PAYMENT CONTENT */}
              {selectedMethod === 'card' && (
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3 text-left">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Card Number
                    </label>
                    <div className="relative">
                      <CreditCard className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        required
                        value={cardNumber}
                        onChange={handleCardNumberChange}
                        placeholder="4532 1234 5678 9012"
                        className="w-full pl-9 pr-3 py-2.5 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm font-mono focus:outline-none focus:border-blue-600 shadow-2xs"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        Expiry Date
                      </label>
                      <input
                        type="text"
                        required
                        value={cardExpiry}
                        onChange={handleExpiryChange}
                        placeholder="MM/YY"
                        className="w-full px-3 py-2.5 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm font-mono focus:outline-none focus:border-blue-600 shadow-2xs"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-slate-700 mb-1">
                        CVV / CVC
                      </label>
                      <input
                        type="password"
                        required
                        maxLength={4}
                        value={cardCvv}
                        onChange={(e) => setCardCvv(e.target.value.replace(/\D/g, ''))}
                        placeholder="•••"
                        className="w-full px-3 py-2.5 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm font-mono focus:outline-none focus:border-blue-600 shadow-2xs"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      Cardholder Name
                    </label>
                    <input
                      type="text"
                      value={cardHolder || fullName}
                      onChange={(e) => setCardHolder(e.target.value)}
                      placeholder="Name as printed on card"
                      className="w-full px-3 py-2.5 bg-white border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:border-blue-600 shadow-2xs"
                    />
                  </div>

                  {cardError && (
                    <p className="text-[11px] text-rose-600 font-semibold">{cardError}</p>
                  )}
                </div>
              )}

              {/* 3. NET BANKING CONTENT */}
              {selectedMethod === 'netbanking' && (
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3 text-left">
                  <span className="text-xs font-bold text-slate-700 block">
                    Select Your Bank:
                  </span>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {popularBanks.map((b) => (
                      <button
                        key={b.id}
                        type="button"
                        onClick={() => setSelectedBank(b.id)}
                        className={`p-2.5 rounded-xl border text-xs font-semibold text-center transition cursor-pointer ${
                          selectedBank === b.id
                            ? 'border-blue-600 bg-white text-blue-700 ring-2 ring-blue-500/20 font-bold shadow-2xs'
                            : 'border-slate-200 bg-white/70 hover:bg-white text-slate-600'
                        }`}
                      >
                        {b.name}
                      </button>
                    ))}
                  </div>

                  <div className="pt-2">
                    <label className="block text-[11px] font-bold text-slate-600 mb-1">
                      Or Select from All Other Banks:
                    </label>
                    <select
                      value={selectedBank}
                      onChange={(e) => setSelectedBank(e.target.value)}
                      className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:border-blue-600"
                    >
                      <option value="HDFC">HDFC Bank</option>
                      <option value="SBI">State Bank of India (SBI)</option>
                      <option value="ICICI">ICICI Bank</option>
                      <option value="AXIS">Axis Bank</option>
                      <option value="KOTAK">Kotak Mahindra Bank</option>
                      <option value="PNB">Punjab National Bank</option>
                      <option value="BOB">Bank of Baroda</option>
                      <option value="CANARA">Canara Bank</option>
                      <option value="INDUSIND">IndusInd Bank</option>
                      <option value="YES">Yes Bank</option>
                      <option value="IDFC">IDFC FIRST Bank</option>
                      <option value="UNION">Union Bank of India</option>
                    </select>
                  </div>
                </div>
              )}

              {/* 4. RAZORPAY GATEWAY CONTENT */}
              {selectedMethod === 'razorpay' && (
                <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-left space-y-2.5">
                  <div className="flex items-center gap-2">
                    <Zap className="w-5 h-5 text-amber-500" />
                    <div>
                      <span className="font-bold text-slate-900 text-sm block">Razorpay Direct Gateway</span>
                      <span className="text-[11px] text-slate-500">Pay via UPI, Cards, NetBanking, or Wallets</span>
                    </div>
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    Clicking pay will process your order and launch the Razorpay secure gateway window for instant verification.
                  </p>
                </div>
              )}

              {/* Processing Overlay / Indicator */}
              {isProcessing && (
                <div className="bg-blue-50 border border-blue-200 rounded-2xl p-3.5 text-center space-y-1.5 animate-pulse">
                  <div className="flex items-center justify-center gap-2 text-blue-700 text-xs font-bold">
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>{processingStatus}</span>
                  </div>
                </div>
              )}

              {/* Submit Payment Button */}
              <button
                type="submit"
                disabled={isProcessing}
                className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3.5 rounded-xl transition shadow-lg shadow-emerald-600/30 text-base flex items-center justify-center gap-2 cursor-pointer disabled:opacity-70 active:scale-95"
              >
                <ShieldCheck className="w-5 h-5" />
                <span>
                  {isProcessing ? 'Verifying & Processing...' : `Pay ${formatPrice(finalPriceINR)} & Unlock PDF`}
                </span>
              </button>

              <div className="flex items-center justify-center gap-3 text-[11px] text-slate-400 text-center pt-0.5">
                <span>🔒 PCI-DSS Compliant</span>
                <span>•</span>
                <span>Licensed to {email}</span>
              </div>
            </form>
          </div>
        )}

        {/* STEP 3: ORDER COMPLETE & STRICT SINGLE PRODUCT DOWNLOAD */}
        {step === 'complete' && orderComplete && (
          <div className="space-y-5 animate-fadeIn text-center">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-1">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            <div>
              <span className="text-xs font-mono font-bold text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full">
                Order #{orderComplete.orderId} • Payment Verified
              </span>
              <h3 className="text-2xl font-black text-slate-900 mt-2">
                Access Licensed &amp; Ready!
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Your digital toolkit has been licensed for <span className="font-semibold text-slate-800">{orderComplete.customerEmail}</span>
              </p>
            </div>

            {/* Email Dispatch Info Box */}
            <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 text-left space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 mt-0.5 shadow-sm">
                  <Mail className="w-4 h-4" />
                </div>
                <div className="text-xs flex-1">
                  <div className="font-bold text-blue-950 flex items-center gap-1.5">
                    <span>Order Receipt &amp; Permanent Download Link</span>
                    <span className="bg-emerald-100 text-emerald-700 text-[10px] font-extrabold px-1.5 py-0.5 rounded">
                      Active
                    </span>
                  </div>
                  <p className="text-blue-800/80 mt-0.5 text-[11px] leading-relaxed">
                    {emailStatusMessage || `Licensed to ${orderComplete.customerEmail}. Click below to receive or open your full invoice and download link:`}
                  </p>
                </div>
              </div>

              {/* Email Receipt Actions */}
              <div className="flex flex-col sm:flex-row gap-2 pt-1 border-t border-blue-200/60">
                <a
                  href={getGmailUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs py-2 px-3 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer shadow-xs text-center"
                >
                  <Mail className="w-3.5 h-3.5" />
                  <span>Open Delivery in Gmail</span>
                  <ExternalLink className="w-3 h-3 opacity-80" />
                </a>
                <button
                  type="button"
                  onClick={handleCopyReceipt}
                  className="bg-white border border-blue-300 hover:bg-blue-50 text-blue-900 font-semibold text-xs py-2 px-3 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  {emailCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{emailCopied ? 'Receipt Copied!' : 'Copy Receipt Text'}</span>
                </button>
              </div>
            </div>

            {/* STRICT SINGLE PDF DELIVERABLE BOX */}
            <div className="text-left bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2.5">
              <div className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2 flex items-center justify-between">
                <span>Your Specific Purchased Product PDF:</span>
                <span className="text-emerald-600 font-extrabold text-[11px] flex items-center gap-1">
                  <Check className="w-3 h-3" />
                  <span>1 Single Deliverable</span>
                </span>
              </div>

              {/* Exactly 1 Single Item Download */}
              <div className="bg-white p-4 rounded-xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-xs">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-rose-50 border border-rose-200 flex items-center justify-center text-rose-600 font-bold text-xs shrink-0">
                    PDF
                  </div>
                  <div>
                    <div className="text-sm font-bold text-slate-900">
                      {'pdfFileName' in item && item.pdfFileName
                        ? item.pdfFileName
                        : `${item.title.replace(/\s+/g, '_')}_Official_Guide.pdf`}
                    </div>
                    <div className="text-[11px] text-slate-500">
                      Product: {item.title} • Paid via {selectedMethod.toUpperCase()}
                    </div>
                  </div>
                </div>

                <button
                  onClick={handleDownloadSinglePdf}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-4 py-2.5 rounded-xl flex items-center justify-center gap-1.5 transition shrink-0 cursor-pointer shadow-md shadow-emerald-600/20 active:scale-95"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Product PDF</span>
                </button>
              </div>

              {!('pdfUrl' in item && item.pdfUrl) && (
                <p className="text-[11px] text-slate-400 italic">
                  Note: A certified digital delivery PDF has been generated and unlocked for your order.
                </p>
              )}
            </div>

            {/* Permanent Access / Done */}
            <div className="flex gap-2 pt-1">
              <button
                onClick={handleCopyPortalLink}
                className="flex-1 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 text-xs font-semibold py-2.5 rounded-xl transition flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {portalCopied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                <span>{portalCopied ? 'Link Copied!' : 'Copy Permanent Download Link'}</span>
              </button>
              <button
                onClick={onClose}
                className="flex-1 bg-slate-900 hover:bg-black text-white text-xs font-semibold py-2.5 rounded-xl transition cursor-pointer"
              >
                Done
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
