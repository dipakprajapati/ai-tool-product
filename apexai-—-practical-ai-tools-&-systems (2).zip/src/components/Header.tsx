import React, { useState } from 'react';
import {
  Menu,
  X,
  ShoppingBag,
  ArrowRight,
  Sparkles,
  Download,
  PackageCheck,
  User as UserIcon,
} from 'lucide-react';
import { useFirebase } from '../firebase/context';

interface HeaderProps {
  onExploreClick: () => void;
  onNavigateHome?: () => void;
  onNavigateBlog?: () => void;
  onOpenLibrary?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onExploreClick,
  onNavigateHome,
  onNavigateBlog,
  onOpenLibrary,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { orders, purchasedProductIds, user, signInWithGoogle } = useFirebase();
  const purchasesCount = orders.length || purchasedProductIds.length;

  const handleHomeClick = (e: React.MouseEvent) => {
    e.preventDefault();
    if (onNavigateHome) onNavigateHome();
    else {
      window.location.hash = '';
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleBlogClick = (e: React.MouseEvent) => {
    e.preventDefault();
    if (onNavigateBlog) onNavigateBlog();
    else {
      window.location.hash = '#blog';
      const el = document.getElementById('blog');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <>
      {/* TOP ANNOUNCEMENT BAR */}
      <div id="announcement-bar" className="bg-blue-600 text-white text-xs py-2.5 text-center font-medium px-4 tracking-wide relative z-50">
        <div className="max-w-7xl mx-auto flex items-center justify-center gap-2 flex-wrap">
          <span className="inline-flex items-center gap-1 font-semibold">
            🚀 Special Launch Offer:
          </span>
          <span>
            Get up to 60% off on all{' '}
            <a
              href="#bundles"
              className="underline font-bold hover:text-blue-100 transition-colors inline-flex items-center gap-0.5"
            >
              Complete AI Bundles
              <ArrowRight className="w-3 h-3 inline" />
            </a>{' '}
            today! Use code <span className="bg-blue-700 px-1.5 py-0.5 rounded font-mono font-bold">LAUNCH60</span>
          </span>
        </div>
      </div>

      {/* HEADER / NAVIGATION */}
      <header id="main-header" className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <a
            href="#"
            id="brand-logo-link"
            onClick={handleHomeClick}
            className="text-xl font-extrabold tracking-tight text-[#0F172A] flex items-center gap-2.5 group cursor-pointer"
          >
            <span className="w-9 h-9 bg-blue-600 text-white rounded-xl flex items-center justify-center text-sm font-black shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform">
              AI
            </span>
            <span className="flex flex-col">
              <span className="leading-tight text-lg font-black tracking-tight text-slate-900">
                Apex<span className="text-blue-600">AI</span>
              </span>
              <span className="text-[10px] text-slate-400 font-semibold tracking-wider uppercase">
                Systems &amp; Workkits
              </span>
            </span>
          </a>

          {/* Desktop Navigation */}
          <nav id="desktop-nav" className="hidden lg:flex items-center space-x-7 text-sm font-medium text-slate-600">
            <a
              href="#home"
              onClick={handleHomeClick}
              className="text-blue-600 font-semibold transition hover:text-blue-700 cursor-pointer"
            >
              Home
            </a>
            <a href="#shop" className="hover:text-blue-600 transition flex items-center gap-1.5">
              <span>Shop</span>
              <span className="bg-blue-50 text-blue-700 text-[11px] font-bold px-2 py-0.5 rounded-full border border-blue-100">
                50+ Products
              </span>
            </a>
            <a href="#bundles" className="hover:text-blue-600 transition">
              Bundles
            </a>
            <a href="#free-resources" className="hover:text-blue-600 transition">
              Free Resources
            </a>
            <a href="#how-it-works" className="hover:text-blue-600 transition">
              How It Works
            </a>
            <a
              href="#blog"
              onClick={handleBlogClick}
              className="hover:text-blue-600 transition cursor-pointer"
            >
              Blog &amp; Guides
            </a>
            <a href="#faq" className="hover:text-blue-600 transition">
              FAQ
            </a>
          </nav>

          {/* Right Action Controls (Clean Customer View) */}
          <div className="hidden md:flex items-center space-x-2.5">
            {/* Show My Downloads ONLY if user is signed in */}
            {user && onOpenLibrary && (
              <button
                type="button"
                onClick={onOpenLibrary}
                id="header-my-downloads-btn"
                className="bg-slate-100 hover:bg-slate-200/90 text-slate-700 px-3 py-2 rounded-xl text-xs font-semibold transition flex items-center gap-1.5 border border-slate-200/80 cursor-pointer shadow-2xs"
                title="View your purchased digital downloads"
              >
                <Download className="w-3.5 h-3.5 text-emerald-600" />
                <span>My Downloads</span>
                {purchasesCount > 0 && (
                  <span className="bg-emerald-600 text-white text-[10px] font-bold px-1.5 py-0.2 rounded-full">
                    {purchasesCount}
                  </span>
                )}
              </button>
            )}

            {user ? (
              <button
                type="button"
                onClick={onOpenLibrary}
                className="flex items-center gap-2 pl-2 pr-2.5 py-1.5 rounded-xl bg-slate-50 border border-slate-200/80 text-xs text-slate-700 hover:bg-slate-100 transition cursor-pointer"
                title={`Signed in as ${user.email}`}
              >
                {user.photoURL ? (
                  <img src={user.photoURL} alt="" className="w-5 h-5 rounded-full object-cover" />
                ) : (
                  <div className="w-5 h-5 rounded-full bg-blue-100 text-blue-700 font-bold text-[10px] flex items-center justify-center">
                    {(user.displayName || user.email || 'U')[0].toUpperCase()}
                  </div>
                )}
                <span className="font-semibold max-w-[80px] truncate text-slate-800">
                  {user.displayName?.split(' ')[0] || 'Account'}
                </span>
              </button>
            ) : (
              <button
                type="button"
                onClick={signInWithGoogle}
                className="text-xs font-semibold text-slate-600 hover:text-slate-900 px-2.5 py-2 rounded-xl hover:bg-slate-100 transition flex items-center gap-1.5 cursor-pointer border border-transparent hover:border-slate-200"
                title="Sign in with Google"
              >
                <UserIcon className="w-3.5 h-3.5 text-slate-500" />
                <span>Sign In</span>
              </button>
            )}

            <a
              href="#shop"
              id="header-explore-btn"
              onClick={onExploreClick}
              className="bg-blue-600 hover:bg-blue-700 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition shadow-xs shadow-blue-500/20 flex items-center gap-1.5 active:scale-95 cursor-pointer"
            >
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>Explore Products</span>
            </a>
          </div>

          {/* Mobile Menu Button & Top Action */}
          <div className="flex items-center gap-2 md:hidden">
            {/* Show Downloads ONLY if logged in */}
            {user && onOpenLibrary && (
              <button
                type="button"
                onClick={onOpenLibrary}
                className="text-xs font-bold px-2.5 py-1.5 bg-slate-100 text-slate-800 rounded-lg flex items-center gap-1"
                title="My Downloads"
              >
                <Download className="w-3.5 h-3.5 text-emerald-600" />
                <span>Downloads</span>
                {purchasesCount > 0 && (
                  <span className="bg-emerald-600 text-white text-[9px] px-1 rounded-full">
                    {purchasesCount}
                  </span>
                )}
              </button>
            )}
            {!user && (
              <button
                type="button"
                onClick={signInWithGoogle}
                className="text-xs font-semibold px-2.5 py-1.5 bg-slate-100 text-slate-700 rounded-lg flex items-center gap-1"
                title="Sign in with Google"
              >
                <UserIcon className="w-3.5 h-3.5 text-slate-500" />
                <span>Sign In</span>
              </button>
            )}
            <a
              href="#shop"
              onClick={onExploreClick}
              className="text-xs font-bold px-3 py-1.5 bg-blue-600 text-white rounded-lg shadow-2xs"
            >
              Shop
            </a>
            <button
              id="mobile-menu-btn"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-700 rounded-lg hover:bg-slate-100 focus:outline-none transition cursor-pointer"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu Dropdown */}
        {mobileMenuOpen && (
          <div
            id="mobile-menu"
            className="md:hidden bg-white border-b border-slate-200 px-6 py-5 space-y-3.5 shadow-lg animate-fadeIn"
          >
            <a
              href="#home"
              onClick={(e) => {
                setMobileMenuOpen(false);
                handleHomeClick(e);
              }}
              className="block text-slate-900 font-semibold py-1.5 hover:text-blue-600"
            >
              Home
            </a>
            <a
              href="#shop"
              onClick={() => setMobileMenuOpen(false)}
              className="block text-slate-700 py-1.5 hover:text-blue-600 flex items-center justify-between"
            >
              <span>Shop All Products</span>
              <span className="bg-blue-50 text-blue-700 text-xs font-bold px-2 py-0.5 rounded-full">
                50+
              </span>
            </a>
            <a
              href="#bundles"
              onClick={() => setMobileMenuOpen(false)}
              className="block text-slate-700 py-1.5 hover:text-blue-600"
            >
              Complete AI Bundles
            </a>
            <a
              href="#free-resources"
              onClick={() => setMobileMenuOpen(false)}
              className="block text-slate-700 py-1.5 hover:text-blue-600"
            >
              Free 50 Prompts Guide
            </a>
            <a
              href="#how-it-works"
              onClick={() => setMobileMenuOpen(false)}
              className="block text-slate-700 py-1.5 hover:text-blue-600"
            >
              How It Works
            </a>
            <a
              href="#blog"
              onClick={(e) => {
                setMobileMenuOpen(false);
                handleBlogClick(e);
              }}
              className="block text-slate-700 py-1.5 hover:text-blue-600"
            >
              Articles &amp; Guides
            </a>
            <a
              href="#faq"
              onClick={() => setMobileMenuOpen(false)}
              className="block text-slate-700 py-1.5 hover:text-blue-600"
            >
              FAQ
            </a>

            {/* ONLY SHOW "My Downloads" IN MENU IF USER IS LOGGED IN */}
            {user && onOpenLibrary && (
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  onOpenLibrary();
                }}
                className="w-full text-left font-semibold text-emerald-600 py-1.5 hover:text-emerald-700 flex items-center justify-between"
              >
                <span className="flex items-center gap-2">
                  <Download className="w-4 h-4" />
                  <span>My Downloads ({purchasesCount})</span>
                </span>
                <span className="bg-emerald-50 text-emerald-700 text-xs font-bold px-2 py-0.5 rounded-full">
                  Purchased
                </span>
              </button>
            )}

            {!user && (
              <button
                type="button"
                onClick={() => {
                  setMobileMenuOpen(false);
                  signInWithGoogle();
                }}
                className="w-full text-left font-semibold text-slate-700 py-1.5 hover:text-blue-600 flex items-center gap-2"
              >
                <UserIcon className="w-4 h-4 text-slate-500" />
                <span>Sign In with Google</span>
              </button>
            )}

            <div className="pt-3 border-t border-slate-100 flex flex-col gap-2.5">
              <a
                href="#shop"
                onClick={() => {
                  setMobileMenuOpen(false);
                  onExploreClick();
                }}
                className="bg-blue-600 text-white py-2.5 rounded-xl text-center font-semibold text-sm shadow-sm"
              >
                Browse All 50+ Toolkits
              </a>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
