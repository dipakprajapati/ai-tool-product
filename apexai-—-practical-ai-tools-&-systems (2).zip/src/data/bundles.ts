import { Bundle } from '../types';

export const BUNDLES_DATA: Bundle[] = [
  {
    id: 'bundle-side-hustle',
    slug: 'ai-side-hustle-starter-bundle',
    title: 'AI Side Hustle Starter Bundle',
    subtitle: 'For beginners who want to explore practical AI-based income opportunities without guesswork.',
    badge: 'POPULAR BUNDLE',
    badgeType: 'popular',
    priceINR: 2999,
    originalPriceINR: 6999,
    savingsPercent: 57,
    imageUrl: 'https://images.unsplash.com/photo-1553729459-efe14ef6055d?auto=format&fit=crop&w=1200&q=80',
    fullDescription: 'The ultimate beginner-to-intermediate ecosystem for launching income-generating AI micro-businesses. You get battle-tested frameworks, step-by-step SOPs, client acquisition scripts, and pre-built templates to earn your first ₹50,000 to ₹1,00,000 using modern AI tools.',
    features: [
      '6 Complete Digital Toolkits & Execution Playbooks',
      '50 Proven AI Income Streams & Step-by-Step Roadmaps',
      'ChatGPT Prompt Mega Pack (500+ Prompts) Included',
      'AI Freelancing Starter Kit + Legal Contract Templates',
      'AI Digital Products Playbook with Canva Templates',
      'Lifetime Access & All Future Quarterly Updates'
    ],
    includedProducts: [
      'AI Freelancing Starter Kit (Worth ₹999)',
      'AI Digital Products Playbook (Worth ₹1,299)',
      'ChatGPT Prompt Mega Pack (Worth ₹899)',
      'AI Viral Short-Form Video Vault (Worth ₹1,499)',
      'Personal AI Chief of Staff (Worth ₹1,199)',
      'Midjourney & Image AI Design Suite (Worth ₹1,100)'
    ],
    deliverables: [
      'Master Side-Hustle Blueprint PDF (120+ pages)',
      'Notion Digital Command Center & Income Tracker',
      '500+ Copy-Paste GPT-4o & Claude Prompts',
      'Ready-to-Use Client Contracts & Proposal Decks',
      'Canva Mockup & Digital Asset Templates'
    ],
    curriculum: [
      {
        title: 'Module 1: The 2026 AI Income Landscape',
        duration: '2 Hours Reading & Setup',
        description: 'Discover the highest margin AI business models: prompt engineering consulting, automated content curation, and micro-agency retainers.'
      },
      {
        title: 'Module 2: Launching Digital Products & Playbooks',
        duration: '3 Hours Implementation',
        description: 'How to research, package, and sell high-demand digital toolkits on Gumroad, Notion, and Indian UPI storefronts.'
      },
      {
        title: 'Module 3: High-Ticket AI Freelancing',
        duration: '4 Hours Step-by-Step',
        description: 'Outbound outreach, Upwork proposals, client contract protection, and delivering 10x value using automated workflows.'
      },
      {
        title: 'Module 4: Scaling to ₹1,00,000/Month',
        duration: 'Ongoing Framework',
        description: 'Standard Operating Procedures (SOPs) to delegate, automate client deliverables, and build recurring monthly retainers.'
      }
    ],
    targetAudience: [
      'College students & graduates looking for independent internet revenue',
      'Working professionals seeking reliable ₹30k - ₹75k weekend side income',
      'Freelancers wanting to offer high-paying AI services to global clients',
      'Digital creators launching their first paid digital downloads'
    ],
    bonuses: [
      {
        title: 'Client Outreach Email Scripts',
        valueINR: 1999,
        description: '15 copy-paste cold email templates with proven 34% response rates from Indian and international business owners.'
      },
      {
        title: 'Notion Second Brain Side-Hustle Tracker',
        valueINR: 1499,
        description: 'Pre-configured Notion workspace with client CRM, invoice templates, and prompt library manager.'
      },
      {
        title: 'Private Founder Telegram Circle Access',
        valueINR: 2499,
        description: 'Direct access to Dipak Prajapati and fellow AI builders sharing live opportunities and feedback.'
      }
    ],
    faqs: [
      {
        question: 'How soon can I expect results after getting this bundle?',
        answer: 'Most members implement Module 1 & 2 within their first weekend. Depending on your dedication, students land their first client or launch their digital product in 14-21 days.'
      },
      {
        question: 'Do I need paid subscriptions to ChatGPT Plus or Midjourney?',
        answer: 'No. All blueprints include options for free tools (Claude Free, ChatGPT Free, Google Gemini, and open-source alternatives).'
      },
      {
        question: 'How do I download the files after purchase?',
        answer: 'You will receive immediate 1-click download access on your checkout screen and an automated email containing permanent cloud links to all PDFs, Notion templates, and bonus vaults.'
      }
    ]
  },
  {
    id: 'bundle-business-automation',
    slug: 'ai-business-automation-bundle',
    title: 'AI Business Automation Bundle',
    subtitle: 'For freelancers, agencies, and businesses that want to use AI to automate repetitive work and capture leads.',
    badge: 'BUSINESS ESSENTIAL',
    badgeType: 'business',
    priceINR: 3999,
    originalPriceINR: 8999,
    savingsPercent: 56,
    imageUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=1200&q=80',
    fullDescription: 'An enterprise-grade automation arsenal designed for small business owners, operators, and agency founders. Replace 40+ hours of tedious weekly manual work with self-operating AI bots, WhatsApp auto-responders, lead enrichment pipelines, and CRM synchronizations.',
    features: [
      'AI Chatbot Agency Mastery Course & Pitch Decks',
      'AI WhatsApp Sales Bot Kit (1-Click Make.com Blueprints)',
      'AI Lead Generation & Outbound Prospecting Engine',
      'Ready-to-Deploy Customer Support & Booking Workflows',
      'Client Service Agreements & High-Ticket Pricing Matrix',
      'Lifetime Access, Direct Setup Support & Video Guides'
    ],
    includedProducts: [
      'AI WhatsApp Sales Bot Kit (Worth ₹1,499)',
      'AI Chatbot Agency Mastery (Worth ₹1,999)',
      'AI Automation Workflow Templates (Worth ₹1,299)',
      'AI Lead Generation Kit (Worth ₹1,499)',
      'AI Proposal & Closing Mastery Pack (Worth ₹1,299)',
      'Make & Zapier JSON Scenario Vault (Worth ₹1,404)'
    ],
    deliverables: [
      '15+ JSON Import-Ready Make.com & Zapier Automation Scenarios',
      'AI WhatsApp & Web Chatbot Architecture Blueprint PDF',
      'Lead Scraping & Enrichment Python Scripts + Airtable Bases',
      'Agency Retainer Contracts & NDA Agreements',
      'Step-by-Step Video Setup Walkthroughs & Documentation'
    ],
    curriculum: [
      {
        title: 'Module 1: Visual Automation Fundamentals',
        duration: '90 Minutes',
        description: 'Connecting Make.com, Webhooks, OpenAI API, and Google Sheets without typing a single line of backend code.'
      },
      {
        title: 'Module 2: The 24/7 AI WhatsApp Sales Agent',
        duration: '3 Hours',
        description: 'Building an intelligent bot that answers queries, quotes prices, qualifies leads, and books meetings into Google Calendar.'
      },
      {
        title: 'Module 3: Autonomous Inbound & Outbound Lead Systems',
        duration: '2.5 Hours',
        description: 'Scraping target B2B companies, enriching decision-maker emails, and generating hyper-personalized email drafts using AI.'
      },
      {
        title: 'Module 4: Selling AI Automation to Businesses',
        duration: '2 Hours',
        description: 'How to pitch local businesses and agencies on a ₹25,000 setup fee + ₹10,000/month maintenance retainer.'
      }
    ],
    targetAudience: [
      'Agency owners wanting to cut labor costs and automate client delivery',
      'E-commerce & retail founders needing instant WhatsApp customer support',
      'B2B consultants, coaches, and service providers looking for automated booking',
      'Tech-savvy freelancers building an AI automation agency (AAA)'
    ],
    bonuses: [
      {
        title: 'Ready-to-Use Client Pitch Decks',
        valueINR: 2499,
        description: 'Editable Figma and PowerPoint pitch presentations tested to close ₹50,000 automation contracts.'
      },
      {
        title: 'Commercial Client Service Agreement Template',
        valueINR: 2999,
        description: 'Legally vetted service contract protecting your IP, scope of work, and monthly retainer fees.'
      },
      {
        title: '1-on-1 Implementation Review Voucher',
        valueINR: 3500,
        description: 'Direct asynchronous architecture review by Founder Dipak Prajapati on your first client automation flow.'
      }
    ],
    faqs: [
      {
        question: 'Can I rebrand and sell these automations to my clients?',
        answer: 'Yes! The Commercial Implementation License grants 100% permission to deploy and sell these automated systems to paying clients under your own agency brand.'
      },
      {
        question: 'Does this require costly software or API keys?',
        answer: 'Make.com has a generous free tier (1,000 ops/month). OpenAI API costs for running these bots typically run under ₹200 to ₹500 per month for moderate usage.'
      },
      {
        question: 'What if I get stuck while importing the Make.com blueprints?',
        answer: 'Every blueprint includes detailed import instructions, screenshots, and sample environment variable values. Plus, email support is included.'
      }
    ]
  },
  {
    id: 'bundle-creator-powerpack',
    slug: 'ai-creator-and-content-powerpack',
    title: 'AI Creator & Content Powerpack',
    subtitle: 'Everything a solo creator, YouTuber, or marketer needs to produce 10x more high-retention content.',
    badge: 'CREATOR FAVORITE',
    badgeType: 'creator',
    priceINR: 1999,
    originalPriceINR: 4999,
    savingsPercent: 60,
    imageUrl: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&w=1200&q=80',
    fullDescription: 'The comprehensive production system for modern content creators. Master short-form video hooks, YouTube longform storytelling, SEO blog engines, and Midjourney thumbnail prompts to achieve omnipresence on Instagram Reels, YouTube, LinkedIn, and X.',
    features: [
      'AI Viral Short-Form Video Vault (100+ Tested Hooks)',
      'AI YouTube Studio OS with High-Retention Story Formulas',
      'AI Social Media Omnipresence Kit (1-to-15 Repurposing)',
      'Midjourney Visual Design Suite & Thumbnail Prompt Formulas',
      'SEO Content Engine & E-E-A-T Ranking Blueprints'
    ],
    includedProducts: [
      'AI Viral Short-Form Video Vault (Worth ₹1,499)',
      'AI YouTube Studio OS (Worth ₹1,299)',
      'AI Social Media Omnipresence Kit (Worth ₹999)',
      'Midjourney & Image AI Design Suite (Worth ₹1,100)',
      'AI SEO Content Engine (Worth ₹999)'
    ],
    deliverables: [
      'Viral Short-Form Script Writing Notion System',
      '100+ High-Retention Hook Formulas (with examples)',
      'YouTube Title & Thumbnail Generator Prompt Matrix',
      '1-to-15 Video Repurposing Workflow (Reels, Carousels, Tweets)',
      'Midjourney Photorealistic Image Prompt Catalog'
    ],
    curriculum: [
      {
        title: 'Module 1: The 3-Second Retention Hook Formula',
        duration: '60 Minutes',
        description: 'Analyzing psychological patterns that stop users from scrolling on Instagram Reels and YouTube Shorts.'
      },
      {
        title: 'Module 2: High-Velocity AI Scriptwriting',
        duration: '90 Minutes',
        description: 'Using custom GPTs to outline, draft, and polish punchy 60-second video scripts in under 5 minutes.'
      },
      {
        title: 'Module 3: Studio Branding & Midjourney Thumbnails',
        duration: '2 Hours',
        description: 'Crafting cinematic facial expressions, neon lighting, and high-CTR thumbnail assets without hiring a designer.'
      }
    ],
    targetAudience: [
      'Solo creators wanting to publish daily Reels and Shorts without burnout',
      'YouTubers looking to double their click-through rate and audience retention',
      'Social media managers handling multiple brand accounts',
      'Founders building their personal brand on LinkedIn and Twitter'
    ],
    bonuses: [
      {
        title: '50 Cinematic Lighting Midjourney Prompts',
        valueINR: 1299,
        description: 'Ready-to-use prompt recipes for generating high-end studio quality portraits and product renders.'
      },
      {
        title: 'YouTube Metadata & Tag Optimization Cheat Sheet',
        valueINR: 999,
        description: 'Step-by-step checklist to maximize algorithm discovery on YouTube search and recommended feeds.'
      }
    ],
    faqs: [
      {
        question: 'Does this help with Hindi and regional content creation?',
        answer: 'Yes! The prompts and storytelling structures work seamlessly across English, Hindi, and regional languages.'
      },
      {
        question: 'Can I use these prompts with ChatGPT 3.5 or free models?',
        answer: 'Yes, all prompts are engineered to work with free AI chatbots, although GPT-4o and Claude 3.5 Sonnet provide the most nuanced output.'
      }
    ]
  },
  {
    id: 'bundle-ultimate-empire',
    slug: 'ultimate-ai-digital-empire-all-access',
    title: 'Ultimate AI Digital Empire All-Access',
    subtitle: 'The full ApexAI digital vault — every single current product, blueprint, prompt system, and all future releases.',
    badge: 'MAXIMUM VALUE',
    badgeType: 'ultimate',
    priceINR: 5999,
    originalPriceINR: 14999,
    savingsPercent: 60,
    imageUrl: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&w=1200&q=80',
    fullDescription: 'The holy grail of AI digital products. You receive unlocked, unrestricted access to EVERY single digital toolkit in the ApexAI library — including the Business Automation Bundle, Side Hustle Bundle, Creator Powerpack, all future product releases, and private founder community access.',
    features: [
      'Access to ALL 50+ Current & Upcoming Digital Products',
      'Both Business Automation & Side Hustle Bundles Included',
      'All Notion Second Brain Systems & Workflow Blueprints',
      'Private Discord / Telegram Community & Monthly Q&A',
      'VIP Priority Support & Full Commercial Usage License',
      'Permanent Lifetime Access with Zero Subscription Fees'
    ],
    includedProducts: [
      'AI Business Automation Bundle (Worth ₹8,999)',
      'AI Side Hustle Starter Bundle (Worth ₹6,999)',
      'AI Creator & Content Powerpack (Worth ₹4,999)',
      'Complete 18+ Individual Standalone Toolkits (Worth ₹18,000+)',
      'All Future 2026-2027 Product Drops & Playbooks'
    ],
    deliverables: [
      'Master ApexAI Empire Vault Access Key',
      'Over 500+ Pages of Digital Guides, Playbooks & PDFs',
      '25+ Importable Make.com, Zapier & n8n Scenarios',
      '1,500+ Master Prompt Architectures & Prompt Chains',
      'Complete Notion Enterprise Digital Workspace',
      'Lifetime Commercial Agency License'
    ],
    curriculum: [
      {
        title: 'Master Track 1: AI Agency & Business Automation',
        duration: '10+ Hours Content & Code',
        description: 'Deploying high-ticket automation workflows for clients, automating WhatsApp, CRMs, and email pipelines.'
      },
      {
        title: 'Master Track 2: Digital Asset Creation & Monetization',
        duration: '8 Hours',
        description: 'How to build, package, and market profitable digital products, prompt packs, and Notion systems.'
      },
      {
        title: 'Master Track 3: Content Omnipresence & Audience Building',
        duration: '6 Hours',
        description: 'Dominating YouTube, Instagram, and LinkedIn with high-retention video scripts and visual storytelling.'
      },
      {
        title: 'Master Track 4: The 2026 AI Entrepreneur Playbook',
        duration: 'Continuous Updates',
        description: 'Quarterly updates covering newest frontier models (Gemini 1.5/2.0, Claude 3.5, OpenAI o1/GPT-4o) and monetization strategies.'
      }
    ],
    targetAudience: [
      'Serious builders, agency owners, and digital entrepreneurs who want the complete arsenal',
      'Teams & startups needing an internal AI knowledge base and prompt library',
      'Freelancers who want to offer any AI service requested by clients',
      'Anyone who hates paying recurring monthly subscriptions'
    ],
    bonuses: [
      {
        title: 'Lifetime All-Access Pass to Future Products',
        valueINR: 9999,
        description: 'Never buy another AI guide again. Every future toolkit released by ApexAI will be added to your library automatically.'
      },
      {
        title: 'Private VIP Founder Mastermind Group',
        valueINR: 4999,
        description: 'Collaborate with top builders, share leads, and get direct product feedback from Dipak Prajapati.'
      },
      {
        title: 'Priority 1-on-1 WhatsApp / Email Support',
        valueINR: 3999,
        description: 'Skip the line. Get your questions answered within 12 hours directly by the founding team.'
      }
    ],
    faqs: [
      {
        question: 'Are there any recurring fees or hidden subscriptions?',
        answer: 'Zero recurring fees. You pay once (₹5,999) and receive lifetime access to everything we have built and everything we release in the future.'
      },
      {
        question: 'How do I access all 50+ products and blueprints?',
        answer: 'You will receive access to the central ApexAI Notion Mega-Portal and a master download hub with direct links to every PDF, script, and prompt pack.'
      },
      {
        question: 'What if this doesn’t live up to my expectations?',
        answer: 'We offer a 100% no-questions-asked 14-day money-back guarantee. If you explore the vault and feel it wasn’t worth 10x the price, email us for an instant refund.'
      }
    ]
  }
];
