import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { TrustStrip } from './components/TrustStrip';
import { GoalCategories } from './components/GoalCategories';
import { ProductCatalog } from './components/ProductCatalog';
import { BundlesSection } from './components/BundlesSection';
import { FreeResourceSection } from './components/FreeResourceSection';
import { HowItWorks } from './components/HowItWorks';
import { BlogSection } from './components/BlogSection';
import { BlogDetailsPage } from './components/BlogDetailsPage';
import { ProductDetailsPage } from './components/ProductDetailsPage';
import { BundleDetailsPage } from './components/BundleDetailsPage';
import { BundleDetailModal } from './components/BundleDetailModal';
import { FaqSection } from './components/FaqSection';
import { FinalCta } from './components/FinalCta';
import { Footer } from './components/Footer';
import { CheckoutModal } from './components/CheckoutModal';
import { ProductDetailModal } from './components/ProductDetailModal';
import { UserLibraryModal } from './components/UserLibraryModal';
import { AdminBlogPanel } from './components/AdminBlogPanel';
import { AdminProductPanel } from './components/AdminProductPanel';

import { PRODUCTS_DATA } from './data/products';
import { BUNDLES_DATA } from './data/bundles';
import { BLOG_POSTS_DATA } from './data/blog';
import { FAQS_DATA } from './data/faqs';
import { Product, Bundle, BlogPost, GoalCategory } from './types';
import { useFirebase } from './firebase/context';
import { Package, FileText, Shield, LogOut, X, Sparkles, Download, CreditCard } from 'lucide-react';

export default function App() {
  const [selectedCategory, setSelectedCategory] = useState<GoalCategory>('all');
  const currency: 'INR' | 'USD' = 'INR';

  // Modals state
  const [checkoutItem, setCheckoutItem] = useState<Product | Bundle | null>(null);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [quickViewBundle, setQuickViewBundle] = useState<Bundle | null>(null);
  const [isLibraryOpen, setIsLibraryOpen] = useState(false);
  const [adminMenuOpen, setAdminMenuOpen] = useState(false);
  const [isAdminBlogOpen, setIsAdminBlogOpen] = useState(false);
  const [isAdminProductOpen, setIsAdminProductOpen] = useState(false);

  // Deep CMS state: directly opening product, bundle or payments tab
  const [adminPanelSection, setAdminPanelSection] = useState<'products' | 'bundles' | 'payments'>('products');
  const [adminPanelEditProdId, setAdminPanelEditProdId] = useState<string | null>(null);
  const [adminPanelEditBundleId, setAdminPanelEditBundleId] = useState<string | null>(null);

  // Active full-page views
  const [activeArticle, setActiveArticle] = useState<BlogPost | null>(null);
  const [activeProduct, setActiveProduct] = useState<Product | null>(null);
  const [activeBundle, setActiveBundle] = useState<Bundle | null>(null);

  const { blogPosts, products: firestoreProducts, bundles: firestoreBundles, isAdmin, signOutUser, paymentSettings } = useFirebase();
  const isOwnerVerified = isAdmin || (typeof window !== 'undefined' && localStorage.getItem('apex_owner_verified') === 'true');

  // Dynamic fallback lists
  const dynamicBlogList = blogPosts && blogPosts.length > 0 ? blogPosts : BLOG_POSTS_DATA;
  const dynamicProductList = firestoreProducts && firestoreProducts.length > 0 ? firestoreProducts : PRODUCTS_DATA;
  const dynamicBundleList = firestoreBundles && firestoreBundles.length > 0 ? firestoreBundles : BUNDLES_DATA;

  // Handle URL Hash based routing (#/blog/slug or #/product/slug or #/bundle/slug or #admin)
  const syncRouteFromHash = useCallback(() => {
    const hash = window.location.hash;

    // Admin direct shortcuts
    if (hash === '#admin' || hash === '#admin-login' || hash === '#/admin') {
      setAdminMenuOpen(true);
      return;
    }
    if (
      hash === '#admin-payments' ||
      hash === '#/admin-payments' ||
      hash === '#payments' ||
      hash === '#razorpay'
    ) {
      setAdminPanelSection('payments');
      setIsAdminProductOpen(true);
      return;
    }
    if (
      hash === '#admin-products' ||
      hash === '#/admin-products' ||
      hash === '#products-admin' ||
      hash === '#/products-admin' ||
      hash === '#admin-bundles' ||
      hash === '#/admin-bundles'
    ) {
      setIsAdminProductOpen(true);
      return;
    }
    if (hash === '#admin-blogs' || hash === '#/admin-blogs') {
      setIsAdminBlogOpen(true);
      return;
    }
    if (hash === '#library' || hash === '#downloads' || hash === '#my-downloads' || hash === '#/library') {
      setIsLibraryOpen(true);
      return;
    }

    // Bundle Details route: #/bundle/:slug
    if (hash.startsWith('#/bundle/') || hash.startsWith('#bundle/')) {
      const slug = hash.replace(/^#(|\/)bundle\//, '').trim();
      if (slug) {
        const found = dynamicBundleList.find(
          (b) => b.slug === slug || b.id === slug || b.title.toLowerCase().replace(/[^a-z0-9]+/g, '-') === slug
        );
        if (found) {
          setActiveBundle(found);
          setActiveProduct(null);
          setActiveArticle(null);
          window.scrollTo({ top: 0, behavior: 'smooth' });
          return;
        }
      }
    }

    // Product Details route: #/product/:slug
    if (hash.startsWith('#/product/') || hash.startsWith('#product/')) {
      const slug = hash.replace(/^#(|\/)product\//, '').trim();
      if (slug) {
        const found = dynamicProductList.find(
          (p) => p.slug === slug || p.id === slug || p.title.toLowerCase().replace(/[^a-z0-9]+/g, '-') === slug
        );
        if (found) {
          setActiveProduct(found);
          setActiveBundle(null);
          setActiveArticle(null);
          window.scrollTo({ top: 0, behavior: 'smooth' });
          return;
        }
      }
    }

    // Blog Details route: #/blog/:slug
    if (hash.startsWith('#/blog/') || hash.startsWith('#blog/')) {
      const slug = hash.replace(/^#(|\/)blog\//, '').trim();
      if (slug) {
        const found = dynamicBlogList.find(
          (p) => p.slug === slug || p.id === slug || p.title.toLowerCase().replace(/[^a-z0-9]+/g, '-') === slug
        );
        if (found) {
          setActiveArticle(found);
          setActiveProduct(null);
          setActiveBundle(null);
          window.scrollTo({ top: 0, behavior: 'smooth' });
          return;
        }
      }
    }

    // If on homepage
    if (
      !hash.startsWith('#/blog/') &&
      !hash.startsWith('#blog/') &&
      !hash.startsWith('#/product/') &&
      !hash.startsWith('#product/') &&
      !hash.startsWith('#/bundle/') &&
      !hash.startsWith('#bundle/')
    ) {
      setActiveArticle(null);
      setActiveProduct(null);
      setActiveBundle(null);
    }
  }, [dynamicBlogList, dynamicProductList, dynamicBundleList]);

  useEffect(() => {
    syncRouteFromHash();
    window.addEventListener('hashchange', syncRouteFromHash);
    window.addEventListener('popstate', syncRouteFromHash);

    // Secret Admin Shortcut: Ctrl+Shift+A or Cmd+Shift+A
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && (e.key === 'A' || e.key === 'a')) {
        e.preventDefault();
        setAdminMenuOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);

    return () => {
      window.removeEventListener('hashchange', syncRouteFromHash);
      window.removeEventListener('popstate', syncRouteFromHash);
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [syncRouteFromHash]);

  // Product Selection Handlers
  const handleSelectProduct = (prod: Product) => {
    setActiveProduct(prod);
    setActiveBundle(null);
    setActiveArticle(null);
    const slug = prod.slug || prod.id || prod.title.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    window.location.hash = `#/product/${slug}`;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackFromProduct = () => {
    setActiveProduct(null);
    window.location.hash = '#shop';
    setTimeout(() => {
      const el = document.getElementById('shop');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
      else window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 50);
  };

  // Bundle Selection Handlers
  const handleSelectBundle = (bundle: Bundle) => {
    setActiveBundle(bundle);
    setActiveProduct(null);
    setActiveArticle(null);
    const slug = bundle.slug || bundle.id || bundle.title.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    window.location.hash = `#/bundle/${slug}`;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackFromBundle = () => {
    setActiveBundle(null);
    window.location.hash = '#bundles';
    setTimeout(() => {
      const el = document.getElementById('bundles');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
      else window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 50);
  };

  // Blog Selection Handlers
  const handleSelectArticle = (post: BlogPost) => {
    setActiveArticle(post);
    setActiveProduct(null);
    setActiveBundle(null);
    const slug = post.slug || post.id || post.title.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    window.location.hash = `#/blog/${slug}`;
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackFromBlog = () => {
    setActiveArticle(null);
    window.location.hash = '#blog';
    setTimeout(() => {
      const el = document.getElementById('blog');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
      else window.scrollTo({ top: 0, behavior: 'smooth' });
    }, 50);
  };

  const handleNavigateHome = () => {
    setActiveArticle(null);
    setActiveProduct(null);
    setActiveBundle(null);
    window.location.hash = '';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToShop = () => {
    if (activeArticle || activeProduct || activeBundle) {
      setActiveArticle(null);
      setActiveProduct(null);
      setActiveBundle(null);
      window.location.hash = '#shop';
      setTimeout(() => {
        const el = document.getElementById('shop');
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 50);
    } else {
      const el = document.getElementById('shop');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const scrollToBundles = () => {
    if (activeArticle || activeProduct || activeBundle) {
      setActiveArticle(null);
      setActiveProduct(null);
      setActiveBundle(null);
      window.location.hash = '#bundles';
      setTimeout(() => {
        const el = document.getElementById('bundles');
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 50);
    } else {
      const el = document.getElementById('bundles');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleOpenEditProductInCMS = (productId: string) => {
    setAdminPanelSection('products');
    setAdminPanelEditProdId(productId);
    setAdminPanelEditBundleId(null);
    setIsAdminProductOpen(true);
  };

  const handleOpenEditBundleInCMS = (bundleId: string) => {
    setAdminPanelSection('bundles');
    setAdminPanelEditBundleId(bundleId);
    setAdminPanelEditProdId(null);
    setIsAdminProductOpen(true);
  };

  const handleOpenCheckoutItem = (item: Product | Bundle) => {
    const directLink = item.paymentLink || paymentSettings?.defaultRazorpayUrl;
    if (paymentSettings?.directRedirectOnAccess && directLink) {
      window.open(directLink, '_blank', 'noopener,noreferrer');
      return;
    }
    setCheckoutItem(item);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAFAFC] text-[#0F172A] selection:bg-blue-600 selection:text-white">
      {/* WordPress-Style Admin Bar (Visible when admin or owner passcode verified) */}
      {isOwnerVerified && (
        <aside aria-label="ApexAI WP-Admin Top Bar" className="bg-slate-900 text-slate-200 text-xs py-2 px-4 flex flex-wrap items-center justify-between border-b border-slate-800 z-50 sticky top-0 shadow-md">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 font-bold text-white tracking-wide">
              <Sparkles className="w-3.5 h-3.5 text-blue-400" />
              <span>ApexAI WP-Admin</span>
            </div>

            <div className="h-4 w-px bg-slate-700 hidden sm:block" />

            {/* Contextual Edit Current Page Button */}
            {activeProduct ? (
              <button
                type="button"
                onClick={() => handleOpenEditProductInCMS(activeProduct.id)}
                className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold px-3 py-1 rounded-md transition flex items-center gap-1 cursor-pointer shadow-sm"
              >
                <span>✏️ Edit This Product Landing Page</span>
              </button>
            ) : activeBundle ? (
              <button
                type="button"
                onClick={() => handleOpenEditBundleInCMS(activeBundle.id)}
                className="bg-indigo-500 hover:bg-indigo-400 text-white font-extrabold px-3 py-1 rounded-md transition flex items-center gap-1 cursor-pointer shadow-sm"
              >
                <span>✏️ Edit This Bundle Landing Page</span>
              </button>
            ) : null}

            <button
              type="button"
              onClick={() => {
                setAdminPanelSection('products');
                setAdminPanelEditProdId(null);
                setAdminPanelEditBundleId(null);
                setIsAdminProductOpen(true);
              }}
              className="text-slate-300 hover:text-white px-2 py-1 rounded hover:bg-slate-800 transition cursor-pointer"
            >
              📦 Products CMS
            </button>

            <button
              type="button"
              onClick={() => {
                setAdminPanelSection('bundles');
                setAdminPanelEditProdId(null);
                setAdminPanelEditBundleId(null);
                setIsAdminProductOpen(true);
              }}
              className="text-slate-300 hover:text-white px-2 py-1 rounded hover:bg-slate-800 transition cursor-pointer"
            >
              💎 Bundles CMS
            </button>

            <button
              type="button"
              onClick={() => {
                setAdminPanelSection('payments');
                setAdminPanelEditProdId(null);
                setAdminPanelEditBundleId(null);
                setIsAdminProductOpen(true);
              }}
              className="text-emerald-400 hover:text-white px-2 py-1 rounded hover:bg-slate-800 transition cursor-pointer flex items-center gap-1 font-semibold"
            >
              <CreditCard className="w-3.5 h-3.5" />
              <span>Razorpay Gateway</span>
            </button>

            <button
              type="button"
              onClick={() => setIsAdminBlogOpen(true)}
              className="text-slate-300 hover:text-white px-2 py-1 rounded hover:bg-slate-800 transition cursor-pointer"
            >
              📄 Blog CMS
            </button>
          </div>

          <div className="flex items-center gap-3 mt-1 sm:mt-0">
            <span className="text-[11px] text-emerald-400 font-semibold flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Owner Mode Active</span>
            </span>
            <button
              type="button"
              onClick={() => {
                localStorage.removeItem('apex_owner_verified');
                window.location.reload();
              }}
              className="text-[10px] text-slate-400 hover:text-rose-400 cursor-pointer ml-1 underline"
              title="Lock Admin Mode"
            >
              Lock Admin
            </button>
          </div>
        </aside>
      )}

      {/* Clean Public Header (No Admin buttons visible) */}
      <Header
        onExploreClick={scrollToShop}
        onNavigateHome={handleNavigateHome}
        onNavigateBlog={handleBackFromBlog}
        onOpenLibrary={() => setIsLibraryOpen(true)}
      />

      {/* Main App Body */}
      <main className="flex-1">
        {/* Full-Page Bundle Details Page (WordPress-style high-ticket landing page) */}
        {activeBundle ? (
          <BundleDetailsPage
            bundle={activeBundle}
            allBundles={dynamicBundleList}
            onBack={handleBackFromBundle}
            onOpenCheckout={handleOpenCheckoutItem}
            onOpenCheckoutForBundle={handleOpenCheckoutItem}
            onSelectBundle={handleSelectBundle}
            onEditInCMS={handleOpenEditBundleInCMS}
            currency={currency}
          />
        ) : activeProduct ? (
          /* Full-Page Product Details Page (WordPress-style dynamic landing page) */
          <ProductDetailsPage
            product={activeProduct}
            allProducts={dynamicProductList}
            onBack={handleBackFromProduct}
            onOpenCheckout={handleOpenCheckoutItem}
            onSelectProduct={handleSelectProduct}
            onEditInCMS={handleOpenEditProductInCMS}
            currency={currency}
          />
        ) : activeArticle ? (
          /* Full-Page Blog Article View */
          <BlogDetailsPage
            article={activeArticle}
            allPosts={dynamicBlogList}
            onBack={handleBackFromBlog}
            onSelectArticle={handleSelectArticle}
            onExploreProducts={scrollToShop}
          />
        ) : (
          /* High-Converting Homepage */
          <>
            {/* Hero Section */}
            <Hero
              onExploreClick={scrollToShop}
              onLearnMoreClick={() => {
                const el = document.getElementById('how-it-works');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
            />

            {/* Value / Trust Strip */}
            <TrustStrip />

            {/* Shop By Your Goal */}
            <GoalCategories
              selectedCategory={selectedCategory}
              onSelectCategory={setSelectedCategory}
            />

            {/* Product Catalogue (Dynamic from Firestore with Details Page) */}
            <ProductCatalog
              products={dynamicProductList}
              selectedCategory={selectedCategory}
              onSelectCategory={setSelectedCategory}
              onOpenCheckout={handleOpenCheckoutItem}
              onQuickView={(prod) => setQuickViewProduct(prod)}
              onViewProductDetails={handleSelectProduct}
              onEditInCMS={handleOpenEditProductInCMS}
              currency={currency}
            />

            {/* Complete AI Bundles (Dynamic from Firestore with Quick Preview and Landing Pages) */}
            <BundlesSection
              bundles={dynamicBundleList}
              onOpenCheckoutForBundle={handleOpenCheckoutItem}
              onViewBundleDetails={handleSelectBundle}
              onQuickViewBundle={(b) => setQuickViewBundle(b)}
              onEditInCMS={handleOpenEditBundleInCMS}
              currency={currency}
            />

            {/* Free Resources & Lead Magnet */}
            <FreeResourceSection />

            {/* How It Works 4-Step Process */}
            <HowItWorks />

            {/* Blog & Tutorials Preview (Dynamic from Firestore with SEO links) */}
            <BlogSection
              posts={dynamicBlogList}
              onReadArticle={handleSelectArticle}
            />

            {/* Frequently Asked Questions */}
            <FaqSection faqs={FAQS_DATA} />

            {/* Final High-Converting CTA */}
            <FinalCta onExploreClick={scrollToShop} />
          </>
        )}
      </main>

      {/* Footer (with subtle discreet owner lock trigger) */}
      <Footer
        onSelectCategory={setSelectedCategory}
        onOpenAdmin={() => setAdminMenuOpen(true)}
      />

      {/* Checkout Modal */}
      <CheckoutModal
        item={checkoutItem}
        onClose={() => setCheckoutItem(null)}
        currency={currency}
      />

      {/* Product Quick View Modal */}
      <ProductDetailModal
        product={quickViewProduct}
        onClose={() => setQuickViewProduct(null)}
        onProceedToCheckout={handleOpenCheckoutItem}
        onViewDetails={handleSelectProduct}
        currency={currency}
      />

      {/* Bundle Quick View Modal (thoda content + continue browsing + details page) */}
      <BundleDetailModal
        bundle={quickViewBundle}
        onClose={() => setQuickViewBundle(null)}
        onViewDetails={handleSelectBundle}
        onProceedToCheckout={handleOpenCheckoutItem}
        currency={currency}
      />

      {/* OWNER ADMIN LAUNCHPAD MODAL (Secret access) */}
      {adminMenuOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 relative shadow-2xl border border-slate-200">
            <button
              onClick={() => {
                setAdminMenuOpen(false);
                if (window.location.hash.includes('admin')) {
                  history.replaceState(null, '', window.location.pathname + window.location.search);
                }
              }}
              className="absolute top-6 right-6 p-2 text-slate-400 hover:text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-full transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-2xl bg-slate-900 text-white flex items-center justify-center shadow-md">
                <Shield className="w-5 h-5 text-blue-400" />
              </div>
              <div>
                <h3 className="text-lg font-black text-slate-900">ApexAI Owner Console</h3>
                <p className="text-xs text-slate-500">Authorized Admin Control Hub</p>
              </div>
            </div>

            <div className="space-y-3 mt-6">
              <button
                onClick={() => {
                  setAdminMenuOpen(false);
                  setAdminPanelSection('products');
                  setAdminPanelEditProdId(null);
                  setAdminPanelEditBundleId(null);
                  setIsAdminProductOpen(true);
                }}
                className="w-full bg-slate-50 hover:bg-blue-50/70 border border-slate-200 hover:border-blue-400 p-4 rounded-2xl transition text-left flex items-center gap-3.5 group cursor-pointer"
              >
                <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform shadow-md shadow-blue-500/20">
                  <Package className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition">
                    Products &amp; Bundles CMS
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    WordPress-style landing page builder, curriculum, and PDF delivery
                  </div>
                </div>
              </button>

              <button
                onClick={() => {
                  setAdminMenuOpen(false);
                  setAdminPanelSection('payments');
                  setAdminPanelEditProdId(null);
                  setAdminPanelEditBundleId(null);
                  setIsAdminProductOpen(true);
                }}
                className="w-full bg-slate-50 hover:bg-emerald-50/70 border border-slate-200 hover:border-emerald-400 p-4 rounded-2xl transition text-left flex items-center gap-3.5 group cursor-pointer"
              >
                <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform shadow-md shadow-emerald-500/20">
                  <CreditCard className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-sm font-bold text-slate-900 group-hover:text-emerald-600 transition">
                    Razorpay Payment Gateway Settings
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    Connect your Razorpay URL &amp; payment links to receive customer payments
                  </div>
                </div>
              </button>

              <button
                onClick={() => {
                  setAdminMenuOpen(false);
                  setIsAdminBlogOpen(true);
                }}
                className="w-full bg-slate-50 hover:bg-blue-50/70 border border-slate-200 hover:border-blue-400 p-4 rounded-2xl transition text-left flex items-center gap-3.5 group cursor-pointer"
              >
                <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform shadow-md shadow-indigo-500/20">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition">
                    Articles &amp; SEO Blog CMS
                  </div>
                  <div className="text-xs text-slate-500 mt-0.5">
                    Publish guides, case studies, and editorial tutorials
                  </div>
                </div>
              </button>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-400">
              <span>ApexAI Platform v3.4</span>
              {isAdmin && (
                <button
                  onClick={() => signOutUser()}
                  className="text-rose-500 hover:underline flex items-center gap-1 cursor-pointer font-semibold"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  <span>Sign Out</span>
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* FULL ADMIN PRODUCT & BUNDLE CMS PANEL */}
      <AdminProductPanel
        isOpen={isAdminProductOpen}
        onClose={() => {
          setIsAdminProductOpen(false);
          setAdminPanelEditProdId(null);
          setAdminPanelEditBundleId(null);
          if (window.location.hash.includes('admin')) {
            history.replaceState(null, '', window.location.pathname + window.location.search);
          }
        }}
        onPreviewProduct={handleSelectProduct}
        onPreviewBundle={handleSelectBundle}
        initialSection={adminPanelSection}
        initialEditProductId={adminPanelEditProdId}
        initialEditBundleId={adminPanelEditBundleId}
      />

      {/* FULL ADMIN BLOG CMS PANEL */}
      <AdminBlogPanel
        isOpen={isAdminBlogOpen}
        onClose={() => {
          setIsAdminBlogOpen(false);
          if (window.location.hash.includes('admin')) {
            history.replaceState(null, '', window.location.pathname + window.location.search);
          }
        }}
        onPreviewPost={handleSelectArticle}
      />

      {/* USER LIBRARY & DOWNLOADS MODAL */}
      <UserLibraryModal
        isOpen={isLibraryOpen}
        onClose={() => setIsLibraryOpen(false)}
        onExploreProducts={scrollToShop}
      />
    </div>
  );
}
